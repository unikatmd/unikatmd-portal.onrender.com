const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');

const dbPath = path.join(__dirname, 'poslovni_sistem.db');
const db = new Database(dbPath);

console.log('Connecting to database...');

// 1. Ensure all employees exist in users table
const employees = [
  { fullName: 'Stefan Glišić', username: 'stefan', role: 'worker', phone: '+387 61 100 201', rate: 12.5 },
  { fullName: 'Amra Bećirović', username: 'amra', role: 'worker', phone: '+387 61 100 202', rate: 12.5 },
  { fullName: 'Nermin Tufekčić', username: 'nermin', role: 'worker', phone: '+387 61 100 203', rate: 12.5 },
  { fullName: 'Edin Đapo', username: 'edin', role: 'worker', phone: '+387 61 100 204', rate: 12.5 },
  { fullName: 'Sara Jekić', username: 'sara', role: 'worker', phone: '+387 61 100 205', rate: 12.5 },
  { fullName: 'Dejana Đukić', username: 'dejana', role: 'worker', phone: '+387 61 100 206', rate: 12.5 }
];

const salt = bcrypt.genSaltSync(10);
const defaultHash = bcrypt.hashSync('rad123', salt);

const findUser = db.prepare('SELECT id FROM users WHERE LOWER(TRIM(full_name)) = LOWER(TRIM(?)) OR username = ?');
const insertUser = db.prepare(`
  INSERT INTO users (username, password_hash, full_name, role, phone, hourly_rate)
  VALUES (?, ?, ?, ?, ?, ?)
`);
const updateUser = db.prepare('UPDATE users SET full_name = ?, hourly_rate = ? WHERE id = ?');

const userMap = {}; // fullName -> id

employees.forEach(emp => {
  let existing = findUser.get(emp.fullName, emp.username);
  if (!existing) {
    const res = insertUser.run(emp.username, defaultHash, emp.fullName, emp.role, emp.phone, emp.rate);
    userMap[emp.fullName] = res.lastInsertRowid;
    console.log(`Created user: ${emp.fullName} (id: ${res.lastInsertRowid})`);
  } else {
    updateUser.run(emp.fullName, emp.rate, existing.id);
    userMap[emp.fullName] = existing.id;
    console.log(`User already exists: ${emp.fullName} (id: ${existing.id})`);
  }
});

// Clear existing work hours for these employees to prevent duplicates on rerun
const deleteOld = db.prepare('DELETE FROM work_hours WHERE user_id IN (' + Object.values(userMap).join(',') + ')');
deleteOld.run();

const insertWorkHour = db.prepare(`
  INSERT INTO work_hours (user_id, client_id, task_id, work_date, hours, start_time, end_time, overtime_hours, hourly_rate, description, status)
  VALUES (?, NULL, NULL, ?, ?, '09:00', '17:00', ?, ?, ?, 'approved')
`);

const raw = fs.readFileSync(path.join(__dirname, 'raw_sheets.txt'), 'utf8');
const lines = raw.split(/\r?\n/).filter(l => l.trim().length > 0);

let importedEntries = 0;

function processMonth(monthStr, daysLineIdx, workerRows) {
  const daysParts = lines[daysLineIdx].split('\t');
  
  workerRows.forEach(rowIdx => {
    const rowParts = lines[rowIdx].split('\t');
    const workerName = rowParts[0].trim();
    const userId = userMap[workerName];
    if (!userId) return;

    daysParts.forEach((d, colIdx) => {
      const dayNum = parseInt(d);
      if (isNaN(dayNum) || dayNum < 1 || dayNum > 31) return;

      const rawVal = (rowParts[colIdx] || '').trim();
      const numHours = parseFloat(rawVal);

      let desc = 'Radno vrijeme 09:00 - 17:00h';
      let hours = 0;

      if (!isNaN(numHours) && numHours > 0) {
        hours = numHours;
      } else if (rawVal && isNaN(numHours) && rawVal !== '0') {
        desc = `Napomena iz tabele: ${rawVal}`;
      }

      if (hours > 0) {
        const dateFormatted = `${monthStr}-${String(dayNum).padStart(2, '0')}`;
        const ot = hours > 8 ? hours - 8 : 0;
        insertWorkHour.run(userId, dateFormatted, hours, ot, 12.5, desc);
        importedEntries++;
      }
    });
  });
}

// 1. Septembar 2026: days at line 2, workers at 3, 4, 5, 6, 7
processMonth('2026-09', 2, [3, 4, 5, 6, 7]);

// 2. Oktobar 2026: days at line 10, workers at 11, 12, 13, 14, 15
processMonth('2026-10', 10, [11, 12, 13, 14, 15]);

// 3. Novembar 2026: days at line 18, workers at 19, 20, 21, 22, 23
processMonth('2026-11', 18, [19, 20, 21, 22, 23]);

console.log(`\nImport complete! Total work hours entries imported: ${importedEntries}`);

// Verify totals
const summary = db.prepare(`
  SELECT u.full_name, strftime('%Y-%m', w.work_date) as month, SUM(w.hours) as total_hours, COUNT(*) as days_count
  FROM work_hours w
  JOIN users u ON w.user_id = u.id
  GROUP BY u.id, month
  ORDER BY month ASC, u.full_name ASC
`).all();

console.table(summary);
