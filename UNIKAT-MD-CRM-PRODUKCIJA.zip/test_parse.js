const fs = require('fs');
// Let's get the user prompt text or write it out to inspect
