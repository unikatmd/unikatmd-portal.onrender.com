# 🏢 Poslovni Portal & Radni CRM Sistem

Kompletan sistem za upravljanje klijentima, radnim nalozima (plan i program rada) i finansijama (sekretarica modul: ko je platio, ko duguje).

---

## 🌟 Glavne Funkcionalnosti

### 1. 👥 Evidencija Klijenata (CRM)
- Registar svih firmi i klijenata (kontakt osoba, telefon, email, grad, adresa, napomene).
- Kartica klijenta: jednim klikom vidite kompletnu istoriju tog klijenta.
- Filteri i brza pretraga po imenu, gradu ili broju telefona.

### 2. 📋 Plan i Program Rada (Radni Nalozi po Klijentu)
- **Šta treba da se radi**: Jasno definisani zadaci za svakog klijenta, uputstvo radnicima, rok i nivo prioriteta (hitno/normalno).
- **Trenutno u toku**: Poslovi koje radnici trenutno obavljaju.
- **Urađeno (Završeno)**: Istorija urađenih poslova sa tačnim datumom završetka i izvještajem radnika o tome šta je urađeno.
- **Blokirano / Nije urađeno**: Odmah vidljivo ako je nastao problem na terenu.

### 3. 💼 Modul za Sekretaricu (Finansije & Dugovanja)
> 🔒 *Zaštićen modul: Radnici nemaju pristup ovim podacima.*
- **Ko duguje novac**: Tabela sa klijentima, ugovorenim iznosima, uplaćenim iznosima i tačnim preostalim dugom.
- **Ko je platio**: Istorija svih uplata (iznos, datum, način uplate: banka/gotovina, napomena).
- **Evidencija uplate u 2 klika**: Sekretarica odabere klijenta i unese iznos; dug se automatski smanjuje.
- **Fakture i zaduženja**: Evidencija brojeva faktura, ugovorenih radova i rokova dospijeća.

### 4. 🔐 3 Nivoa Pristupa (Uloge)
1. **👑 Direktor / Vlasnik** (`direktor` / `admin123`):
   - Pun uvid u sve klijente, poslove, finansije, dugovanja i radnike.
   - Može pristupiti sa mobilnog telefona dok je na putu.
2. **💼 Sekretarica** (`sekretarica` / `sek123`):
   - Evidencija uplata, dužnika, faktura, kreiranje klijenata i zadataka.
3. **🔧 Radnici** (`radnik` / `rad123`):
   - Vide klijente, zadatke i šta treba da se radi.
   - Mogu označiti posao kao "U toku" ili "Urađeno" i upisati šta su završili.
   - **NEMAJU uvid u cijene i dugovanja.**

---

## 🌐 Kako dobiti TRAJNI LINK za pristup sa telefona na putu i kancelarije?

Da bi direktor imao pristup dok putuje, a radnici iz kancelarije, aplikacija se postavlja na internet preko besplatnog ili jeftinog cloud servisa:

### Opcija 1: Besplatno preko Render.com (Preporučeno - 5 minuta)
1. Napravite besplatan nalog na [render.com](https://render.com).
2. Povežite ovaj projekat (preko GitHub repozitorijuma) ili kliknite **New Web Service**.
3. Render automatski prepoznaje `render.yaml` i dodjeljuje vam trajni link, npr:
   `https://vasa-firma.onrender.com`
4. Taj link pošaljete radnicima u kancelariju i sačuvate ga na svom mobilnom telefonu (može se dodati na početni ekran kao ikonica aplikacije).

### Opcija 2: Pokretanje na računaru u kancelariji
- Dvaput kliknite na fajl `pokreni_lokalno.bat`.
- Svi računari u istoj kancelarijskoj mreži (Wi-Fi/LAN) mogu pristupiti preko lokalne IP adrese, npr. `http://192.168.1.50:3000`.

---

## 🚀 Pokretanje i Testiranje

1. Pokrenite aplikaciju pokretanjem fajla:
   `pokreni_lokalno.bat`
   ili u terminalu kucajte:
   `node server.js`
2. Otvorite internet pretraživač (Chrome, Edge) na:
   [http://localhost:3000](http://localhost:3000)
3. Na ekranu za prijavu imate brza dugmad za testiranje direktora, sekretarice i radnika.
