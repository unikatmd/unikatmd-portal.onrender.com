@echo off
cd /d "%~dp0"
title Poslovni Sistem - Evidencija Klijenata i Finansija
echo ========================================================
echo       POKRETANJE POSLOVNOG PORTALA I CRM SISTEMA
echo ========================================================
echo.

set PATH=%PATH%;C:\Program Files\nodejs

echo Provjera Node.js okruzenja...
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [GRESKA] Node.js nije pronadjen!
    echo Molimo provjerite da li je instaliran u C:\Program Files\nodejs
    pause
    exit /b
)

echo Pokrecem server...
echo.
echo Adresa: http://localhost:3000
echo.
echo Otvaram pretrazivac za 2 sekunde...
start "" "http://localhost:3000"

echo ========================================================
echo  Server je aktivan! Ostavite ovaj prozor otvoren dok radite.
echo  Pritisnite Ctrl+C za zaustavljanje.
echo ========================================================
echo.

node server.js
pause
