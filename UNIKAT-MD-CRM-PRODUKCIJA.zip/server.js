const express = require('express');
const path = require('path');
const cors = require('cors');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'poslovni-crm-tajni-kljuc-2026';
const PORT = process.env.PORT || 3000;

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Database setup
const dbPath = path.join(__dirname, 'poslovni_sistem.db');
const db = new Database(dbPath);
db.pragma('journal_mode = WAL');

// Initialize database schema
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('admin', 'secretary', 'worker')),
    phone TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS clients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    contact_person TEXT,
    phone TEXT,
    email TEXT,
    address TEXT,
    city TEXT,
    notes TEXT,
    status TEXT DEFAULT 'active' CHECK(status IN ('active', 'paused', 'completed')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'todo' CHECK(status IN ('todo', 'in_progress', 'done', 'blocked')),
    priority TEXT DEFAULT 'medium' CHECK(priority IN ('low', 'medium', 'high')),
    assigned_user_id INTEGER,
    due_date DATE,
    completed_at DATETIME,
    completed_note TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE CASCADE,
    FOREIGN KEY(assigned_user_id) REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS billing (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    invoice_number TEXT,
    total_amount REAL NOT NULL DEFAULT 0,
    paid_amount REAL NOT NULL DEFAULT 0,
    due_date DATE,
    status TEXT DEFAULT 'unpaid' CHECK(status IN ('unpaid', 'partial', 'paid')),
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER NOT NULL,
    billing_id INTEGER,
    amount REAL NOT NULL,
    payment_date DATE NOT NULL,
    payment_method TEXT DEFAULT 'bank' CHECK(payment_method IN ('bank', 'cash', 'card', 'other')),
    note TEXT,
    created_by_user_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE CASCADE,
    FOREIGN KEY(billing_id) REFERENCES billing(id) ON DELETE SET NULL,
    FOREIGN KEY(created_by_user_id) REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS work_hours (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    client_id INTEGER,
    task_id INTEGER,
    work_date DATE NOT NULL,
    hours REAL NOT NULL,
    start_time TEXT,
    end_time TEXT,
    overtime_hours REAL DEFAULT 0,
    hourly_rate REAL DEFAULT 0,
    description TEXT,
    status TEXT DEFAULT 'approved' CHECK(status IN ('pending', 'approved', 'rejected')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE SET NULL,
    FOREIGN KEY(task_id) REFERENCES tasks(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    month TEXT NOT NULL,
    item_order INTEGER DEFAULT 1,
    title TEXT NOT NULL,
    payment_date_desc TEXT,
    amount REAL NOT NULL DEFAULT 0,
    payment_method TEXT NOT NULL DEFAULT 'gotovina' CHECK(payment_method IN ('gotovina', 'ziralno', 'ostalo')),
    notes TEXT,
    category TEXT DEFAULT 'opste',
    is_paid INTEGER DEFAULT 1,
    created_by_user_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(created_by_user_id) REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS monthly_finance_meta (
    month TEXT PRIMARY KEY,
    cash_withdrawn REAL DEFAULT 0,
    opening_cash_balance REAL DEFAULT 0,
    opening_bank_balance REAL DEFAULT 0,
    notes TEXT,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS company_liabilities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    month TEXT NOT NULL,
    creditor_name TEXT NOT NULL,
    description TEXT,
    amount REAL NOT NULL DEFAULT 0,
    paid_amount REAL NOT NULL DEFAULT 0,
    due_date TEXT,
    status TEXT DEFAULT 'unpaid' CHECK(status IN ('unpaid', 'partial', 'paid')),
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS print_services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_date DATE NOT NULL,
    client_id INTEGER,
    client_name TEXT NOT NULL,
    service_type TEXT NOT NULL,
    description TEXT,
    executor TEXT DEFAULT 'Misija',
    status TEXT DEFAULT 'done' CHECK(status IN ('in_progress', 'done', 'cancelled')),
    price REAL DEFAULT 0,
    paid_amount REAL DEFAULT 0,
    payment_status TEXT DEFAULT 'unpaid',
    payment_date TEXT,
    notes TEXT,
    responsible_person TEXT DEFAULT 'Emin / Amra',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE SET NULL
  );
`);

// Migration: add hourly_rate to users if missing
try {
  db.exec('ALTER TABLE users ADD COLUMN hourly_rate REAL DEFAULT 0');
} catch (e) {}

// Migration: add monthly_package, payment_day_desc, currency to clients
try { db.exec("ALTER TABLE clients ADD COLUMN monthly_package REAL DEFAULT 0"); } catch (e) {}
try { db.exec("ALTER TABLE clients ADD COLUMN payment_day_desc TEXT"); } catch (e) {}
try { db.exec("ALTER TABLE clients ADD COLUMN currency TEXT DEFAULT 'KM'"); } catch (e) {}

// Migration: add month and billing_type to billing
try { db.exec("ALTER TABLE billing ADD COLUMN month TEXT"); } catch (e) {}
try { db.exec("ALTER TABLE billing ADD COLUMN billing_type TEXT DEFAULT 'package'"); } catch (e) {}

// Migration: add payment tracking to print_services
try { db.exec("ALTER TABLE print_services ADD COLUMN paid_amount REAL DEFAULT 0"); } catch (e) {}
try { db.exec("ALTER TABLE print_services ADD COLUMN payment_status TEXT DEFAULT 'unpaid'"); } catch (e) {}
try { db.exec("ALTER TABLE print_services ADD COLUMN payment_date TEXT"); } catch (e) {}

// Migration: add granular permissions to users
try { db.exec("ALTER TABLE users ADD COLUMN permissions TEXT"); } catch (e) {}

// Postavke sistema (Zajednička Master Šifra Firme za ulaz radnika)
try {
  db.exec(`
    CREATE TABLE IF NOT EXISTS system_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    )
  `);
} catch (e) {}

const getSystemSetting = (key, defaultVal) => {
  try {
    const row = db.prepare('SELECT value FROM system_settings WHERE key = ?').get(key);
    return row ? row.value : defaultVal;
  } catch (e) {
    return defaultVal;
  }
};

const setSystemSetting = (key, val) => {
  db.prepare(`
    INSERT INTO system_settings (key, value) VALUES (?, ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value
  `).run(key, val);
};

// Postavi početnu master šifru firme ako još nije definisana
try {
  if (!db.prepare('SELECT value FROM system_settings WHERE key = ?').get('portal_master_key')) {
    setSystemSetting('portal_master_key', 'unikatmd2609876');
  }
} catch (e) {}

// DEFINICIJA SVIH DOSTUPNIH DOZVOLA / PERMISIJA NA SAJTU
const PERMISSION_DEFINITIONS = [
  {
    category: 'Finansije & Dugovanja',
    icon: 'coins',
    items: [
      { key: 'view_finances', label: 'Pregled Finansija & Sekretarica', desc: 'Pristup modulu Finansije, pregled ugovorenih paketa i naplate' },
      { key: 'manage_debts', label: 'Uređivanje Dugovanja Klijenata', desc: 'Direktno mijenjanje stvarnog duga, starog duga i iznosa paketa' },
      { key: 'record_payments', label: 'Evidentiranje Uplata Klijenata', desc: 'Unos uplate kada klijent plati na račun ili u gotovini' },
      { key: 'manage_expenses', label: 'Rashodi & Troškovi Firme', desc: 'Unos, izmjena i brisanje troškova poslovanja (kirija, režije, plate...)' },
      { key: 'manage_invoices', label: 'Zaduženja & Fakture', desc: 'Kreiranje, izmjena i brisanje pojedinačnih računa i zaduženja' },
      { key: 'view_cash_meta', label: 'Kasa & Žirala', desc: 'Podešavanje i uvid u stanje gotovine i novca na računu firme' },
      { key: 'view_earnings', label: 'Uvid u Iznose Zarada', desc: 'Prikaz novčanih iznosa plata radnika i finansijskih cifri poslovanja' }
    ]
  },
  {
    category: 'Klijenti & Partneri',
    icon: 'building-2',
    items: [
      { key: 'view_clients', label: 'Pregled Baze Klijenata', desc: 'Pristup listi i kontakt podacima klijenata' },
      { key: 'manage_clients', label: 'Dodavanje i Izmjena Klijenata', desc: 'Kreiranje novih klijenata, cjenovnika i ugovorenih paketa' },
      { key: 'delete_clients', label: 'Brisanje Klijenata', desc: 'Mogućnost trajnog brisanja klijenta iz sistema' }
    ]
  },
  {
    category: 'Radni Nalozi & Zadaci',
    icon: 'check-square',
    items: [
      { key: 'view_all_tasks', label: 'Pregled Svih Radnih Naloga', desc: 'Uvid u radne zadatke svih kolega u firmi (ne samo svojih)' },
      { key: 'create_tasks', label: 'Kreiranje i Dodjela Naloga', desc: 'Otvaranje novih zadataka i dodjeljivanje radnicima' },
      { key: 'edit_tasks', label: 'Izmjena i Brisanje Naloga', desc: 'Uređivanje opisa, rokova, prioriteta i brisanje zadataka' }
    ]
  },
  {
    category: 'Radni Sati & Obračun',
    icon: 'clock',
    items: [
      { key: 'log_work_hours', label: 'Unos Vlastitih Radnih Sati', desc: 'Evidentiranje svog rada, dolazaka i odlazaka' },
      { key: 'view_all_work_hours', label: 'Pregled Sati Svih Radnika', desc: 'Uvid u radne sate svih zaposlenih u firmi' },
      { key: 'manage_work_hours', label: 'Uređivanje Radnih Sati', desc: 'Izmjena i brisanje radnih sati drugih zaposlenih' },
      { key: 'view_payroll', label: 'Obračun Plata (Payroll)', desc: 'Pristup zbirnom obračunu isplata i plata zaposlenih' }
    ]
  },
  {
    category: 'Štamparija',
    icon: 'printer',
    items: [
      { key: 'view_print', label: 'Pregled Naloga Štampe', desc: 'Uvid u evidenciju izvršenih usluga štamparije' },
      { key: 'manage_print', label: 'Kreiranje i Izmjena Naloga', desc: 'Dodavanje i uređivanje narudžbi za štampu' },
      { key: 'manage_print_billing', label: 'Cijene & Naplata Štampe', desc: 'Uvid u cijene štampe, dugove i evidentiranje naplate' }
    ]
  },
  {
    category: 'Zaposleni & Permisije',
    icon: 'shield',
    items: [
      { key: 'manage_users', label: 'Dodavanje i Uređivanje Zaposlenih', desc: 'Kreiranje novih korisnika, izmjena podataka i satnica radnika' },
      { key: 'manage_permissions', label: 'Podešavanje Permisija i Dozvola', desc: 'Pravo dodjele i izmjene permisija drugim korisnicima' }
    ]
  }
];

function getDefaultPermissions(role) {
  const allKeys = {};
  PERMISSION_DEFINITIONS.forEach(cat => {
    cat.items.forEach(it => {
      allKeys[it.key] = false;
    });
  });

  if (role === 'admin') {
    Object.keys(allKeys).forEach(k => allKeys[k] = true);
    return allKeys;
  }

  if (role === 'secretary') {
    Object.keys(allKeys).forEach(k => allKeys[k] = true);
    allKeys['manage_permissions'] = false; // Samo Admin može mijenjati sistemske permisije
    return allKeys;
  }

  // Standardni radnik:
  allKeys['view_clients'] = true;
  allKeys['log_work_hours'] = true;
  allKeys['view_print'] = true;
  return allKeys;
}

function getUserPermissions(userOrId) {
  let user = null;
  if (typeof userOrId === 'object' && userOrId !== null) {
    user = userOrId;
  } else {
    user = db.prepare('SELECT id, username, role, permissions FROM users WHERE id = ?').get(userOrId);
  }
  if (!user) return {};

  const defaults = getDefaultPermissions(user.role);
  if (user.role === 'admin') {
    return defaults;
  }

  if (user.permissions) {
    try {
      const parsed = JSON.parse(user.permissions);
      return { ...defaults, ...parsed };
    } catch (e) {
      return defaults;
    }
  }

  return defaults;
}

// Authentication middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Niste prijavljeni. Molimo prijavite se.' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Sesija je istekla ili nije važeća. Prijavite se ponovo.' });
    }
    req.user = user;
    next();
  });
}

// Require role helper (backward-compatible)
function requireRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Niste prijavljeni.' });
    }
    if (req.user.role === 'admin') {
      return next();
    }
    if (allowedRoles.includes(req.user.role)) {
      return next();
    }
    return res.status(403).json({ error: 'Nemate dozvolu za pristup ovom dijelu programa.' });
  };
}

// Granular permission check middleware
function requirePermission(permKey, ...fallbackRoles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Niste prijavljeni. Molimo prijavite se.' });
    }
    if (req.user.role === 'admin') {
      return next();
    }
    const perms = getUserPermissions(req.user.id);
    if (perms[permKey] === true) {
      return next();
    }
    if (fallbackRoles.length > 0 && fallbackRoles.includes(req.user.role)) {
      return next();
    }
    return res.status(403).json({
      error: `Nemate potrebnu dozvolu ("${permKey}") za ovu akciju. Obratite se administratoru.`
    });
  };
}

// ==================== AUTH ROUTES ====================
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Unesite korisničko ime i lozinku.' });
  }

  let searchUsername = username.trim().toLowerCase();
  // Alias mapping za lakšu prijavu
  if (searchUsername === 'djapo' || searchUsername === 'đapo' || searchUsername === 'dapo') {
    searchUsername = 'edin';
  } else if (searchUsername === 'direktor' || searchUsername === 'vlasnik') {
    searchUsername = 'emin';
  }

  const user = db.prepare('SELECT * FROM users WHERE LOWER(username) = ?').get(searchUsername);
  let isPasswordValid = false;
  if (user && user.password_hash) {
    isPasswordValid = bcrypt.compareSync(password, user.password_hash);
  }

  if (!user || !isPasswordValid) {
    return res.status(401).json({ error: 'Pogrešno korisničko ime ili lozinka.' });
  }

  const token = jwt.sign(
    { id: user.id, username: user.username, role: user.role, full_name: user.full_name },
    JWT_SECRET,
    { expiresIn: '30d' }
  );

  const userPerms = getUserPermissions(user);
  res.json({
    token,
    user: {
      id: user.id,
      username: user.username,
      full_name: user.full_name,
      role: user.role,
      phone: user.phone,
      hourly_rate: user.hourly_rate || 0,
      avatar: user.avatar || null,
      permissions: userPerms
    }
  });
});

app.get('/api/auth/me', authenticateToken, (req, res) => {
  const user = db.prepare('SELECT id, username, full_name, role, phone, hourly_rate, avatar, permissions, created_at FROM users WHERE id = ?').get(req.user.id);
  if (!user) return res.status(404).json({ error: 'Korisnik nije pronađen.' });
  user.permissions = getUserPermissions(user);
  res.json({ user });
});

// Middleware koji osigurava da samo oni koji znaju master šifru firme mogu dohvatiti profile zaposlenih
const requireGateAccess = (req, res, next) => {
  const gateHeader = req.headers['x-portal-gate'];
  const authHeader = req.headers['authorization'];

  // 1. Ako već postoji valjan JWT korisnički token (već prijavljen korisnik)
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    try {
      jwt.verify(token, JWT_SECRET);
      return next();
    } catch (e) {}
  }

  // 2. Ako je poslan master gate token
  if (gateHeader) {
    try {
      const decoded = jwt.verify(gateHeader, JWT_SECRET);
      if (decoded && decoded.gate === 'unikat_portal_access') {
        return next();
      }
    } catch (e) {}

    // 3. Ili ako je u headeru poslana direktna master šifra
    const currentKey = getSystemSetting('portal_master_key', 'unikatmd2609876');
    if (gateHeader.trim().toLowerCase() === currentKey.trim().toLowerCase()) {
      return next();
    }
  }

  return res.status(403).json({ error: 'Zaštićen pristup. Morate unijeti zajedničku master šifru firme da biste vidjeli zaposlene.' });
};

// Verifikacija zajedničke master šifre firme (Otključavanje portala)
app.post('/api/portal/verify-gate', (req, res) => {
  const access_code = req.body.access_code || req.body.masterKey;
  if (!access_code) {
    return res.status(400).json({ error: 'Morate unijeti zajedničku šifru firme.' });
  }

  const currentKey = getSystemSetting('portal_master_key', 'unikatmd2609876');
  if (access_code.trim().toLowerCase() === currentKey.trim().toLowerCase()) {
    const gateToken = jwt.sign(
      { gate: 'unikat_portal_access', verifiedAt: Date.now() },
      JWT_SECRET,
      { expiresIn: '30d' }
    );
    return res.json({ success: true, gate_token: gateToken, message: 'Pristup portalu odobren!' });
  }

  return res.status(401).json({ error: 'Pogrešna master šifra firme. Pristup profilima zaposlenih je zaključan.' });
});

// Zaštićeni endpoint za prikaz profila zaposlenih na login ekranu sa slikama (zahtijeva zajedničku master šifru)
app.get('/api/public/profiles', requireGateAccess, (req, res) => {
  const profiles = db.prepare(`
    SELECT id, username, full_name, role, avatar 
    FROM users 
    ORDER BY CASE WHEN role = 'admin' THEN 1 WHEN role = 'secretary' THEN 2 ELSE 3 END, full_name ASC
  `).all();
  res.json({ profiles });
});

// Pregled i izmjena zajedničke master šifre (Samo Direktor)
app.get('/api/portal/master-key', authenticateToken, requirePermission('manage_users', 'admin'), (req, res) => {
  const currentKey = getSystemSetting('portal_master_key', 'unikatmd2609876');
  res.json({ master_key: currentKey });
});

app.put('/api/portal/master-key', authenticateToken, requirePermission('manage_users', 'admin'), (req, res) => {
  const { new_master_key } = req.body;
  if (!new_master_key || new_master_key.trim().length < 4) {
    return res.status(400).json({ error: 'Master šifra mora imati najmanje 4 znaka.' });
  }
  setSystemSetting('portal_master_key', new_master_key.trim());
  const gateToken = jwt.sign(
    { gate: 'unikat_portal_access', verifiedAt: Date.now() },
    JWT_SECRET,
    { expiresIn: '30d' }
  );
  res.json({ success: true, gate_token: gateToken, message: 'Zajednička master šifra firme je uspješno ažurirana!' });
});

// Promjena lozinke - dostupno svakom prijavljenom korisniku (Amra, Stefan, Sara, Emin, Đapo...)
app.put('/api/auth/change-password', authenticateToken, (req, res) => {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword) {
    return res.status(400).json({ error: 'Morate unijeti trenutnu i novu lozinku.' });
  }

  if (newPassword.length < 4) {
    return res.status(400).json({ error: 'Nova lozinka mora imati najmanje 4 karaktera.' });
  }

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  if (!user) {
    return res.status(404).json({ error: 'Korisnik nije pronađen.' });
  }

  const isCurrentValid = bcrypt.compareSync(currentPassword, user.password_hash);
  if (!isCurrentValid) {
    return res.status(400).json({ error: 'Trenutna lozinka nije ispravna.' });
  }

  const salt = bcrypt.genSaltSync(10);
  const newHash = bcrypt.hashSync(newPassword, salt);

  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(newHash, req.user.id);

  res.json({ success: true, message: 'Lozinka je uspješno promijenjena! Koristite novu lozinku za prijavu.' });
});

// ==================== USERS & PERMISSIONS MANAGEMENT ====================
app.get('/api/permissions/definitions', authenticateToken, (req, res) => {
  res.json({ definitions: PERMISSION_DEFINITIONS });
});

app.get('/api/users', authenticateToken, (req, res) => {
  const users = db.prepare('SELECT id, username, full_name, role, phone, hourly_rate, avatar, permissions, created_at FROM users ORDER BY full_name ASC').all();
  users.forEach(u => {
    u.permissions = getUserPermissions(u);
  });
  res.json({ users });
});

// Pregled permisija za određenog radnika
app.get('/api/users/:id/permissions', authenticateToken, (req, res) => {
  const currentPerms = getUserPermissions(req.user.id);
  if (req.user.role !== 'admin' && !currentPerms.manage_permissions) {
    return res.status(403).json({ error: 'Samo administrator može pregledati i podešavati dozvole zaposlenih.' });
  }

  const userId = parseInt(req.params.id);
  const targetUser = db.prepare('SELECT id, username, full_name, role, permissions FROM users WHERE id = ?').get(userId);
  if (!targetUser) {
    return res.status(404).json({ error: 'Korisnik nije pronađen.' });
  }

  res.json({
    user_id: targetUser.id,
    username: targetUser.username,
    full_name: targetUser.full_name,
    role: targetUser.role,
    permissions: getUserPermissions(targetUser),
    definitions: PERMISSION_DEFINITIONS
  });
});

// Spremanje / izmjena permisija za određenog radnika (Admin & menadžer sa permisijom)
app.put('/api/users/:id/permissions', authenticateToken, (req, res) => {
  const currentPerms = getUserPermissions(req.user.id);
  if (req.user.role !== 'admin' && !currentPerms.manage_permissions) {
    return res.status(403).json({ error: 'Samo administrator ima ovlaštenje za dodjelu i izmjenu permisija.' });
  }

  const userId = parseInt(req.params.id);
  const targetUser = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  if (!targetUser) {
    return res.status(404).json({ error: 'Korisnik nije pronađen.' });
  }

  // Ne dozvoli ograničavanje administratora (direktora)
  if (targetUser.role === 'admin' && req.user.id !== targetUser.id) {
    return res.status(400).json({ error: 'Direktor / Administrator uvijek posjeduje sve dozvole na sistemu i ne može se ograničiti.' });
  }

  const { permissions } = req.body;
  if (!permissions || typeof permissions !== 'object') {
    return res.status(400).json({ error: 'Neispravan format permisija.' });
  }

  const jsonStr = JSON.stringify(permissions);
  db.prepare('UPDATE users SET permissions = ? WHERE id = ?').run(jsonStr, userId);

  const updatedPerms = getUserPermissions(userId);
  res.json({
    success: true,
    message: `Dozvole za korisnika "${targetUser.full_name}" su uspješno ažurirane!`,
    permissions: updatedPerms
  });
});

app.post('/api/users', authenticateToken, requirePermission('manage_users', 'admin', 'secretary'), (req, res) => {
  const { username, password, full_name, role, phone, hourly_rate, avatar, permissions } = req.body;
  if (!username || !password || !full_name || !role) {
    return res.status(400).json({ error: 'Sva polja osim telefona i satnice su obavezna.' });
  }

  try {
    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync(password, salt);
    const rate = hourly_rate ? parseFloat(hourly_rate) || 0 : 0;
    const permsJson = permissions ? JSON.stringify(permissions) : null;

    const result = db.prepare(`
      INSERT INTO users (username, password_hash, full_name, role, phone, hourly_rate, avatar, permissions)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(username.trim(), hash, full_name.trim(), role, phone || null, rate, avatar || null, permsJson);

    res.json({ success: true, id: result.lastInsertRowid, message: 'Radnik / korisnik uspješno kreiran.' });
  } catch (err) {
    if (err.message.includes('UNIQUE constraint failed: users.username')) {
      return res.status(400).json({ error: 'Korisničko ime već postoji.' });
    }
    res.status(500).json({ error: 'Greška pri kreiranju korisnika: ' + err.message });
  }
});

// Ažuriranje satnice radnika (KM/h)
app.put('/api/users/:id/rate', authenticateToken, (req, res) => {
  const userId = parseInt(req.params.id);
  const currentPerms = getUserPermissions(req.user.id);
  if (req.user.role !== 'admin' && !currentPerms.manage_users && req.user.id !== userId) {
    return res.status(403).json({ error: 'Nemate dozvolu za promjenu satnice drugog radnika.' });
  }

  const { hourly_rate } = req.body;
  const rate = parseFloat(hourly_rate);
  if (isNaN(rate) || rate < 0) {
    return res.status(400).json({ error: 'Nevažeći iznos satnice.' });
  }

  db.prepare('UPDATE users SET hourly_rate = ? WHERE id = ?').run(rate, userId);
  res.json({ success: true, message: 'Satnica uspješno ažurirana.' });
});

app.put('/api/users/:id', authenticateToken, requirePermission('manage_users', 'admin', 'secretary'), (req, res) => {
  const userId = parseInt(req.params.id);
  const { full_name, role, phone, hourly_rate, avatar, password, permissions } = req.body;
  const existing = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  if (!existing) return res.status(404).json({ error: 'Korisnik nije pronađen.' });

  // Sekretarica ne može promijeniti direktora u radnika
  if (existing.role === 'admin' && req.user.role !== 'admin' && role && role !== 'admin') {
    return res.status(403).json({ error: 'Samo direktor može mijenjati ulogu administratora.' });
  }

  let hash = existing.password_hash;
  if (password && password.trim()) {
    const salt = bcrypt.genSaltSync(10);
    hash = bcrypt.hashSync(password.trim(), salt);
  }

  const rate = hourly_rate !== undefined ? parseFloat(hourly_rate) || 0 : (existing.hourly_rate || 0);
  const permsJson = permissions !== undefined ? JSON.stringify(permissions) : existing.permissions;
  const userAvatar = avatar !== undefined ? avatar : existing.avatar;

  db.prepare(`
    UPDATE users
    SET full_name = ?, role = ?, phone = ?, hourly_rate = ?, avatar = ?, password_hash = ?, permissions = ?
    WHERE id = ?
  `).run(
    full_name || existing.full_name,
    role || existing.role,
    phone !== undefined ? phone : existing.phone,
    rate,
    userAvatar,
    hash,
    permsJson,
    userId
  );

  res.json({ success: true, message: 'Podaci o zaposlenom uspješno ažurirani.' });
});

app.delete('/api/users/:id', authenticateToken, requirePermission('manage_users', 'admin'), (req, res) => {
  const id = parseInt(req.params.id);
  if (id === req.user.id) {
    return res.status(400).json({ error: 'Ne možete obrisati vlastiti korisnički nalog.' });
  }

  const target = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  if (!target) return res.status(404).json({ error: 'Korisnik nije pronađen.' });

  // Sekretarica ne može obrisati administratora (direktora)
  if (target.role === 'admin' && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Samo direktor može obrisati administratorski nalog.' });
  }

  db.prepare('DELETE FROM users WHERE id = ?').run(id);
  res.json({ success: true, message: 'Korisnik uspješno obrisan.' });
});

// ==================== DASHBOARD STATS ====================
app.get('/api/dashboard/stats', authenticateToken, (req, res) => {
  const role = req.user.role;

  const totalClients = db.prepare("SELECT COUNT(*) as c FROM clients WHERE status = 'active'").get().c;
  const totalTasks = db.prepare('SELECT COUNT(*) as c FROM tasks').get().c;
  const doneTasks = db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status = 'done'").get().c;
  const pendingTasks = db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status IN ('todo', 'in_progress', 'blocked')").get().c;

  let myTasks = 0;
  if (role === 'worker') {
    myTasks = db.prepare("SELECT COUNT(*) as c FROM tasks WHERE assigned_user_id = ? AND status != 'done'").get(req.user.id).c;
  }

  // Work hours stats for the current month
  const currentMonth = new Date().toISOString().substring(0, 7);
  let hoursStats = null;

  if (role === 'worker') {
    const wh = db.prepare(`
      SELECT 
        COALESCE(SUM(hours + COALESCE(overtime_hours, 0)), 0) as totalHours,
        COALESCE(SUM(hours), 0) as regularHours,
        COALESCE(SUM(overtime_hours), 0) as totalOvertime,
        COALESCE(SUM((hours + COALESCE(overtime_hours, 0)) * hourly_rate), 0) as totalPay,
        COUNT(DISTINCT work_date) as daysWorked
      FROM work_hours
      WHERE user_id = ? AND strftime('%Y-%m', work_date) = ?
    `).get(req.user.id, currentMonth);

    hoursStats = {
      totalHours: wh.totalHours,
      regularHours: wh.regularHours,
      totalOvertime: wh.totalOvertime,
      totalPay: wh.totalPay,
      daysWorked: wh.daysWorked
    };
  } else {
    // Admin / Secretary
    const wh = db.prepare(`
      SELECT 
        COALESCE(SUM(hours + COALESCE(overtime_hours, 0)), 0) as totalHours,
        COALESCE(SUM(hours), 0) as regularHours,
        COALESCE(SUM(overtime_hours), 0) as totalOvertime,
        COALESCE(SUM((hours + COALESCE(overtime_hours, 0)) * hourly_rate), 0) as totalPay,
        COUNT(DISTINCT user_id) as activeWorkersCount
      FROM work_hours
      WHERE strftime('%Y-%m', work_date) = ?
    `).get(currentMonth);

    hoursStats = {
      totalHours: wh.totalHours,
      regularHours: wh.regularHours,
      totalOvertime: wh.totalOvertime,
      totalPay: wh.totalPay,
      activeWorkersCount: wh.activeWorkersCount
    };
  }

  let financeStats = null;
  // Radnik nema pristup finansijskim ciframa poslovanja!
  if (role === 'admin' || role === 'secretary') {
    const fin = db.prepare(`
      SELECT 
        COALESCE(SUM(total_amount), 0) as totalBilled,
        COALESCE(SUM(paid_amount), 0) as totalCollected,
        COALESCE(SUM(total_amount - paid_amount), 0) as totalDebt,
        (SELECT COUNT(DISTINCT client_id) FROM billing WHERE status != 'paid' AND (total_amount - paid_amount) > 0) as debtorsCount
      FROM billing
    `).get();

    const recentPayments = db.prepare(`
      SELECT p.*, c.name as client_name, u.full_name as recorder_name
      FROM payments p
      JOIN clients c ON p.client_id = c.id
      LEFT JOIN users u ON p.created_by_user_id = u.id
      ORDER BY p.payment_date DESC, p.id DESC
      LIMIT 5
    `).all();

    financeStats = {
      totalBilled: fin.totalBilled,
      totalCollected: fin.totalCollected,
      totalDebt: fin.totalDebt,
      debtorsCount: fin.debtorsCount,
      recentPayments
    };
  }

  res.json({
    totalClients,
    totalTasks,
    doneTasks,
    pendingTasks,
    myTasks,
    hoursStats,
    financeStats
  });
});

// ==================== CLIENTS ====================
app.get('/api/clients', authenticateToken, (req, res) => {
  const { search, status } = req.query;
  let sql = `
    SELECT c.*, 
      (SELECT COUNT(*) FROM tasks t WHERE t.client_id = c.id) as total_tasks,
      (SELECT COUNT(*) FROM tasks t WHERE t.client_id = c.id AND t.status = 'done') as completed_tasks,
      (SELECT COUNT(*) FROM tasks t WHERE t.client_id = c.id AND t.status != 'done') as pending_tasks
  `;

  if (req.user.role === 'admin' || req.user.role === 'secretary') {
    sql += `,
      COALESCE((SELECT SUM(b.total_amount) FROM billing b WHERE b.client_id = c.id), 0) as total_billed,
      COALESCE((SELECT SUM(b.paid_amount) FROM billing b WHERE b.client_id = c.id), 0) as total_paid,
      COALESCE((SELECT SUM(b.total_amount - b.paid_amount) FROM billing b WHERE b.client_id = c.id), 0) as total_debt
    `;
  }

  sql += ` FROM clients c WHERE 1=1 `;
  const params = [];

  if (search) {
    sql += ` AND (c.name LIKE ? OR c.contact_person LIKE ? OR c.city LIKE ? OR c.phone LIKE ?) `;
    const s = `%${search}%`;
    params.push(s, s, s, s);
  }

  if (status && status !== 'all') {
    sql += ` AND c.status = ? `;
    params.push(status);
  }

  sql += ` ORDER BY c.id DESC `;
  const clients = db.prepare(sql).all(...params);

  // Radnici NE SMIJU vidjeti ugovorene pakete, cijene i finansijske bilješke klijenata!
  if (req.user.role !== 'admin' && req.user.role !== 'secretary') {
    clients.forEach(c => {
      c.notes = null;
    });
  }

  res.json({ clients });
});

app.get('/api/clients/:id', authenticateToken, (req, res) => {
  const clientId = parseInt(req.params.id);
  const client = db.prepare('SELECT * FROM clients WHERE id = ?').get(clientId);
  if (!client) return res.status(404).json({ error: 'Klijent nije pronađen.' });

  // Radnici ne vide paket ili cijenu u detaljima klijenta
  if (req.user.role !== 'admin' && req.user.role !== 'secretary') {
    client.notes = null;
  }

  const tasks = db.prepare(`
    SELECT t.*, u.full_name as assigned_name
    FROM tasks t
    LEFT JOIN users u ON t.assigned_user_id = u.id
    WHERE t.client_id = ?
    ORDER BY CASE t.status WHEN 'todo' THEN 1 WHEN 'in_progress' THEN 2 WHEN 'blocked' THEN 3 WHEN 'done' THEN 4 END, t.due_date ASC
  `).all(clientId);

  let billing = [];
  let payments = [];
  let financeSummary = null;

  if (req.user.role === 'admin' || req.user.role === 'secretary') {
    billing = db.prepare('SELECT * FROM billing WHERE client_id = ? ORDER BY id DESC').all(clientId);
    payments = db.prepare(`
      SELECT p.*, u.full_name as recorder_name, b.title as billing_title
      FROM payments p
      LEFT JOIN users u ON p.created_by_user_id = u.id
      LEFT JOIN billing b ON p.billing_id = b.id
      WHERE p.client_id = ?
      ORDER BY p.payment_date DESC
    `).all(clientId);

    const totalBilled = billing.reduce((acc, b) => acc + b.total_amount, 0);
    const totalPaid = billing.reduce((acc, b) => acc + b.paid_amount, 0);
    financeSummary = {
      totalBilled,
      totalPaid,
      totalDebt: totalBilled - totalPaid
    };
  }

  res.json({
    client,
    tasks,
    billing,
    payments,
    financeSummary
  });
});

// Dodavanje i izmjena klijenata - provjerava permisiju 'manage_clients'
app.post('/api/clients', authenticateToken, requirePermission('manage_clients', 'admin', 'secretary'), (req, res) => {
  const { name, contact_person, phone, email, address, city, notes, monthly_package, payment_day_desc, currency } = req.body;
  if (!name || !name.trim()) {
    return res.status(400).json({ error: 'Naziv klijenta je obavezan.' });
  }

  const pkg = (monthly_package !== undefined && monthly_package !== '') ? parseFloat(monthly_package) : 0;
  const curr = currency || 'KM';
  const payDay = payment_day_desc ? payment_day_desc.trim() : null;

  const result = db.prepare(`
    INSERT INTO clients (name, contact_person, phone, email, address, city, notes, monthly_package, payment_day_desc, currency)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(name.trim(), contact_person || null, phone || null, email || null, address || null, city || null, notes || null, pkg, payDay, curr);

  const clientId = result.lastInsertRowid;

  // Ako je unesen mjesečni paket veći od 0, automatski dodaj i zaduženje paketa za tekući mjesec (2026-11)
  if (pkg > 0) {
    const curMonth = '2026-11';
    db.prepare(`
      INSERT INTO billing (client_id, title, total_amount, paid_amount, due_date, status, billing_type, month, notes)
      VALUES (?, ?, ?, 0.0, ?, 'unpaid', 'package', ?, ?)
    `).run(clientId, `Mjesečni paket (${curMonth})`, pkg, `${curMonth}-15`, curMonth, payDay || notes || null);
  }

  res.json({ success: true, id: clientId, message: 'Klijent uspješno kreiran.' });
});

function adjustClientDebtHelper(clientId, {
  month,
  monthly_package,
  payment_day_desc,
  paid_in_month,
  month_debt,
  previous_debt,
  total_debt,
  notes
}) {
  const targetMonth = (month && month !== 'all') ? month : '2026-11';

  // 1. Ažuriraj klijenta ako su poslani paket ili dan plaćanja ili napomena
  const clientUpdates = [];
  const clientParams = [];
  if (monthly_package !== undefined && monthly_package !== '') {
    clientUpdates.push('monthly_package = ?');
    clientParams.push(parseFloat(monthly_package));
  }
  if (payment_day_desc !== undefined) {
    clientUpdates.push('payment_day_desc = ?');
    clientParams.push(payment_day_desc ? payment_day_desc.trim() : null);
  }
  if (notes !== undefined && notes !== '') {
    clientUpdates.push('notes = ?');
    clientParams.push(notes.trim());
  }
  if (clientUpdates.length > 0) {
    clientParams.push(clientId);
    db.prepare(`UPDATE clients SET ${clientUpdates.join(', ')} WHERE id = ?`).run(...clientParams);
  }

  // 2. Ako je total_debt === 0 (Klijent je sve platio ili je dug izmiren)
  if (total_debt !== undefined && parseFloat(total_debt) === 0 && (previous_debt === undefined || parseFloat(previous_debt) === 0) && (month_debt === undefined || parseFloat(month_debt) === 0)) {
    db.prepare(`
      UPDATE billing 
      SET paid_amount = total_amount, status = 'paid'
      WHERE client_id = ? AND status != 'paid'
    `).run(clientId);
    return;
  }

  // 3. Ažuriraj paket račun za targetMonth
  const existingPkgBill = db.prepare(`
    SELECT * FROM billing 
    WHERE client_id = ? AND month = ? AND billing_type = 'package'
  `).get(clientId, targetMonth);

  const pkgTotal = (monthly_package !== undefined && monthly_package !== '') 
    ? parseFloat(monthly_package) 
    : (existingPkgBill ? existingPkgBill.total_amount : 0);

  let pkgPaid = existingPkgBill ? existingPkgBill.paid_amount : 0;
  if (paid_in_month !== undefined && paid_in_month !== '') {
    pkgPaid = parseFloat(paid_in_month);
  } else if (month_debt !== undefined && month_debt !== '') {
    pkgPaid = Math.max(0, pkgTotal - parseFloat(month_debt));
  }

  const pkgStatus = (pkgPaid >= pkgTotal && pkgTotal > 0) ? 'paid' : (pkgPaid > 0 ? 'partial' : 'unpaid');

  if (existingPkgBill) {
    db.prepare(`
      UPDATE billing 
      SET total_amount = ?, paid_amount = ?, status = ?, notes = COALESCE(?, notes)
      WHERE id = ?
    `).run(pkgTotal, pkgPaid, pkgStatus, notes || null, existingPkgBill.id);
  } else if (pkgTotal > 0) {
    db.prepare(`
      INSERT INTO billing (client_id, title, total_amount, paid_amount, due_date, status, billing_type, month, notes)
      VALUES (?, ?, ?, ?, ?, ?, 'package', ?, ?)
    `).run(clientId, `Mjesečni paket (${targetMonth})`, pkgTotal, pkgPaid, `${targetMonth}-15`, pkgStatus, targetMonth, notes || null);
  }

  // 4. Ažuriraj stari / zaostali dug (previous_debt)
  if (previous_debt !== undefined && previous_debt !== '') {
    const prevVal = parseFloat(previous_debt) || 0;
    const existingDebtBill = db.prepare(`
      SELECT * FROM billing 
      WHERE client_id = ? AND billing_type = 'debt'
      ORDER BY id DESC LIMIT 1
    `).get(clientId);

    if (existingDebtBill) {
      if (prevVal <= 0) {
        db.prepare(`UPDATE billing SET paid_amount = total_amount, status = 'paid' WHERE id = ?`).run(existingDebtBill.id);
      } else {
        db.prepare(`UPDATE billing SET total_amount = ?, paid_amount = 0, status = 'unpaid', notes = COALESCE(?, notes) WHERE id = ?`)
          .run(prevVal, notes || null, existingDebtBill.id);
      }
    } else if (prevVal > 0) {
      const debtMonth = (targetMonth === '2026-11') ? '2026-10' : targetMonth;
      db.prepare(`
        INSERT INTO billing (client_id, title, total_amount, paid_amount, due_date, status, billing_type, month, notes)
        VALUES (?, 'Zaostalo dugovanje / prethodni dug', ?, 0.0, ?, 'unpaid', 'debt', ?, ?)
      `).run(clientId, prevVal, `${debtMonth}-31`, debtMonth, notes || 'Zaostali dug');
    }
  }

  // 5. Ako je korisnik eksplicitno unio total_debt, a nije specificirao previous_debt
  if (total_debt !== undefined && total_debt !== '' && previous_debt === undefined) {
    const targetTotal = parseFloat(total_debt);
    const currentPkgDebt = Math.max(0, pkgTotal - pkgPaid);
    const neededDebt = Math.max(0, targetTotal - currentPkgDebt);

    const existingDebtBill = db.prepare(`
      SELECT * FROM billing 
      WHERE client_id = ? AND billing_type = 'debt'
      ORDER BY id DESC LIMIT 1
    `).get(clientId);

    if (existingDebtBill) {
      if (neededDebt <= 0) {
        db.prepare(`UPDATE billing SET paid_amount = total_amount, status = 'paid' WHERE id = ?`).run(existingDebtBill.id);
      } else {
        db.prepare(`UPDATE billing SET total_amount = ?, paid_amount = 0, status = 'unpaid', notes = COALESCE(?, notes) WHERE id = ?`)
          .run(neededDebt, notes || null, existingDebtBill.id);
      }
    } else if (neededDebt > 0) {
      const debtMonth = (targetMonth === '2026-11') ? '2026-10' : targetMonth;
      db.prepare(`
        INSERT INTO billing (client_id, title, total_amount, paid_amount, due_date, status, billing_type, month, notes)
        VALUES (?, 'Zaostalo dugovanje / prethodni dug', ?, 0.0, ?, 'unpaid', 'debt', ?, ?)
      `).run(clientId, neededDebt, `${debtMonth}-31`, debtMonth, notes || 'Dugovanje klijenta');
    }
  }
}

// Izmjena klijenta - provjerava permisiju 'manage_clients'
app.put('/api/clients/:id', authenticateToken, requirePermission('manage_clients', 'admin', 'secretary'), (req, res) => {
  const clientId = parseInt(req.params.id);
  const { name, contact_person, phone, email, address, city, notes, status, monthly_package, payment_day_desc, currency, target_debt, old_debt, debt_notes } = req.body;

  if (!name || !name.trim()) {
    return res.status(400).json({ error: 'Naziv klijenta je obavezan.' });
  }

  const current = db.prepare('SELECT * FROM clients WHERE id = ?').get(clientId);
  if (!current) {
    return res.status(404).json({ error: 'Klijent nije pronađen.' });
  }

  const updatedName = name.trim();
  const updatedContact = contact_person !== undefined ? contact_person : current.contact_person;
  const updatedPhone = phone !== undefined ? phone : current.phone;
  const updatedEmail = email !== undefined ? email : current.email;
  const updatedAddress = address !== undefined ? address : current.address;
  const updatedCity = city !== undefined ? city : current.city;
  const updatedNotes = notes !== undefined ? notes : current.notes;
  const updatedStatus = status || current.status || 'active';
  const updatedPackage = (monthly_package !== undefined && monthly_package !== '') ? parseFloat(monthly_package) : current.monthly_package;
  const updatedPayDay = payment_day_desc !== undefined ? payment_day_desc : current.payment_day_desc;
  const updatedCurrency = currency || current.currency || 'KM';

  db.prepare(`
    UPDATE clients 
    SET name = ?, contact_person = ?, phone = ?, email = ?, address = ?, city = ?, notes = ?, status = ?, monthly_package = ?, payment_day_desc = ?, currency = ?
    WHERE id = ?
  `).run(
    updatedName,
    updatedContact,
    updatedPhone,
    updatedEmail,
    updatedAddress,
    updatedCity,
    updatedNotes,
    updatedStatus,
    updatedPackage,
    updatedPayDay,
    updatedCurrency,
    clientId
  );

  // Ako se promijenila cijena paketa ili ako klijent ima račun za tekući mjesec, ažuriraj račun za 2026-11
  if (monthly_package !== undefined && monthly_package !== '') {
    const curMonth = '2026-11';
    const existingBill = db.prepare(`SELECT * FROM billing WHERE client_id = ? AND month = ? AND billing_type = 'package'`).get(clientId, curMonth);
    if (existingBill) {
      const newPaid = existingBill.paid_amount;
      const newStatus = newPaid >= updatedPackage ? 'paid' : (newPaid > 0 ? 'partial' : 'unpaid');
      db.prepare(`UPDATE billing SET total_amount = ?, status = ?, notes = ? WHERE id = ?`).run(updatedPackage, newStatus, updatedPayDay || existingBill.notes, existingBill.id);
    } else if (updatedPackage > 0) {
      db.prepare(`
        INSERT INTO billing (client_id, title, total_amount, paid_amount, due_date, status, billing_type, month, notes)
        VALUES (?, ?, ?, 0.0, ?, 'unpaid', 'package', ?, ?)
      `).run(clientId, `Mjesečni paket (${curMonth})`, updatedPackage, `${curMonth}-15`, curMonth, updatedPayDay || null);
    }
  }

  // Ako su unesene izmjene dugovanja (target_debt, old_debt, debt_notes)
  if (target_debt !== undefined || old_debt !== undefined || debt_notes !== undefined) {
    adjustClientDebtHelper(clientId, {
      total_debt: target_debt,
      previous_debt: old_debt,
      notes: debt_notes || notes,
      month: '2026-11'
    });
  }

  res.json({ success: true, message: 'Podaci o klijentu, cijeni i dugovanju uspješno ažurirani.' });
});

// Brisanje klijenta - provjerava permisiju 'delete_clients'
app.delete('/api/clients/:id', authenticateToken, requirePermission('delete_clients', 'admin'), (req, res) => {
  const clientId = parseInt(req.params.id);
  db.prepare('DELETE FROM clients WHERE id = ?').run(clientId);
  res.json({ success: true, message: 'Klijent uspješno obrisan.' });
});

// ==================== TASKS (PLAN I PROGRAM RADA) ====================
app.get('/api/tasks', authenticateToken, (req, res) => {
  const { status, client_id, assigned_user_id, task_type, search } = req.query;

  let sql = `
    SELECT t.*, c.name as client_name, c.phone as client_phone, c.city as client_city, u.full_name as assigned_name, u.avatar as assigned_avatar
    FROM tasks t
    JOIN clients c ON t.client_id = c.id
    LEFT JOIN users u ON t.assigned_user_id = u.id
    WHERE 1=1
  `;
  const params = [];

  if (status && status !== 'all') {
    sql += ` AND t.status = ? `;
    params.push(status);
  }

  if (client_id) {
    sql += ` AND t.client_id = ? `;
    params.push(parseInt(client_id));
  }

  if (assigned_user_id) {
    sql += ` AND t.assigned_user_id = ? `;
    params.push(parseInt(assigned_user_id));
  }

  if (task_type && task_type !== 'all') {
    sql += ` AND t.task_type = ? `;
    params.push(task_type);
  }

  if (search) {
    sql += ` AND (t.title LIKE ? OR t.description LIKE ? OR c.name LIKE ? OR t.task_type LIKE ?) `;
    const s = `%${search}%`;
    params.push(s, s, s, s);
  }

  sql += ` ORDER BY CASE t.status WHEN 'in_progress' THEN 1 WHEN 'todo' THEN 2 WHEN 'blocked' THEN 3 WHEN 'done' THEN 4 END, t.task_date DESC, t.due_date ASC `;
  const tasks = db.prepare(sql).all(...params);
  res.json({ tasks });
});

app.post('/api/tasks', authenticateToken, (req, res) => {
  const { client_id, title, description, priority, assigned_user_id, due_date, task_type } = req.body;
  if (!client_id || !title || !title.trim()) {
    return res.status(400).json({ error: 'Klijent i naziv zadatka su obavezni.' });
  }

  const today = new Date().toISOString().split('T')[0];
  const result = db.prepare(`
    INSERT INTO tasks (client_id, title, description, priority, assigned_user_id, due_date, status, task_type, task_date, created_at)
    VALUES (?, ?, ?, ?, ?, ?, 'todo', ?, ?, CURRENT_TIMESTAMP)
  `).run(
    parseInt(client_id),
    title.trim(),
    description || null,
    priority || 'medium',
    assigned_user_id ? parseInt(assigned_user_id) : null,
    due_date || null,
    task_type || null,
    today
  );

  const newTaskId = result.lastInsertRowid;

  // Create notification if assigned to a user
  if (assigned_user_id) {
    const client = db.prepare('SELECT name FROM clients WHERE id = ?').get(parseInt(client_id));
    const clientName = client ? client.name : 'Klijent';
    const typeLabel = task_type ? ` [${task_type}]` : '';

    db.prepare(`
      INSERT INTO notifications (user_id, task_id, title, message, type)
      VALUES (?, ?, ?, ?, 'task_assigned')
    `).run(
      parseInt(assigned_user_id),
      newTaskId,
      `🎯 Novi radni nalog${typeLabel}: ${clientName}`,
      `${req.user.full_name} vam je dodijelio/la zadatak: "${title.trim()}". ${due_date ? 'Rok: ' + due_date : ''}`
    );
  }

  res.json({ success: true, id: newTaskId, message: 'Zadatak u planu rada uspješno dodat.' });
});

// Ažuriranje statusa i detalja zadatka (podržava i PUT i PATCH)
const handleTaskUpdate = (req, res) => {
  const taskId = parseInt(req.params.id);
  const { title, description, status, priority, assigned_user_id, due_date, completed_note, task_type } = req.body;

  const currentTask = db.prepare('SELECT * FROM tasks WHERE id = ?').get(taskId);
  if (!currentTask) return res.status(404).json({ error: 'Zadatak nije pronađen.' });

  const oldStatus = currentTask.status;
  const newStatus = status || oldStatus;

  let completedAt = currentTask.completed_at;
  if (newStatus === 'done' && oldStatus !== 'done') {
    completedAt = new Date().toISOString();
  } else if (newStatus && newStatus !== 'done') {
    completedAt = null;
  }

  // Ako radnik preuzme zadatak (in_progress), a zadatak nema dodijeljenog radnika, automatski ga dodijeli njemu
  let finalAssignedUser = assigned_user_id !== undefined ? (assigned_user_id ? parseInt(assigned_user_id) : null) : currentTask.assigned_user_id;
  if (newStatus === 'in_progress' && !finalAssignedUser) {
    finalAssignedUser = req.user.id;
  }

  db.prepare(`
    UPDATE tasks 
    SET title = ?, description = ?, status = ?, priority = ?, assigned_user_id = ?, due_date = ?, completed_at = ?, completed_note = ?, task_type = ?
    WHERE id = ?
  `).run(
    title || currentTask.title,
    description !== undefined ? description : currentTask.description,
    newStatus,
    priority || currentTask.priority,
    finalAssignedUser,
    due_date !== undefined ? due_date : currentTask.due_date,
    completedAt,
    completed_note !== undefined ? completed_note : currentTask.completed_note,
    task_type !== undefined ? task_type : currentTask.task_type,
    taskId
  );

  const client = db.prepare('SELECT name FROM clients WHERE id = ?').get(currentTask.client_id);
  const clientName = client ? client.name : 'Klijent';
  const taskTitle = title || currentTask.title;

  // Tačno vrijeme i datum (npr. 11.11.2026. u 18:15h)
  const now = new Date();
  const dateFormatted = `${String(now.getDate()).padStart(2, '0')}.${String(now.getMonth() + 1).padStart(2, '0')}.${now.getFullYear()}.`;
  const timeFormatted = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

  // 1. Ako je zadatak dodijeljen drugom radniku, obavijesti ga
  if (finalAssignedUser && finalAssignedUser !== currentTask.assigned_user_id && finalAssignedUser !== req.user.id) {
    db.prepare(`
      INSERT INTO notifications (user_id, task_id, title, message, type)
      VALUES (?, ?, ?, ?, 'task_assigned')
    `).run(
      finalAssignedUser,
      taskId,
      `🎯 Zaduženi ste za zadatak: ${clientName}`,
      `${req.user.full_name} vam je proslijedio/la zadatak: "${taskTitle}".`
    );
  }

  // Pronađi sve menadžere (Emin - direktor i Amra - sekretarica/PM)
  const managers = db.prepare(`
    SELECT DISTINCT id, full_name, username FROM users 
    WHERE role IN ('admin', 'secretary') OR username IN ('emin', 'amra')
  `).all();

  // 2. Kada radnik klikne da je uzeo projekat ("U TOKU"):
  if (newStatus === 'in_progress' && oldStatus !== 'in_progress') {
    managers.forEach(m => {
      if (m.id !== req.user.id) {
        db.prepare(`
          INSERT INTO notifications (user_id, task_id, title, message, type)
          VALUES (?, ?, ?, ?, 'task_started')
        `).run(
          m.id,
          taskId,
          `⚡ Projekat u toku: ${clientName}`,
          `Radnik ${req.user.full_name} je preuzeo projekat "${taskTitle}" dana ${dateFormatted} u ${timeFormatted}h. Projekat je sada u toku.`
        );
      }
    });
  }

  // 3. Kada radnik završi projekat ("ZAVRŠENO"):
  if (newStatus === 'done' && oldStatus !== 'done') {
    const reportSuffix = (completed_note && completed_note.trim()) ? `\nIzvještaj o radu: "${completed_note.trim()}"` : '';
    managers.forEach(m => {
      if (m.id !== req.user.id) {
        db.prepare(`
          INSERT INTO notifications (user_id, task_id, title, message, type)
          VALUES (?, ?, ?, ?, 'task_completed')
        `).run(
          m.id,
          taskId,
          `✅ Projekat završen: ${clientName}`,
          `Radnik ${req.user.full_name} je uspješno završio projekat "${taskTitle}" dana ${dateFormatted} u ${timeFormatted}h.${reportSuffix}`
        );
      }
    });
  }

  res.json({ success: true, message: 'Zadatak uspješno ažuriran.', status: newStatus });
};

app.put('/api/tasks/:id', authenticateToken, handleTaskUpdate);
app.patch('/api/tasks/:id', authenticateToken, handleTaskUpdate);
app.put('/api/tasks/:id/status', authenticateToken, handleTaskUpdate);
app.patch('/api/tasks/:id/status', authenticateToken, handleTaskUpdate);

// ==================== NOTIFICATIONS API ====================
app.get('/api/notifications', authenticateToken, (req, res) => {
  const notifications = db.prepare(`
    SELECT n.*, t.title as task_title, t.task_type, t.client_id, c.name as client_name
    FROM notifications n
    LEFT JOIN tasks t ON n.task_id = t.id
    LEFT JOIN clients c ON t.client_id = c.id
    WHERE n.user_id = ?
    ORDER BY n.created_at DESC
    LIMIT 30
  `).all(req.user.id);

  const unreadCount = db.prepare(`
    SELECT COUNT(*) as c FROM notifications WHERE user_id = ? AND is_read = 0
  `).get(req.user.id).c;

  res.json({ notifications, unreadCount });
});

app.put('/api/notifications/:id/read', authenticateToken, (req, res) => {
  db.prepare('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?').run(parseInt(req.params.id), req.user.id);
  res.json({ success: true });
});

app.post('/api/notifications/read-all', authenticateToken, (req, res) => {
  db.prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?').run(req.user.id);
  res.json({ success: true });
});

app.delete('/api/tasks/:id', authenticateToken, (req, res) => {
  const taskId = parseInt(req.params.id);
  db.prepare('DELETE FROM tasks WHERE id = ?').run(taskId);
  res.json({ success: true, message: 'Zadatak uspješno obrisan.' });
});

// ==================== SEKRETARICA & FINANSIJE ====================
// Samo za Admina i Sekretaricu!

// 1. Pregled svih dužnika i stanja po klijentima
app.get('/api/finance/debtors', authenticateToken, requirePermission('view_finances', 'admin', 'secretary'), (req, res) => {
  const { filter } = req.query; // 'all', 'debtors_only', 'paid_only'

  let sql = `
    SELECT 
      c.id as client_id,
      c.name as client_name,
      c.contact_person,
      c.phone,
      c.email,
      c.city,
      COALESCE(SUM(b.total_amount), 0) as total_billed,
      COALESCE(SUM(b.paid_amount), 0) as total_paid,
      COALESCE(SUM(b.total_amount - b.paid_amount), 0) as total_debt,
      COUNT(b.id) as total_invoices,
      COUNT(CASE WHEN b.status != 'paid' AND (b.total_amount - b.paid_amount) > 0 THEN 1 END) as unpaid_invoices_count,
      MIN(CASE WHEN b.status != 'paid' AND (b.total_amount - b.paid_amount) > 0 THEN b.due_date END) as oldest_due_date
    FROM clients c
    LEFT JOIN billing b ON c.id = b.client_id
    GROUP BY c.id
  `;

  if (filter === 'debtors_only') {
    sql += ` HAVING total_debt > 0 ORDER BY total_debt DESC `;
  } else if (filter === 'paid_only') {
    sql += ` HAVING total_debt <= 0 AND total_billed > 0 ORDER BY c.name ASC `;
  } else {
    sql += ` ORDER BY total_debt DESC, c.name ASC `;
  }

  const debtors = db.prepare(sql).all();
  res.json({ debtors });
});

// 1b. Pregled klijenata i paketa po mjesecima (Ovaj mjesec / Prošli mjesec / Sve ukupno)
app.get('/api/finance/monthly-clients', authenticateToken, requirePermission('view_finances', 'admin', 'secretary'), (req, res) => {
  const targetMonth = req.query.month || '2026-11';
  const filter = req.query.filter || 'all'; // 'all', 'debtors_only', 'paid_only'
  const isAll = targetMonth === 'all';

  const clients = db.prepare(`
    SELECT id, name, contact_person, phone, email, city, monthly_package, payment_day_desc, currency
    FROM clients
    WHERE status = 'active' AND (monthly_package > 0 OR id IN (SELECT DISTINCT client_id FROM billing))
    ORDER BY name ASC
  `).all();

  const monthNames = {
    '2026-09': 'Septembar 2026',
    '2026-10': 'Oktobar 2026',
    '2026-11': 'Novembar 2026',
    '2026-12': 'Decembar 2026'
  };

  let rows = clients.map(c => {
    if (isAll) {
      const stats = db.prepare(`
        SELECT 
          COALESCE(SUM(total_amount), 0) as total_billed,
          COALESCE(SUM(paid_amount), 0) as total_paid,
          COALESCE(SUM(total_amount - paid_amount), 0) as total_debt
        FROM billing
        WHERE client_id = ?
      `).get(c.id);

      return {
        client_id: c.id,
        client_name: c.name,
        contact_person: c.contact_person,
        phone: c.phone,
        city: c.city,
        monthly_package: c.monthly_package || 0,
        currency: c.currency || 'KM',
        payment_day_desc: c.payment_day_desc || 'U toku mjeseca',
        paid_in_month: stats.total_paid,
        month_debt: stats.total_debt,
        previous_debt: 0,
        total_debt: stats.total_debt,
        status: stats.total_debt <= 0 ? 'paid' : (stats.total_paid > 0 ? 'partial' : 'unpaid'),
        notes: `Ukupno fakturisano: ${stats.total_billed.toFixed(2)} KM | Plaćeno: ${stats.total_paid.toFixed(2)} KM`
      };
    }

    // Specific Month calculation
    // 1. Package bill for this month
    const pkgBill = db.prepare(`
      SELECT * FROM billing 
      WHERE client_id = ? AND month = ? AND billing_type = 'package'
    `).get(c.id, targetMonth);

    // 2. Extra bills/debts created specifically in this month
    const extraBills = db.prepare(`
      SELECT * FROM billing 
      WHERE client_id = ? AND month = ? AND billing_type != 'package'
    `).all(c.id, targetMonth);

    const extraAmount = extraBills.reduce((s, b) => s + b.total_amount, 0);
    const extraPaid = extraBills.reduce((s, b) => s + b.paid_amount, 0);
    const extraDebt = extraBills.reduce((s, b) => s + (b.total_amount - b.paid_amount), 0);
    const extraNotes = extraBills.map(b => b.notes || b.title).join('; ');

    const pkgAmount = pkgBill ? pkgBill.total_amount : (c.monthly_package || 0);
    const pkgPaid = pkgBill ? pkgBill.paid_amount : 0;
    const pkgDebt = pkgBill ? Math.max(0, pkgBill.total_amount - pkgBill.paid_amount) : (c.monthly_package || 0);

    // 3. Payments recorded in this month
    const paySum = db.prepare(`
      SELECT COALESCE(SUM(amount), 0) as s FROM payments 
      WHERE client_id = ? AND strftime('%Y-%m', payment_date) = ?
    `).get(c.id, targetMonth).s;

    const paidInMonth = Math.max(pkgPaid + extraPaid, paySum);

    // 4. Carried-over previous debt from months before targetMonth
    const prevDebtRow = db.prepare(`
      SELECT COALESCE(SUM(total_amount - paid_amount), 0) as s 
      FROM billing 
      WHERE client_id = ? AND month < ? AND status != 'paid'
    `).get(c.id, targetMonth);
    const prevDebt = prevDebtRow ? prevDebtRow.s : 0;

    // Separate carried/extra debt from this month's regular package:
    const separateDebt = prevDebt + extraDebt;

    // Total actual debt for this client (Package debt from this month + separate debt):
    const totalDebt = pkgDebt + separateDebt;

    let status = 'unpaid';
    if (totalDebt <= 0) {
      status = 'paid';
    } else if (paidInMonth > 0) {
      status = 'partial';
    } else if (targetMonth >= '2026-11' && paidInMonth === 0) {
      status = 'pending';
    }

    let noteText = '';
    if (extraNotes) {
      noteText = extraNotes;
    } else if (pkgBill && pkgBill.notes) {
      noteText = pkgBill.notes;
    } else if (c.notes) {
      noteText = c.notes;
    }

    return {
      client_id: c.id,
      client_name: c.name,
      contact_person: c.contact_person,
      phone: c.phone,
      city: c.city,
      monthly_package: pkgAmount,
      currency: c.currency || 'KM',
      payment_day_desc: c.payment_day_desc || 'U toku mjeseca',
      paid_in_month: paidInMonth,
      month_debt: pkgDebt,
      previous_debt: separateDebt,
      total_debt: totalDebt,
      status,
      notes: noteText
    };
  });

  if (filter === 'debtors_only') {
    rows = rows.filter(r => r.total_debt > 0);
  } else if (filter === 'paid_only') {
    rows = rows.filter(r => r.total_debt <= 0);
  }

  const totalPackages = rows.reduce((s, r) => s + r.monthly_package, 0);
  const totalPaid = rows.reduce((s, r) => s + r.paid_in_month, 0);
  const totalMonthDebt = rows.reduce((s, r) => s + r.month_debt, 0);
  const totalPrevDebt = rows.reduce((s, r) => s + (r.previous_debt || 0), 0);
  const grandTotalDebt = rows.reduce((s, r) => s + r.total_debt, 0);

  res.json({
    month: targetMonth,
    monthLabel: monthNames[targetMonth] || targetMonth,
    isCurrentMonth: targetMonth === '2026-11',
    isAll,
    totals: {
      totalPackages,
      totalPaid,
      totalMonthDebt,
      totalPrevDebt,
      grandTotalDebt
    },
    clients: rows
  });
});

// 1c. Prilagođavanje i direktna izmjena dugovanja i paketa klijenta (Admin & Sekretarica)
app.post('/api/finance/clients/:id/adjust-debt', authenticateToken, requirePermission('manage_debts', 'admin', 'secretary'), (req, res) => {
  const clientId = parseInt(req.params.id);
  const client = db.prepare('SELECT * FROM clients WHERE id = ?').get(clientId);
  if (!client) {
    return res.status(404).json({ error: 'Klijent nije pronađen.' });
  }

  try {
    adjustClientDebtHelper(clientId, req.body);
    res.json({ success: true, message: 'Dugovanje i finansijski podaci klijenta su uspješno ažurirani.' });
  } catch (err) {
    res.status(500).json({ error: 'Greška pri ažuriranju dugovanja: ' + err.message });
  }
});

// 2. Pregled svih zaduženja/računa (ko je platio, ko nije)
app.get('/api/finance/invoices', authenticateToken, requirePermission('view_finances', 'admin', 'secretary'), (req, res) => {
  const { status, client_id, search } = req.query;

  let sql = `
    SELECT b.*, c.name as client_name, c.phone as client_phone, c.contact_person
    FROM billing b
    JOIN clients c ON b.client_id = c.id
    WHERE 1=1
  `;
  const params = [];

  if (status && status !== 'all') {
    sql += ` AND b.status = ? `;
    params.push(status);
  }

  if (client_id) {
    sql += ` AND b.client_id = ? `;
    params.push(parseInt(client_id));
  }

  if (search) {
    sql += ` AND (b.title LIKE ? OR b.invoice_number LIKE ? OR c.name LIKE ?) `;
    const s = `%${search}%`;
    params.push(s, s, s);
  }

  sql += ` ORDER BY CASE b.status WHEN 'unpaid' THEN 1 WHEN 'partial' THEN 2 WHEN 'paid' THEN 3 END, b.due_date ASC `;
  const invoices = db.prepare(sql).all(...params);
  res.json({ invoices });
});

// 3. Dodavanje novog zaduženja/fakture
app.post('/api/finance/invoices', authenticateToken, requirePermission('manage_invoices', 'admin', 'secretary'), (req, res) => {
  const { client_id, title, invoice_number, total_amount, paid_amount, due_date, status, notes, month, billing_type } = req.body;
  if (!client_id || !title || !total_amount) {
    return res.status(400).json({ error: 'Klijent, opis/naziv i ukupan iznos su obavezni.' });
  }

  const amount = parseFloat(total_amount);
  if (isNaN(amount) || amount <= 0) {
    return res.status(400).json({ error: 'Iznos mora biti validan pozitivan broj.' });
  }

  const paid = (paid_amount !== undefined && paid_amount !== '') ? parseFloat(paid_amount) : 0.0;
  let invStatus = status;
  if (!invStatus) {
    invStatus = paid >= amount ? 'paid' : (paid > 0 ? 'partial' : 'unpaid');
  }

  const result = db.prepare(`
    INSERT INTO billing (client_id, title, invoice_number, total_amount, paid_amount, due_date, status, notes, month, billing_type)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    parseInt(client_id), 
    title.trim(), 
    invoice_number ? invoice_number.trim() : null, 
    amount, 
    paid, 
    due_date || null, 
    invStatus, 
    notes || null,
    month || '2026-11',
    billing_type || 'service'
  );

  res.json({ success: true, id: result.lastInsertRowid, message: 'Zaduženje/račun uspješno evidentiran.' });
});

// Ažuriranje zaduženja/računa (Admin i Sekretarica)
app.put('/api/finance/invoices/:id', authenticateToken, requirePermission('manage_invoices', 'admin', 'secretary'), (req, res) => {
  const invoiceId = parseInt(req.params.id);
  const { title, invoice_number, total_amount, paid_amount, due_date, status, notes, month, billing_type } = req.body;

  const current = db.prepare('SELECT * FROM billing WHERE id = ?').get(invoiceId);
  if (!current) {
    return res.status(404).json({ error: 'Zaduženje/račun nije pronađen.' });
  }

  const newTitle = title !== undefined ? title.trim() : current.title;
  const newInvNum = invoice_number !== undefined ? (invoice_number ? invoice_number.trim() : null) : current.invoice_number;
  const newTotal = total_amount !== undefined ? parseFloat(total_amount) : current.total_amount;
  const newPaid = paid_amount !== undefined ? parseFloat(paid_amount) : current.paid_amount;
  const newDue = due_date !== undefined ? due_date : current.due_date;
  const newNotes = notes !== undefined ? notes : current.notes;
  const newMonth = month !== undefined ? month : current.month;
  const newType = billing_type !== undefined ? billing_type : current.billing_type;
  let newStatus = status;
  if (!newStatus) {
    newStatus = newPaid >= newTotal ? 'paid' : (newPaid > 0 ? 'partial' : 'unpaid');
  }

  db.prepare(`
    UPDATE billing 
    SET title = ?, invoice_number = ?, total_amount = ?, paid_amount = ?, due_date = ?, status = ?, notes = ?, month = ?, billing_type = ?
    WHERE id = ?
  `).run(newTitle, newInvNum, newTotal, newPaid, newDue, newStatus, newNotes, newMonth, newType, invoiceId);

  res.json({ success: true, message: 'Zaduženje/račun uspješno ažuriran.' });
});

// Brisanje zaduženja/računa (Admin i Sekretarica)
app.delete('/api/finance/invoices/:id', authenticateToken, requirePermission('manage_invoices', 'admin', 'secretary'), (req, res) => {
  const invoiceId = parseInt(req.params.id);
  db.prepare('DELETE FROM billing WHERE id = ?').run(invoiceId);
  res.json({ success: true, message: 'Zaduženje/račun uspješno obrisano.' });
});

// 4. Evidentiranje uplate (sekretarica unosi ko je platio)
app.post('/api/finance/payments', authenticateToken, requirePermission('record_payments', 'admin', 'secretary'), (req, res) => {
  const { client_id, billing_id, amount, payment_date, payment_method, note } = req.body;

  if (!client_id || !amount) {
    return res.status(400).json({ error: 'Klijent i iznos uplate su obavezni.' });
  }

  const payAmount = parseFloat(amount);
  if (isNaN(payAmount) || payAmount <= 0) {
    return res.status(400).json({ error: 'Iznos uplate mora biti veći od 0.' });
  }

  const pDate = payment_date || new Date().toISOString().split('T')[0];

  const runPayment = db.transaction(() => {
    // 1. Zapiši uplatu
    const pResult = db.prepare(`
      INSERT INTO payments (client_id, billing_id, amount, payment_date, payment_method, note, created_by_user_id)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(
      parseInt(client_id),
      billing_id ? parseInt(billing_id) : null,
      payAmount,
      pDate,
      payment_method || 'bank',
      note || null,
      req.user.id
    );

    // 2. Ako je vezano za specifičan račun, ažuriraj taj račun
    if (billing_id) {
      const bill = db.prepare('SELECT * FROM billing WHERE id = ?').get(parseInt(billing_id));
      if (bill) {
        const newPaid = bill.paid_amount + payAmount;
        let newStatus = 'partial';
        if (newPaid >= bill.total_amount) {
          newStatus = 'paid';
        } else if (newPaid <= 0) {
          newStatus = 'unpaid';
        }
        db.prepare(`UPDATE billing SET paid_amount = ?, status = ? WHERE id = ?`).run(newPaid, newStatus, bill.id);
      }
    } else {
      // Ako nije odabran specifičan račun, automatski raspodijeli na najstarije neplaćene račune tog klijenta!
      let remainingPayment = payAmount;
      const unpaidBills = db.prepare(`
        SELECT * FROM billing 
        WHERE client_id = ? AND status != 'paid' 
        ORDER BY due_date ASC, id ASC
      `).all(parseInt(client_id));

      for (const bill of unpaidBills) {
        if (remainingPayment <= 0) break;
        const dueOnBill = bill.total_amount - bill.paid_amount;
        const toPay = Math.min(remainingPayment, dueOnBill);
        const newPaid = bill.paid_amount + toPay;
        const newStatus = newPaid >= bill.total_amount ? 'paid' : 'partial';

        db.prepare(`UPDATE billing SET paid_amount = ?, status = ? WHERE id = ?`).run(newPaid, newStatus, bill.id);
        remainingPayment -= toPay;
      }
    }

    return pResult.lastInsertRowid;
  });

  try {
    const paymentId = runPayment();
    res.json({ success: true, id: paymentId, message: 'Uplata je uspješno zabilježena i stanje klijenta je ažurirano.' });
  } catch (err) {
    res.status(500).json({ error: 'Greška pri evidentiranju uplate: ' + err.message });
  }
});

// 5. Istorija svih uplata
app.get('/api/finance/payments', authenticateToken, requirePermission('view_finances', 'admin', 'secretary'), (req, res) => {
  const { client_id } = req.query;
  let sql = `
    SELECT p.*, c.name as client_name, u.full_name as recorder_name, b.title as billing_title, b.invoice_number
    FROM payments p
    JOIN clients c ON p.client_id = c.id
    LEFT JOIN users u ON p.created_by_user_id = u.id
    LEFT JOIN billing b ON p.billing_id = b.id
    WHERE 1=1
  `;
  const params = [];

  if (client_id) {
    sql += ` AND p.client_id = ? `;
    params.push(parseInt(client_id));
  }

  sql += ` ORDER BY p.payment_date DESC, p.id DESC `;
  const payments = db.prepare(sql).all(...params);
  res.json({ payments });
});

// ==================== MJESEČNI RASHODI & BILANS (ADMIN & SEKRETARICA SAMO) ====================

// 6. Lista rashoda po mjesecu (npr. '2026-10')
app.get('/api/finance/expenses', authenticateToken, requirePermission('view_finances', 'admin', 'secretary'), (req, res) => {
  const month = req.query.month || new Date().toISOString().substring(0, 7);

  const expenses = db.prepare(`
    SELECT e.*, u.full_name as creator_name
    FROM expenses e
    LEFT JOIN users u ON e.created_by_user_id = u.id
    WHERE e.month = ?
    ORDER BY e.item_order ASC, e.id ASC
  `).all(month);

  const totals = db.prepare(`
    SELECT 
      COALESCE(SUM(amount), 0) as totalExpenses,
      COALESCE(SUM(CASE WHEN payment_method = 'gotovina' THEN amount ELSE 0 END), 0) as totalCash,
      COALESCE(SUM(CASE WHEN payment_method = 'ziralno' THEN amount ELSE 0 END), 0) as totalBank,
      COALESCE(SUM(CASE WHEN payment_method NOT IN ('gotovina', 'ziralno') THEN amount ELSE 0 END), 0) as totalOther
    FROM expenses
    WHERE month = ?
  `).get(month);

  let meta = db.prepare('SELECT * FROM monthly_finance_meta WHERE month = ?').get(month);
  if (!meta) {
    meta = {
      month,
      cash_withdrawn: 0,
      opening_cash_balance: 0,
      opening_bank_balance: 0,
      notes: ''
    };
  }

  res.json({
    month,
    expenses,
    totals,
    meta
  });
});

// 7. Dodavanje novog troška/rashoda
app.post('/api/finance/expenses', authenticateToken, requirePermission('manage_expenses', 'admin', 'secretary'), (req, res) => {
  const { month, title, amount, payment_method, payment_date_desc, notes, item_order, category } = req.body;
  if (!title || amount === undefined || amount === null) {
    return res.status(400).json({ error: 'Naziv troška i iznos su obavezni.' });
  }

  const expMonth = month || new Date().toISOString().substring(0, 7);
  const expAmount = parseFloat(amount) || 0;
  const method = payment_method === 'ziralno' ? 'ziralno' : (payment_method === 'ostalo' ? 'ostalo' : 'gotovina');

  let order = parseInt(item_order);
  if (isNaN(order)) {
    const maxOrder = db.prepare('SELECT MAX(item_order) as m FROM expenses WHERE month = ?').get(expMonth).m;
    order = (maxOrder || 0) + 1;
  }

  const result = db.prepare(`
    INSERT INTO expenses (month, item_order, title, payment_date_desc, amount, payment_method, notes, category, is_paid, created_by_user_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
  `).run(expMonth, order, title.trim(), payment_date_desc ? payment_date_desc.trim() : null, expAmount, method, notes ? notes.trim() : null, category || 'opste', req.user.id);

  res.json({ success: true, id: result.lastInsertRowid, message: 'Trošak uspješno evidentiran.' });
});

// 8. Izmjena postojećeg troška
app.put('/api/finance/expenses/:id', authenticateToken, requirePermission('manage_expenses', 'admin', 'secretary'), (req, res) => {
  const { id } = req.params;
  const { title, amount, payment_method, payment_date_desc, notes, item_order, category, is_paid } = req.body;

  const current = db.prepare('SELECT * FROM expenses WHERE id = ?').get(id);
  if (!current) {
    return res.status(404).json({ error: 'Trošak nije pronađen.' });
  }

  const updatedTitle = title !== undefined ? title.trim() : current.title;
  const updatedAmount = amount !== undefined ? parseFloat(amount) : current.amount;
  const updatedMethod = payment_method !== undefined ? payment_method : current.payment_method;
  const updatedDateDesc = payment_date_desc !== undefined ? payment_date_desc : current.payment_date_desc;
  const updatedNotes = notes !== undefined ? notes : current.notes;
  const updatedOrder = item_order !== undefined ? parseInt(item_order) : current.item_order;
  const updatedCategory = category !== undefined ? category : current.category;
  const updatedPaid = is_paid !== undefined ? (is_paid ? 1 : 0) : current.is_paid;

  db.prepare(`
    UPDATE expenses 
    SET title = ?, amount = ?, payment_method = ?, payment_date_desc = ?, notes = ?, item_order = ?, category = ?, is_paid = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(updatedTitle, updatedAmount, updatedMethod, updatedDateDesc, updatedNotes, updatedOrder, updatedCategory, updatedPaid, id);

  res.json({ success: true, message: 'Trošak uspješno ažuriran.' });
});

// 9. Brisanje troška
app.delete('/api/finance/expenses/:id', authenticateToken, requirePermission('manage_expenses', 'admin', 'secretary'), (req, res) => {
  const { id } = req.params;
  const result = db.prepare('DELETE FROM expenses WHERE id = ?').run(id);
  if (result.changes === 0) {
    return res.status(404).json({ error: 'Trošak nije pronađen.' });
  }
  res.json({ success: true, message: 'Trošak uspješno obrisan.' });
});

// 10. Mjesečni bilans (Prihodi, Rashodi, Stanje gotovine u kasi, Stanje na računu, Dobit)
app.get('/api/finance/monthly-summary', authenticateToken, requirePermission('view_finances', 'admin', 'secretary'), (req, res) => {
  const month = req.query.month || new Date().toISOString().substring(0, 7);

  // 1. Prihodi (iz payments za taj mjesec)
  const incomeStats = db.prepare(`
    SELECT 
      COALESCE(SUM(amount), 0) as totalIncome,
      COALESCE(SUM(CASE WHEN payment_method = 'cash' THEN amount ELSE 0 END), 0) as cashIncome,
      COALESCE(SUM(CASE WHEN payment_method != 'cash' THEN amount ELSE 0 END), 0) as bankIncome,
      COUNT(id) as paymentsCount
    FROM payments
    WHERE strftime('%Y-%m', payment_date) = ?
  `).get(month);

  // 2. Rashodi (iz expenses za taj mjesec)
  const expenseStats = db.prepare(`
    SELECT 
      COALESCE(SUM(amount), 0) as totalExpenses,
      COALESCE(SUM(CASE WHEN payment_method = 'gotovina' THEN amount ELSE 0 END), 0) as cashExpenses,
      COALESCE(SUM(CASE WHEN payment_method = 'ziralno' THEN amount ELSE 0 END), 0) as bankExpenses,
      COALESCE(SUM(CASE WHEN payment_method NOT IN ('gotovina', 'ziralno') THEN amount ELSE 0 END), 0) as otherExpenses,
      COUNT(id) as expensesCount
    FROM expenses
    WHERE month = ?
  `).get(month);

  // 3. Meta (dignuto sa računa, početna stanja)
  let meta = db.prepare('SELECT * FROM monthly_finance_meta WHERE month = ?').get(month);
  if (!meta) {
    meta = {
      month,
      cash_withdrawn: 0,
      opening_cash_balance: 0,
      opening_bank_balance: 0,
      notes: ''
    };
  }

  // Izračun gotovina i žirala stanja:
  // Kasa gotovina = početno + uplate u gotovini + dignuto sa računa u keš - troškovi u gotovini
  const cashBalance = (meta.opening_cash_balance || 0) + (incomeStats.cashIncome || 0) + (meta.cash_withdrawn || 0) - (expenseStats.cashExpenses || 0);
  // Žiro račun = početno + uplate na račun - dignuto sa računa u keš - žiralni troškovi
  const bankBalance = (meta.opening_bank_balance || 0) + (incomeStats.bankIncome || 0) - (meta.cash_withdrawn || 0) - (expenseStats.bankExpenses || 0);
  // Ukupno stanje / Čista zarada (Profit) = Ukupni prihodi - Ukupni rashodi
  const netProfit = (incomeStats.totalIncome || 0) - (expenseStats.totalExpenses || 0);
  // Ukupan novčani saldo = Gotovina saldo + Žiralno saldo
  const totalAvailableFunds = cashBalance + bankBalance;

  // 4. Potraživanja (Ko nama duguje)
  const receivables = db.prepare(`
    SELECT 
      c.id, c.name, 
      COALESCE(SUM(b.total_amount - b.paid_amount), 0) as debt,
      b.notes as note
    FROM clients c
    JOIN billing b ON c.id = b.client_id
    WHERE b.status != 'paid' AND (b.total_amount - b.paid_amount) > 0
    GROUP BY c.id
    ORDER BY debt DESC
  `).all();
  const totalReceivables = receivables.reduce((sum, r) => sum + r.debt, 0);

  // 5. Naša dugovanja / Obaveze ("DUGUJEMO")
  const liabilities = db.prepare(`
    SELECT * FROM company_liabilities WHERE month = ? ORDER BY id ASC
  `).all(month);
  const totalLiabilities = liabilities.reduce((sum, l) => sum + (l.amount - (l.paid_amount || 0)), 0);

  res.json({
    month,
    income: {
      total: incomeStats.totalIncome,
      cash: incomeStats.cashIncome,
      bank: incomeStats.bankIncome,
      count: incomeStats.paymentsCount
    },
    expenses: {
      total: expenseStats.totalExpenses,
      cash: expenseStats.cashExpenses,
      bank: expenseStats.bankExpenses,
      other: expenseStats.otherExpenses,
      count: expenseStats.expensesCount
    },
    meta,
    balances: {
      cashBalance,
      bankBalance,
      netProfit,
      totalAvailableFunds
    },
    receivables: {
      total: totalReceivables,
      list: receivables
    },
    liabilities: {
      total: totalLiabilities,
      list: liabilities
    }
  });
});

// 11. Ažuriranje mjesečnih meta podataka (dignuto sa računa, početno stanje)
app.put('/api/finance/monthly-meta/:month', authenticateToken, requirePermission('view_cash_meta', 'admin', 'secretary'), (req, res) => {
  const { month } = req.params;
  const { cash_withdrawn, opening_cash_balance, opening_bank_balance, notes } = req.body;

  db.prepare(`
    INSERT INTO monthly_finance_meta (month, cash_withdrawn, opening_cash_balance, opening_bank_balance, notes, updated_at)
    VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(month) DO UPDATE SET
      cash_withdrawn = excluded.cash_withdrawn,
      opening_cash_balance = excluded.opening_cash_balance,
      opening_bank_balance = excluded.opening_bank_balance,
      notes = excluded.notes,
      updated_at = CURRENT_TIMESTAMP
  `).run(
    month,
    parseFloat(cash_withdrawn) || 0,
    parseFloat(opening_cash_balance) || 0,
    parseFloat(opening_bank_balance) || 0,
    notes ? notes.trim() : null
  );

  res.json({ success: true, message: 'Finansijski parametri uspješno sačuvani.' });
});

// 12. Obaveze firme (Dugujemo dobavljačima / saradnicima)
app.get('/api/finance/liabilities', authenticateToken, requirePermission('view_finances', 'admin', 'secretary'), (req, res) => {
  const month = req.query.month || new Date().toISOString().substring(0, 7);
  const liabilities = db.prepare('SELECT * FROM company_liabilities WHERE month = ? ORDER BY id ASC').all(month);
  res.json({ liabilities });
});

app.post('/api/finance/liabilities', authenticateToken, requirePermission('manage_expenses', 'admin', 'secretary'), (req, res) => {
  const { month, creditor_name, description, amount, due_date, notes } = req.body;
  if (!creditor_name || !amount) {
    return res.status(400).json({ error: 'Naziv povjerioca i iznos su obavezni.' });
  }

  const libMonth = month || new Date().toISOString().substring(0, 7);
  const result = db.prepare(`
    INSERT INTO company_liabilities (month, creditor_name, description, amount, paid_amount, due_date, status, notes)
    VALUES (?, ?, ?, ?, 0, ?, 'unpaid', ?)
  `).run(libMonth, creditor_name.trim(), description ? description.trim() : null, parseFloat(amount) || 0, due_date || null, notes ? notes.trim() : null);

  res.json({ success: true, id: result.lastInsertRowid, message: 'Obaveza uspješno evidentirana.' });
});

app.put('/api/finance/liabilities/:id', authenticateToken, requirePermission('manage_expenses', 'admin', 'secretary'), (req, res) => {
  const { id } = req.params;
  const { creditor_name, description, amount, paid_amount, due_date, status, notes } = req.body;

  const current = db.prepare('SELECT * FROM company_liabilities WHERE id = ?').get(id);
  if (!current) return res.status(404).json({ error: 'Obaveza nije pronađena.' });

  const pAmount = paid_amount !== undefined ? parseFloat(paid_amount) : current.paid_amount;
  const totAmount = amount !== undefined ? parseFloat(amount) : current.amount;
  let newStatus = status || current.status;
  if (pAmount >= totAmount) newStatus = 'paid';
  else if (pAmount > 0) newStatus = 'partial';

  db.prepare(`
    UPDATE company_liabilities 
    SET creditor_name = ?, description = ?, amount = ?, paid_amount = ?, due_date = ?, status = ?, notes = ?
    WHERE id = ?
  `).run(
    creditor_name !== undefined ? creditor_name.trim() : current.creditor_name,
    description !== undefined ? description : current.description,
    totAmount,
    pAmount,
    due_date !== undefined ? due_date : current.due_date,
    newStatus,
    notes !== undefined ? notes : current.notes,
    id
  );

  res.json({ success: true, message: 'Obaveza uspješno ažurirana.' });
});

app.delete('/api/finance/liabilities/:id', authenticateToken, requirePermission('manage_expenses', 'admin', 'secretary'), (req, res) => {
  const { id } = req.params;
  db.prepare('DELETE FROM company_liabilities WHERE id = ?').run(id);
  res.json({ success: true, message: 'Obaveza uspješno obrisana.' });
});

// ==================== ŠTAMPARIJA & PRINT USLUGE ====================

// Pomoćna funkcija za normalizaciju datuma štampe (npr. "16.10." ili "16.10.2026" u "2026-10-16")
function normalizePrintDate(inputDate) {
  if (!inputDate) return new Date().toISOString().split('T')[0];
  const str = String(inputDate).trim();
  const match = str.match(/^(\d{1,2})\.(\d{1,2})\.?(\d{2,4})?$/);
  if (match) {
    const day = match[1].padStart(2, '0');
    const month = match[2].padStart(2, '0');
    let year = match[3] || '2026';
    if (year.length === 2) year = '20' + year;
    return `${year}-${month}-${day}`;
  }
  if (/^\d{4}-\d{2}-\d{2}$/.test(str)) {
    return str;
  }
  return str;
}

// 1. Spisak svih štamparskih usluga sa statistikom za isplatu štampariji
app.get('/api/print-services', authenticateToken, (req, res) => {
  const { status, search, month } = req.query;

  let sql = `
    SELECT p.*, 
      c.name as resolved_client_name, c.phone as client_phone
    FROM print_services p
    LEFT JOIN clients c ON p.client_id = c.id
    WHERE 1=1
  `;
  const params = [];

  if (status && status !== 'all') {
    if (status === 'done' || status === 'Završeno') {
      sql += ` AND (p.status = 'done' OR p.status = 'Završeno') `;
    } else if (status === 'in_progress' || status === 'U toku') {
      sql += ` AND (p.status = 'in_progress' OR p.status = 'U toku') `;
    } else {
      sql += ` AND p.status = ? `;
      params.push(status);
    }
  }

  if (month && month !== 'all') {
    sql += ` AND strftime('%Y-%m', p.order_date) = ? `;
    params.push(month);
  }

  if (search) {
    sql += ` AND (p.client_name LIKE ? OR p.service_type LIKE ? OR p.description LIKE ? OR p.executor LIKE ?) `;
    const s = `%${search}%`;
    params.push(s, s, s, s);
  }

  sql += ` ORDER BY p.order_date DESC, p.id DESC `;
  const printServices = db.prepare(sql).all(...params);

  // Stats filtrirane prema odabranom mjesecu i pretrazi
  let statsSql = `
    SELECT 
      COUNT(*) as totalCount,
      COUNT(CASE WHEN status IN ('done', 'Završeno') THEN 1 END) as doneCount,
      COUNT(CASE WHEN status IN ('in_progress', 'U toku') THEN 1 END) as inProgressCount,
      COALESCE(SUM(price), 0) as totalToPay
    FROM print_services p
    WHERE 1=1
  `;
  const statsParams = [];
  if (month && month !== 'all') {
    statsSql += ` AND strftime('%Y-%m', p.order_date) = ? `;
    statsParams.push(month);
  }
  if (search) {
    statsSql += ` AND (p.client_name LIKE ? OR p.service_type LIKE ? OR p.description LIKE ? OR p.executor LIKE ?) `;
    const s = `%${search}%`;
    statsParams.push(s, s, s, s);
  }
  const stats = db.prepare(statsSql).get(...statsParams);

  // Dostupni mjeseci za padajući meni
  const availableMonths = db.prepare(`
    SELECT DISTINCT strftime('%Y-%m', order_date) as m 
    FROM print_services 
    WHERE order_date IS NOT NULL 
    ORDER BY m DESC
  `).all().map(r => r.m).filter(Boolean);

  res.json({ printServices, stats, availableMonths });
});

// 2. Dodavanje nove štamparske usluge (šta je štampano i iznos za isplatu štampariji)
app.post('/api/print-services', authenticateToken, requirePermission('manage_print', 'admin', 'secretary'), (req, res) => {
  const { order_date, client_id, client_name, service_type, description, executor, status, price, notes, responsible_person } = req.body;

  if (!order_date || !client_name || !service_type) {
    return res.status(400).json({ error: 'Datum, naziv klijenta i vrsta usluge su obavezni.' });
  }

  const pDate = normalizePrintDate(order_date);
  const pPrice = parseFloat(price) || 0;
  const pStatus = (status === 'in_progress' || status === 'U toku') ? 'in_progress' : ((status === 'cancelled' || status === 'Otkazano') ? 'cancelled' : 'done');

  const result = db.prepare(`
    INSERT INTO print_services (order_date, client_id, client_name, service_type, description, executor, status, price, paid_amount, payment_status, notes, responsible_person)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 'unpaid', ?, ?)
  `).run(
    pDate,
    client_id ? parseInt(client_id) : null,
    client_name.trim(),
    service_type.trim(),
    description ? description.trim() : null,
    executor ? executor.trim() : 'Misija',
    pStatus,
    pPrice,
    notes ? notes.trim() : null,
    responsible_person ? responsible_person.trim() : (req.user ? req.user.full_name : 'Emin / Amra')
  );

  res.json({ success: true, id: result.lastInsertRowid, message: 'Nalog za štampu uspješno zabilježen!' });
});

// 3. Ažuriranje štamparske usluge
app.put('/api/print-services/:id', authenticateToken, requirePermission('manage_print', 'admin', 'secretary'), (req, res) => {
  const { id } = req.params;
  const { order_date, client_id, client_name, service_type, description, executor, status, price, notes, responsible_person } = req.body;

  const current = db.prepare('SELECT * FROM print_services WHERE id = ?').get(id);
  if (!current) {
    return res.status(404).json({ error: 'Usluga štampe nije pronađena.' });
  }

  const updatedDate = order_date ? normalizePrintDate(order_date) : current.order_date;
  const updatedClientId = client_id !== undefined ? (client_id ? parseInt(client_id) : null) : current.client_id;
  const updatedClientName = client_name !== undefined ? client_name.trim() : current.client_name;
  const updatedService = service_type !== undefined ? service_type.trim() : current.service_type;
  const updatedDesc = description !== undefined ? description : current.description;
  const updatedExecutor = executor !== undefined ? executor : current.executor;
  let updatedStatus = current.status;
  if (status !== undefined) {
    updatedStatus = (status === 'in_progress' || status === 'U toku') ? 'in_progress' : ((status === 'cancelled' || status === 'Otkazano') ? 'cancelled' : 'done');
  }
  const updatedPrice = price !== undefined ? parseFloat(price) : current.price;
  const updatedNotes = notes !== undefined ? notes : current.notes;
  const updatedResp = responsible_person !== undefined ? responsible_person : current.responsible_person;

  db.prepare(`
    UPDATE print_services 
    SET order_date = ?, client_id = ?, client_name = ?, service_type = ?, description = ?, executor = ?, status = ?, price = ?, notes = ?, responsible_person = ?
    WHERE id = ?
  `).run(
    updatedDate,
    updatedClientId,
    updatedClientName,
    updatedService,
    updatedDesc,
    updatedExecutor,
    updatedStatus,
    updatedPrice,
    updatedNotes,
    updatedResp,
    id
  );

  res.json({ success: true, message: 'Nalog štampe uspješno ažuriran.' });
});

// 4. Brisanje štamparske usluge
app.delete('/api/print-services/:id', authenticateToken, requirePermission('manage_print', 'admin', 'secretary'), (req, res) => {
  const { id } = req.params;
  const result = db.prepare('DELETE FROM print_services WHERE id = ?').run(id);
  if (result.changes === 0) {
    return res.status(404).json({ error: 'Usluga štampe nije pronađena.' });
  }
  res.json({ success: true, message: 'Usluga štampe uspješno obrisana.' });
});

// ==================== WORK HOURS (RADNI SATI & DNEVNICE) ====================

// 1. Spisak radnih sati (filtrirano po radniku, klijentu, datumu ili mjesecu)
app.get('/api/work-hours', authenticateToken, (req, res) => {
  const { user_id, client_id, month, from_date, to_date } = req.query;

  let sql = `
    SELECT 
      w.*,
      u.full_name as user_full_name,
      u.role as user_role,
      u.avatar as user_avatar,
      c.name as client_name,
      t.title as task_title,
      ROUND((w.hours + COALESCE(w.overtime_hours, 0)) * w.hourly_rate, 2) as calculated_pay,
      ROUND(w.hours + COALESCE(w.overtime_hours, 0), 2) as total_entry_hours
    FROM work_hours w
    JOIN users u ON w.user_id = u.id
    LEFT JOIN clients c ON w.client_id = c.id
    LEFT JOIN tasks t ON w.task_id = t.id
    WHERE 1=1
  `;
  const params = [];

  // Radnik smije vidjeti isključivo svoje radne sate!
  if (req.user.role === 'worker') {
    sql += ` AND w.user_id = ? `;
    params.push(req.user.id);
  } else if (user_id) {
    sql += ` AND w.user_id = ? `;
    params.push(parseInt(user_id));
  }

  if (client_id) {
    sql += ` AND w.client_id = ? `;
    params.push(parseInt(client_id));
  }

  if (month) {
    sql += ` AND strftime('%Y-%m', w.work_date) = ? `;
    params.push(month);
  }

  if (from_date) {
    sql += ` AND w.work_date >= ? `;
    params.push(from_date);
  }

  if (to_date) {
    sql += ` AND w.work_date <= ? `;
    params.push(to_date);
  }

  sql += ` ORDER BY w.work_date DESC, w.id DESC `;
  const entries = db.prepare(sql).all(...params);

  const totalRegularHours = entries.reduce((acc, e) => acc + (parseFloat(e.hours) || 0), 0);
  const totalOvertime = entries.reduce((acc, e) => acc + (parseFloat(e.overtime_hours) || 0), 0);
  const totalHours = totalRegularHours + totalOvertime;
  const totalPay = entries.reduce((acc, e) => acc + (parseFloat(e.calculated_pay) || 0), 0);

  res.json({
    entries,
    summary: {
      totalHours: Math.round(totalHours * 100) / 100,
      totalRegularHours: Math.round(totalRegularHours * 100) / 100,
      totalOvertime: Math.round(totalOvertime * 100) / 100,
      totalPay: Math.round(totalPay * 100) / 100,
      count: entries.length
    }
  });
});

// 2. Mjesečni zbirni obračun plata / dnevnica
app.get('/api/work-hours/payroll-report', authenticateToken, requirePermission('view_payroll', 'admin', 'secretary'), (req, res) => {
  const month = req.query.month || new Date().toISOString().substring(0, 7);

  const workers = db.prepare(`
    SELECT 
      u.id as user_id, 
      u.full_name, 
      u.role, 
      u.phone, 
      u.hourly_rate,
      u.avatar,
      COALESCE(SUM(w.hours), 0) as regular_hours,
      COALESCE(SUM(w.overtime_hours), 0) as total_overtime,
      COALESCE(SUM(w.hours + COALESCE(w.overtime_hours, 0)), 0) as total_hours,
      COALESCE(SUM((w.hours + COALESCE(w.overtime_hours, 0)) * w.hourly_rate), 0) as total_pay,
      COUNT(DISTINCT w.work_date) as days_worked,
      COUNT(w.id) as entries_count
    FROM users u
    LEFT JOIN work_hours w ON u.id = w.user_id AND strftime('%Y-%m', w.work_date) = ?
    WHERE u.role IN ('worker', 'secretary')
    GROUP BY u.id
    ORDER BY u.full_name ASC
  `).all(month);

  const grandTotalHours = workers.reduce((acc, w) => acc + (w.total_hours || 0), 0);
  const grandTotalPay = workers.reduce((acc, w) => acc + (w.total_pay || 0), 0);

  res.json({
    month,
    workers,
    grandTotalHours: Math.round(grandTotalHours * 100) / 100,
    grandTotalPay: Math.round(grandTotalPay * 100) / 100
  });
});

// 3. Unos novih radnih sati (radnik unosi za sebe, sekretarica/direktor mogu za bilo koga)
app.post('/api/work-hours', authenticateToken, (req, res) => {
  let { user_id, client_id, task_id, work_date, hours, start_time, end_time, overtime_hours, description, hourly_rate } = req.body;

  let targetUserId = req.user.id;
  if (req.user.role === 'admin' || req.user.role === 'secretary') {
    if (user_id) targetUserId = parseInt(user_id);
  }

  const numHours = parseFloat(hours);
  if (isNaN(numHours) || numHours <= 0) {
    return res.status(400).json({ error: 'Broj radnih sati mora biti veći od 0.' });
  }

  const workerUser = db.prepare('SELECT hourly_rate FROM users WHERE id = ?').get(targetUserId);
  let rate = workerUser ? (workerUser.hourly_rate || 0) : 0;

  // Samo administrator i sekretarica mogu postavljati/mijenjati satnicu
  if (req.user.role === 'admin' || req.user.role === 'secretary') {
    if (hourly_rate !== undefined && hourly_rate !== null && hourly_rate !== '') {
      const customRate = parseFloat(hourly_rate);
      if (!isNaN(customRate) && customRate >= 0) {
        rate = customRate;
        // Ako se unese nova satnica, ažuriraj je u profilu tog radnika
        db.prepare('UPDATE users SET hourly_rate = ? WHERE id = ?').run(rate, targetUserId);
      }
    }
  }

  const dateVal = work_date || new Date().toISOString().split('T')[0];
  const otHours = overtime_hours ? parseFloat(overtime_hours) || 0 : 0;

  const result = db.prepare(`
    INSERT INTO work_hours (user_id, client_id, task_id, work_date, hours, start_time, end_time, overtime_hours, hourly_rate, description, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'approved')
  `).run(
    targetUserId,
    client_id ? parseInt(client_id) : null,
    task_id ? parseInt(task_id) : null,
    dateVal,
    numHours,
    start_time || null,
    end_time || null,
    otHours,
    rate,
    description ? description.trim() : null
  );

  res.json({ success: true, id: result.lastInsertRowid, message: 'Radni sati uspješno evidentirani.' });
});

// 4. Izmjena radnih sati
app.put('/api/work-hours/:id', authenticateToken, requirePermission('manage_work_hours', 'admin', 'secretary'), (req, res) => {
  const entryId = parseInt(req.params.id);
  const entry = db.prepare('SELECT * FROM work_hours WHERE id = ?').get(entryId);
  if (!entry) return res.status(404).json({ error: 'Zapis radnih sati nije pronađen.' });

  const { user_id, client_id, task_id, work_date, hours, start_time, end_time, overtime_hours, description, hourly_rate } = req.body;

  const targetUserId = user_id !== undefined ? (parseInt(user_id) || entry.user_id) : entry.user_id;
  const numHours = hours !== undefined ? (parseFloat(hours) || entry.hours) : entry.hours;
  const otHours = overtime_hours !== undefined ? (parseFloat(overtime_hours) || 0) : entry.overtime_hours;
  let rate = entry.hourly_rate;

  if (hourly_rate !== undefined && hourly_rate !== null && hourly_rate !== '') {
    const customRate = parseFloat(hourly_rate);
    if (!isNaN(customRate) && customRate >= 0) {
      rate = customRate;
    }
  }

  db.prepare(`
    UPDATE work_hours
    SET user_id = ?, client_id = ?, task_id = ?, work_date = ?, hours = ?, start_time = ?, end_time = ?, overtime_hours = ?, hourly_rate = ?, description = ?
    WHERE id = ?
  `).run(
    targetUserId,
    client_id !== undefined ? (client_id ? parseInt(client_id) : null) : entry.client_id,
    task_id !== undefined ? (task_id ? parseInt(task_id) : null) : entry.task_id,
    work_date || entry.work_date,
    numHours,
    start_time !== undefined ? start_time : entry.start_time,
    end_time !== undefined ? end_time : entry.end_time,
    otHours,
    rate,
    description !== undefined ? description : entry.description,
    entryId
  );

  res.json({ success: true, message: 'Radni sati i iznos uspješno ažurirani.' });
});

// 5. Brisanje radnih sati
app.delete('/api/work-hours/:id', authenticateToken, requirePermission('manage_work_hours', 'admin', 'secretary'), (req, res) => {
  const entryId = parseInt(req.params.id);
  const entry = db.prepare('SELECT * FROM work_hours WHERE id = ?').get(entryId);
  if (!entry) return res.status(404).json({ error: 'Zapis nije pronađen.' });

  db.prepare('DELETE FROM work_hours WHERE id = ?').run(entryId);
  res.json({ success: true, message: 'Zapis radnih sati obrisan.' });
});

// 6. Uvoz radnih sati iz Google Sheets / Excel tabele
app.post('/api/work-hours/import', authenticateToken, requireRole('admin', 'secretary'), (req, res) => {
  const { records } = req.body;
  if (!records || !Array.isArray(records) || records.length === 0) {
    return res.status(400).json({ error: 'Nema zapisa za uvoz radnih sati.' });
  }

  const findUser = db.prepare('SELECT id, hourly_rate FROM users WHERE LOWER(TRIM(full_name)) = LOWER(TRIM(?)) OR LOWER(TRIM(username)) = LOWER(TRIM(?))');
  const insertUser = db.prepare("INSERT INTO users (username, password_hash, full_name, role, hourly_rate) VALUES (?, ?, ?, 'worker', 12.5)");
  const findClient = db.prepare('SELECT id FROM clients WHERE LOWER(TRIM(name)) = LOWER(TRIM(?))');
  const insertClient = db.prepare("INSERT INTO clients (name, status) VALUES (?, 'active')");
  const insertHours = db.prepare(`
    INSERT INTO work_hours (user_id, client_id, work_date, hours, overtime_hours, hourly_rate, description, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'approved')
  `);

  let count = 0;
  const run = db.transaction(() => {
    for (const r of records) {
      const numHours = parseFloat(r.hours || r.sati || 0);
      if (isNaN(numHours) || numHours <= 0) continue;

      let userId = req.user.id;
      let rate = 12.5;

      const workerName = (r.worker_name || r.radnik || r.ime || '').trim();
      if (workerName) {
        let u = findUser.get(workerName, workerName);
        if (!u) {
          const uname = workerName.toLowerCase().replace(/[^a-z0-9]/g, '') || `radnik_${Date.now()}_${count}`;
          const salt = bcrypt.genSaltSync(10);
          const hash = bcrypt.hashSync('rad123', salt);
          const uRes = insertUser.run(uname, hash, workerName);
          userId = uRes.lastInsertRowid;
          rate = 12.5;
        } else {
          userId = u.id;
          rate = u.hourly_rate || 12.5;
        }
      }

      let clientId = null;
      const clientName = (r.client_name || r.klijent || r.firma || '').trim();
      if (clientName) {
        let c = findClient.get(clientName);
        if (!c) {
          const cRes = insertClient.run(clientName);
          clientId = cRes.lastInsertRowid;
        } else {
          clientId = c.id;
        }
      }

      const dateVal = r.work_date || r.datum || new Date().toISOString().split('T')[0];
      const otHours = parseFloat(r.overtime_hours || r.prekovremeno || 0) || 0;
      const customRate = r.hourly_rate ? parseFloat(r.hourly_rate) : rate;

      insertHours.run(
        userId,
        clientId,
        dateVal,
        numHours,
        otHours,
        customRate,
        r.description || r.opis || null
      );
      count++;
    }
  });

  try {
    run();
    res.json({ success: true, count, message: `Uspješno uvezeno ${count} unosa radnih sati!` });
  } catch (err) {
    res.status(500).json({ error: 'Greška pri uvozu radnih sati: ' + err.message });
  }
});

// 6. Uvoz podataka iz Google Sheets / Excel / CSV
app.post('/api/import/records', authenticateToken, requireRole('admin', 'secretary'), (req, res) => {
  const { records } = req.body;
  if (!records || !Array.isArray(records) || records.length === 0) {
    return res.status(400).json({ error: 'Nema podataka za uvoz.' });
  }

  const findClient = db.prepare('SELECT id FROM clients WHERE LOWER(TRIM(name)) = LOWER(TRIM(?))');
  const insertClient = db.prepare(`
    INSERT INTO clients (name, contact_person, phone, email, address, city, notes, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'active')
  `);
  const insertTask = db.prepare(`
    INSERT INTO tasks (client_id, title, description, status, priority, due_date)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  const insertBilling = db.prepare(`
    INSERT INTO billing (client_id, title, invoice_number, total_amount, paid_amount, due_date, status, notes)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const insertPayment = db.prepare(`
    INSERT INTO payments (client_id, billing_id, amount, payment_date, payment_method, note, created_by_user_id)
    VALUES (?, ?, ?, ?, 'bank', ?, ?)
  `);

  let importedCount = 0;
  const runImport = db.transaction(() => {
    for (const r of records) {
      const clientName = (r.client_name || r.name || r.firma || r.klijent || '').trim();
      if (!clientName) continue;

      // 1. Klijent
      let existing = findClient.get(clientName);
      let clientId = existing ? existing.id : null;

      if (!clientId) {
        const cResult = insertClient.run(
          clientName,
          r.contact_person || r.kontakt || null,
          r.phone || r.telefon || null,
          r.email || null,
          r.address || r.adresa || null,
          r.city || r.grad || null,
          r.notes || r.napomena || null
        );
        clientId = cResult.lastInsertRowid;
      }

      // 2. Zadatak (ako postoji opis rada ili zadatka)
      const taskTitle = (r.task_title || r.zadatak || r.posao || r.opis_posla || '').trim();
      if (taskTitle) {
        let status = 'todo';
        const rawStatus = (r.task_status || r.status || '').toLowerCase();
        if (rawStatus.includes('urađeno') || rawStatus.includes('uradjeno') || rawStatus.includes('done') || rawStatus.includes('završeno') || rawStatus.includes('zavrseno')) {
          status = 'done';
        } else if (rawStatus.includes('u toku') || rawStatus.includes('progress') || rawStatus.includes('radi')) {
          status = 'in_progress';
        } else if (rawStatus.includes('blok') || rawStatus.includes('nije')) {
          status = 'blocked';
        }

        insertTask.run(
          clientId,
          taskTitle,
          r.task_description || r.opis || null,
          status,
          r.priority || 'medium',
          r.due_date || r.rok || null
        );
      }

      // 3. Finansije / Zaduženja (ako postoji cijena/iznos)
      const totalAmount = parseFloat(r.total_amount || r.iznos || r.cijena || r.fakturisano || 0);
      const paidAmount = parseFloat(r.paid_amount || r.placeno || r.uplaceno || 0);

      if (totalAmount > 0 || paidAmount > 0) {
        const finalTotal = totalAmount > 0 ? totalAmount : paidAmount;
        let billStatus = 'unpaid';
        if (paidAmount >= finalTotal && finalTotal > 0) {
          billStatus = 'paid';
        } else if (paidAmount > 0) {
          billStatus = 'partial';
        }

        const bResult = insertBilling.run(
          clientId,
          taskTitle ? `Usluga: ${taskTitle}` : 'Ugovorene usluge',
          r.invoice_number || r.broj_fakture || null,
          finalTotal,
          paidAmount,
          r.due_date || null,
          billStatus,
          r.notes || null
        );

        if (paidAmount > 0) {
          insertPayment.run(
            clientId,
            bResult.lastInsertRowid,
            paidAmount,
            r.payment_date || new Date().toISOString().split('T')[0],
            'Uvoz iz Google Sheets',
            req.user.id
          );
        }
      }

      importedCount++;
    }
  });

  try {
    runImport();
    res.json({ success: true, count: importedCount, message: `Uspješno uvezeno ${importedCount} stavki.` });
  } catch (err) {
    res.status(500).json({ error: 'Greška pri uvozu: ' + err.message });
  }
});

// Fallback to index.html for SPA routing
app.use((req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start Server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`====================================================`);
  console.log(` Poslovni CRM & Radni Nalog sistem je pokrenut!`);
  console.log(` Lokalni pristup: http://localhost:${PORT}`);
  console.log(` Mrežni pristup (za sve u kancelariji): http://0.0.0.0:${PORT}`);
  console.log(`====================================================`);
});
