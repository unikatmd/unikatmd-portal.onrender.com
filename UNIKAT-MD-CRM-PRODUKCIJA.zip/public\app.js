// State Management
let currentUser = null;
let authToken = localStorage.getItem('token') || null;
let portalGateToken = localStorage.getItem('unikat_portal_gate') || null;
let currentTab = 'dashboard';
let clientsList = [];
let usersList = [];
let currentDetailedClientId = null;
let currentTaskScope = 'all'; // 'all' ili 'my'
let userNotifications = [];
let lastUnreadNotificationCount = 0;
let notificationPollingTimer = null;
let printServicesList = [];
let printActiveFilter = 'all';
let printCurrentView = 'orders';
let printSearchDebounceTimer = null;

// Theme Management (Dark Luxury / Light Office)
function initTheme() {
  const saved = localStorage.getItem('unikat_theme') || 'dark';
  applyTheme(saved);
}

function toggleTheme() {
  const isLight = document.body.classList.contains('theme-light');
  const next = isLight ? 'dark' : 'light';
  localStorage.setItem('unikat_theme', next);
  applyTheme(next);
}

function applyTheme(theme) {
  const body = document.body;
  const labelEl = document.getElementById('themeLabel');
  const iconEl = document.getElementById('themeIcon');
  const mobileIcons = document.querySelectorAll('.mobile-theme-icon');

  if (theme === 'light') {
    body.classList.remove('theme-dark');
    body.classList.add('theme-light');
    if (labelEl) labelEl.textContent = 'Svijetla tema';
    if (iconEl) iconEl.setAttribute('data-lucide', 'sun');
    mobileIcons.forEach(i => i.setAttribute('data-lucide', 'sun'));
  } else {
    body.classList.remove('theme-light');
    body.classList.add('theme-dark');
    if (labelEl) labelEl.textContent = 'Tamna tema';
    if (iconEl) iconEl.setAttribute('data-lucide', 'moon');
    mobileIcons.forEach(i => i.setAttribute('data-lucide', 'moon'));
  }
  refreshIcons();
}

// ==================== AVATARS & TEAM PROFILES ====================
window.cachedProfiles = [];

function getUserAvatar(userOrIdentifier, sizeClass = 'w-7 h-7', textClass = 'text-xs') {
  let avatarUrl = null;
  let displayName = 'K';

  if (!userOrIdentifier) {
    return `<div class="${sizeClass} rounded-full bg-slate-800 text-[#DFC68A] border border-[#D4AF37]/30 flex items-center justify-center font-bold ${textClass} shrink-0">?</div>`;
  }

  // Handle composite responsible persons like "Emin / Amra"
  if (typeof userOrIdentifier === 'string' && (userOrIdentifier.includes(' / ') || userOrIdentifier.includes('/'))) {
    const parts = userOrIdentifier.split('/').map(s => s.trim());
    return `
      <div class="inline-flex items-center -space-x-2 shrink-0">
        ${parts.map(p => getUserAvatar(p, sizeClass, textClass)).join('')}
      </div>
    `;
  }

  if (typeof userOrIdentifier === 'object') {
    avatarUrl = userOrIdentifier.avatar;
    displayName = userOrIdentifier.full_name || userOrIdentifier.username || 'K';
  } else if (typeof userOrIdentifier === 'string') {
    if (userOrIdentifier.startsWith('/uploads/') || userOrIdentifier.startsWith('http') || userOrIdentifier.startsWith('data:')) {
      avatarUrl = userOrIdentifier;
      displayName = 'K';
    } else {
      displayName = userOrIdentifier;
      const norm = userOrIdentifier.trim().toLowerCase();
      // Search in cachedProfiles or usersList
      const pool = (window.cachedProfiles && window.cachedProfiles.length) ? window.cachedProfiles : (usersList || []);
      const matched = pool.find(u => 
        (u.username && u.username.toLowerCase() === norm) || 
        (u.full_name && u.full_name.toLowerCase() === norm) ||
        (u.full_name && u.full_name.toLowerCase().includes(norm)) ||
        norm.includes(u.full_name ? u.full_name.toLowerCase() : '____')
      );
      if (matched && matched.avatar) {
        avatarUrl = matched.avatar;
      } else {
        // Fallback matching for known team members
        if (norm.includes('emin') || norm.includes('cifrić') || norm.includes('direktor')) {
          avatarUrl = '/uploads/avatars/emin.jpg';
        } else if (norm.includes('amra') || norm.includes('bećirović') || norm.includes('becirovic')) {
          avatarUrl = '/uploads/avatars/amra.jpg';
        } else if (norm.includes('stefan') || norm.includes('glišić') || norm.includes('glisic')) {
          avatarUrl = '/uploads/avatars/stefan.jpg';
        } else if (norm.includes('sara') || norm.includes('jekić') || norm.includes('jekic')) {
          avatarUrl = '/uploads/avatars/sara.jpg';
        } else if (norm.includes('edin') || norm.includes('đapo') || norm.includes('dapo') || norm.includes('djapo')) {
          avatarUrl = '/uploads/avatars/edin.jpg';
        }
      }
    }
  }

  const initial = (displayName.charAt(0) || 'K').toUpperCase();

  if (avatarUrl) {
    return `
      <div class="${sizeClass} rounded-full overflow-hidden border border-[#D4AF37]/50 shadow-sm shrink-0 bg-slate-900 inline-flex items-center justify-center">
        <img src="${avatarUrl}" alt="${escapeHtml(displayName)}" class="w-full h-full object-cover object-top" onerror="this.onerror=null;this.parentElement.outerHTML='<div class=\\'${sizeClass} rounded-full bg-slate-800 text-[#DFC68A] border border-[#D4AF37]/40 flex items-center justify-center font-bold ${textClass}\\'>${initial}</div>';">
      </div>
    `;
  } else {
    return `
      <div class="${sizeClass} rounded-full bg-gradient-to-br from-slate-800 to-slate-950 text-[#DFC68A] border border-[#D4AF37]/40 shadow-sm shrink-0 inline-flex items-center justify-center font-bold ${textClass}">
        ${initial}
      </div>
    `;
  }
}

function togglePasswordVisibility(inputId) {
  const input = document.getElementById(inputId);
  if (!input) return;
  input.type = input.type === 'password' ? 'text' : 'password';
}

function showPortalGate() {
  const gateSec = document.getElementById('portalGateSection');
  const loginSec = document.getElementById('portalLoginSection');
  if (gateSec) gateSec.classList.remove('hidden');
  if (loginSec) loginSec.classList.add('hidden');
  const input = document.getElementById('portalMasterKeyInput');
  if (input) {
    input.value = '';
    setTimeout(() => input.focus(), 100);
  }
  const err = document.getElementById('portalGateError');
  if (err) err.classList.add('hidden');
  refreshIcons();
}

function showPortalLogin() {
  const gateSec = document.getElementById('portalGateSection');
  const loginSec = document.getElementById('portalLoginSection');
  if (gateSec) gateSec.classList.add('hidden');
  if (loginSec) loginSec.classList.remove('hidden');
  loadLoginProfiles();
  refreshIcons();
}

function lockPortalGate() {
  portalGateToken = null;
  localStorage.removeItem('unikat_portal_gate');
  showPortalGate();
}

async function handleUnlockGate(e) {
  if (e) e.preventDefault();
  const input = document.getElementById('portalMasterKeyInput');
  const errDiv = document.getElementById('portalGateError');
  const errText = document.getElementById('portalGateErrorText');
  const btn = document.getElementById('btnUnlockGate');
  const pass = (input ? input.value : '').trim();
  if (!pass) return;

  if (btn) {
    btn.disabled = true;
    btn.classList.add('opacity-70');
  }
  if (errDiv) errDiv.classList.add('hidden');

  try {
    const res = await fetch('/api/portal/verify-gate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ access_code: pass })
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Pogrešna master šifra.');
    }
    portalGateToken = data.gate_token;
    localStorage.setItem('unikat_portal_gate', portalGateToken);
    showPortalLogin();
  } catch (err) {
    if (errDiv) {
      if (errText) errText.textContent = err.message || 'Pogrešna master šifra firme.';
      errDiv.classList.remove('hidden');
    }
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.classList.remove('opacity-70');
    }
    refreshIcons();
  }
}

async function loadLoginProfiles() {
  const container = document.getElementById('loginProfilesGrid');
  if (!container) return;

  try {
    const headers = {};
    if (portalGateToken) {
      headers['x-portal-gate'] = portalGateToken;
    }
    if (authToken) {
      headers['Authorization'] = `Bearer ${authToken}`;
    }
    const res = await fetch('/api/public/profiles', { headers });
    if (res.status === 403 || res.status === 401) {
      portalGateToken = null;
      localStorage.removeItem('unikat_portal_gate');
      showPortalGate();
      return;
    }
    const data = await res.json();
    window.cachedProfiles = data.profiles || [];

    if (window.cachedProfiles.length === 0) {
      container.innerHTML = '<div class="col-span-4 text-center text-xs text-slate-500 py-2">Nema registrovanih profila.</div>';
      return;
    }

    container.innerHTML = window.cachedProfiles.map(p => {
      let roleLabel = 'Radnik';
      let borderClass = 'border-slate-800 hover:border-[#D4AF37]/60';
      if (p.role === 'admin' || p.username === 'emin') {
        roleLabel = '👑 Direktor';
        borderClass = 'border-[#D4AF37]/40 bg-[#D4AF37]/5';
      } else if (p.role === 'secretary' || p.username === 'amra') {
        roleLabel = '💼 Menadžer';
        borderClass = 'border-emerald-500/30 bg-emerald-500/5';
      }

      const shortName = p.full_name.split(' ')[0] || p.username;
      const avatarHtml = getUserAvatar(p, 'w-11 h-11 sm:w-12 sm:h-12', 'text-sm');

      return `
        <button type="button" onclick="selectLoginProfile('${escapeHtml(p.username)}')" id="profileCard_${escapeHtml(p.username)}" class="login-profile-card group flex flex-col items-center p-2 rounded-xl transition text-center border ${borderClass} hover:bg-slate-800/60 focus:outline-none">
          <div class="relative mb-1 transition transform group-hover:scale-105">
            ${avatarHtml}
            ${p.role === 'admin' ? '<span class="absolute -bottom-1 -right-1 text-[11px]">👑</span>' : ''}
          </div>
          <div class="text-[11px] font-bold text-white truncate max-w-full group-hover:text-[#ECC968]">${escapeHtml(shortName)}</div>
          <div class="text-[9px] text-[#DFC68A] uppercase font-semibold tracking-wider truncate max-w-full">${roleLabel}</div>
        </button>
      `;
    }).join('');

    refreshIcons();
  } catch (err) {
    console.error('Error loading login profiles:', err);
    if (container) {
      container.innerHTML = '<div class="col-span-4 text-center text-xs text-slate-500 py-1">Prijavite se putem formulara ispod.</div>';
    }
  }
}

function selectLoginProfile(username) {
  const usernameInput = document.getElementById('loginUsername');
  const passwordInput = document.getElementById('loginPassword');
  if (usernameInput) usernameInput.value = username;
  if (passwordInput) {
    passwordInput.value = '';
    passwordInput.focus();
  }

  // Highlight selected card
  document.querySelectorAll('.login-profile-card').forEach(el => {
    el.classList.remove('ring-2', 'ring-[#ECC968]', 'bg-[#D4AF37]/20');
  });
  const selectedCard = document.getElementById(`profileCard_${username}`);
  if (selectedCard) {
    selectedCard.classList.add('ring-2', 'ring-[#ECC968]', 'bg-[#D4AF37]/20');
  }
}

function previewUserAvatar(url) {
  const previewEl = document.getElementById('userModalAvatarPreview');
  if (!previewEl) return;
  if (url) {
    previewEl.innerHTML = `<img src="${url}" class="w-full h-full object-cover object-top" alt="Avatar">`;
  } else {
    previewEl.innerHTML = '<i data-lucide="user" class="w-5 h-5 text-slate-400"></i>';
    refreshIcons();
  }
}

// Initialize app on page load
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  if (authToken) {
    verifySession();
  } else {
    showAuth();
  }

  // Setup form listeners
  const gateForm = document.getElementById('portalGateForm');
  if (gateForm) gateForm.addEventListener('submit', handleUnlockGate);
  const mkForm = document.getElementById('masterKeyForm');
  if (mkForm) mkForm.addEventListener('submit', handleSaveMasterKey);

  document.getElementById('loginForm').addEventListener('submit', handleLogin);
  document.getElementById('clientForm').addEventListener('submit', handleSaveClient);
  document.getElementById('taskForm').addEventListener('submit', handleCreateTask);
  document.getElementById('completeTaskForm').addEventListener('submit', handleCompleteTask);
  document.getElementById('invoiceForm').addEventListener('submit', handleSaveInvoice);
  document.getElementById('paymentForm').addEventListener('submit', handleCreatePayment);
  document.getElementById('userForm').addEventListener('submit', handleCreateUser);
  const whForm = document.getElementById('workHourForm');
  if (whForm) whForm.addEventListener('submit', handleCreateWorkHour);

  // Set default dates to today
  const today = new Date().toISOString().split('T')[0];
  const pDate = document.getElementById('paymentDate');
  if (pDate) pDate.value = today;
  const tDue = document.getElementById('taskDueDate');
  if (tDue) tDue.value = today;
  const whD = document.getElementById('whDate');
  if (whD) whD.value = today;
  const whM = document.getElementById('hoursFilterMonth');
  if (whM) whM.value = today.substring(0, 7);
});

// Helper for Lucide icons rendering
function refreshIcons() {
  if (window.lucide) {
    window.lucide.createIcons();
  }
}

// API Fetch Helper
async function api(endpoint, options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    ...(authToken ? { 'Authorization': `Bearer ${authToken}` } : {}),
    ...(options.headers || {})
  };

  try {
    const res = await fetch(endpoint, { ...options, headers });
    let data = null;
    const text = await res.text();
    try {
      data = JSON.parse(text);
    } catch (e) {
      data = { error: text || `HTTP ${res.status}: ${res.statusText}` };
    }

    if (!res.ok) {
      if (res.status === 401 && authToken) {
        logout();
      }
      throw new Error(data.error || `Greška (${res.status}): ${res.statusText}`);
    }
    return data;
  } catch (err) {
    console.error('API Error:', err);
    if (err.name === 'TypeError' && err.message && err.message.toLowerCase().includes('fetch')) {
      throw new Error('Problem sa vezom prema serveru. Molimo osvježite stranicu ili sačekajte trenutak.');
    }
    throw err;
  }
}

// ==================== AUTHENTICATION ====================
function fillLogin(user, pass) {
  // Disabled for security
}

function toggleOtherLogins() {
  // Disabled
}

async function handleLogin(e) {
  e.preventDefault();
  const username = document.getElementById('loginUsername').value.trim();
  const password = document.getElementById('loginPassword').value;
  const errDiv = document.getElementById('loginError');
  errDiv.classList.add('hidden');

  try {
    const data = await api('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password })
    });

    authToken = data.token;
    currentUser = data.user;
    localStorage.setItem('token', authToken);
    localStorage.setItem('user', JSON.stringify(currentUser));

    setupUIForUser();
    showApp();
    switchTab('dashboard');
  } catch (err) {
    errDiv.textContent = err.message;
    errDiv.classList.remove('hidden');
  }
}

async function verifySession() {
  try {
    const data = await api('/api/auth/me');
    currentUser = data.user;
    localStorage.setItem('user', JSON.stringify(currentUser));
    setupUIForUser();
    showApp();
    switchTab('dashboard');
  } catch (err) {
    logout();
  }
}

function logout() {
  stopNotificationPolling();
  authToken = null;
  currentUser = null;
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  showAuth();
}

function showAuth() {
  document.getElementById('authContainer').classList.remove('hidden');
  document.getElementById('appContainer').classList.add('hidden');
  if (!portalGateToken) {
    showPortalGate();
  } else {
    showPortalLogin();
  }
  refreshIcons();
}

function showApp() {
  document.getElementById('authContainer').classList.add('hidden');
  document.getElementById('appContainer').classList.remove('hidden');
  refreshIcons();
}

// ==================== NOTIFICATIONS & REAL-TIME AUDIO ====================

// Web Audio Melodic Chime (Synthesized two-tone bell)
function playNotificationSound() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    // Tone 1: 880Hz (A5)
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(880, now);
    gain1.gain.setValueAtTime(0.2, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.3);

    // Tone 2: 1318.5Hz (E6 - high chime)
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(1318.5, now + 0.12);
    gain2.gain.setValueAtTime(0.25, now + 0.12);
    gain2.gain.exponentialRampToValueAtTime(0.0001, now + 0.7);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.12);
    osc2.stop(now + 0.7);
  } catch (err) {
    console.warn('Audio chime warning:', err);
  }
}

// Browser Desktop Notification
function requestDesktopNotificationPermission() {
  try {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
  } catch (e) {
    console.warn('Notification permission error:', e);
  }
}

function triggerDesktopNotification(title, message, taskId) {
  try {
    if ('Notification' in window && Notification.permission === 'granted') {
      const n = new Notification(title, {
        body: message,
        icon: '/logo-icon.png',
        badge: '/logo-icon.png'
      });
      n.onclick = () => {
        window.focus();
        switchTab('tasks');
        n.close();
      };
    }
  } catch (e) {
    console.warn('Desktop notification error:', e);
  }
}

// In-App Toast
function showFloatingToast(title, message) {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = 'pointer-events-auto transform translate-y-3 opacity-0 transition-all duration-300 bg-[#0E121B] border border-[#D4AF37]/60 shadow-2xl rounded-2xl p-4 text-slate-100 flex items-start gap-3 text-xs';
  toast.innerHTML = `
    <div class="w-8 h-8 rounded-xl gold-gradient-bg flex items-center justify-center text-slate-950 font-bold shrink-0 mt-0.5 shadow">
      <i data-lucide="bell-ring" class="w-4 h-4"></i>
    </div>
    <div class="flex-1 min-w-0">
      <h4 class="font-extrabold text-white text-xs">${escapeHtml(title)}</h4>
      <p class="text-slate-300 text-[11px] mt-0.5 line-clamp-3">${escapeHtml(message)}</p>
    </div>
    <button onclick="this.parentElement.remove()" class="text-slate-400 hover:text-white p-1">
      <i data-lucide="x" class="w-3.5 h-3.5"></i>
    </button>
  `;
  container.appendChild(toast);
  refreshIcons();

  setTimeout(() => {
    toast.classList.remove('translate-y-3', 'opacity-0');
  }, 10);

  setTimeout(() => {
    toast.classList.add('opacity-0', '-translate-y-2');
    setTimeout(() => toast.remove(), 350);
  }, 7000);
}

// Auto-assign worker based on chosen task type
function autoAssignWorkerByType(taskType) {
  const assignSelect = document.getElementById('taskAssignedUser');
  if (!assignSelect || !usersList || usersList.length === 0) return;

  const type = (taskType || '').toLowerCase();
  let targetUsername = null;

  if (type.includes('dizajn')) {
    targetUsername = 'sara'; // Sara Jekić (Design)
  } else if (type.includes('montaž') || type.includes('video')) {
    targetUsername = 'stefan'; // Stefan Glišić (Montaža)
  } else if (type.includes('snimanj')) {
    targetUsername = 'nermin'; // Nermin Tufekčić (Snimanje)
  } else if (type.includes('mrež') || type.includes('admin') || type.includes('ponud')) {
    targetUsername = 'amra'; // Amra Bećirović (PM)
  }

  if (targetUsername) {
    const user = usersList.find(u => u.username === targetUsername);
    if (user) {
      assignSelect.value = user.id;
    }
  }
}

// Scope Switcher: 'my' vs 'all'
function setTaskScope(scope) {
  currentTaskScope = scope;
  const btnMy = document.getElementById('btnScopeMy');
  const btnAll = document.getElementById('btnScopeAll');
  const myLabel = document.getElementById('scopeMyLabel');

  if (myLabel && currentUser) {
    const firstName = currentUser.full_name.split(' ')[0];
    myLabel.textContent = `Moji zadaci (${firstName})`;
  }

  if (scope === 'my') {
    if (btnMy) btnMy.className = 'px-3 py-1.5 rounded-lg text-xs font-bold gold-btn text-slate-950 transition flex items-center gap-1.5 shadow';
    if (btnAll) btnAll.className = 'px-3 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white transition flex items-center gap-1.5';
  } else {
    if (btnMy) btnMy.className = 'px-3 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white transition flex items-center gap-1.5';
    if (btnAll) btnAll.className = 'px-3 py-1.5 rounded-lg text-xs font-bold gold-btn text-slate-950 transition flex items-center gap-1.5 shadow';
  }

  loadTasks();
}

function startNotificationPolling() {
  if (notificationPollingTimer) clearInterval(notificationPollingTimer);
  notificationPollingTimer = setInterval(fetchNotifications, 12000);
}

function stopNotificationPolling() {
  if (notificationPollingTimer) {
    clearInterval(notificationPollingTimer);
    notificationPollingTimer = null;
  }
}

async function fetchNotifications() {
  if (!authToken || !currentUser) return;
  try {
    const data = await api('/api/notifications');
    userNotifications = data.notifications || [];
    const unreadCount = data.unreadCount || 0;

    // Check if new unread notification arrived
    if (unreadCount > lastUnreadNotificationCount && lastUnreadNotificationCount !== 0) {
      const newest = userNotifications.find(n => n.is_read === 0);
      if (newest) {
        playNotificationSound();
        triggerDesktopNotification(newest.title, newest.message, newest.task_id);
        showFloatingToast(newest.title, newest.message);
      }
    }
    lastUnreadNotificationCount = unreadCount;

    updateNotificationBadges(unreadCount);
    renderNotificationsList();
  } catch (err) {
    // Ignore polling failures
  }
}

function updateNotificationBadges(unreadCount) {
  const badgeDot = document.getElementById('notificationBadge');
  const badgeCount = document.getElementById('notificationCountBadge');
  const mobileCount = document.getElementById('mobileNotificationCountBadge');

  if (unreadCount > 0) {
    if (badgeDot) badgeDot.classList.remove('hidden');
    if (badgeCount) {
      badgeCount.textContent = unreadCount > 9 ? '9+' : unreadCount;
      badgeCount.classList.remove('hidden');
    }
    if (mobileCount) {
      mobileCount.textContent = unreadCount > 9 ? '9+' : unreadCount;
      mobileCount.classList.remove('hidden');
    }
  } else {
    if (badgeDot) badgeDot.classList.add('hidden');
    if (badgeCount) badgeCount.classList.add('hidden');
    if (mobileCount) mobileCount.classList.add('hidden');
  }
}

function toggleNotificationsDrawer() {
  const drawer = document.getElementById('notificationsDrawer');
  if (!drawer) return;
  drawer.classList.toggle('hidden');
  if (!drawer.classList.contains('hidden')) {
    fetchNotifications();
    refreshIcons();
  }
}

function renderNotificationsList() {
  const list = document.getElementById('notificationsList');
  if (!list) return;

  if (userNotifications.length === 0) {
    list.innerHTML = `
      <div class="text-center py-12 text-slate-500">
        <i data-lucide="bell-off" class="w-8 h-8 mx-auto mb-2 opacity-40"></i>
        <p class="font-bold text-xs">Nemate radnih obavještenja</p>
        <p class="text-[11px] text-slate-600 mt-1">Svi dodijeljeni poslovi će se pojaviti ovdje.</p>
      </div>
    `;
    refreshIcons();
    return;
  }

  list.innerHTML = userNotifications.map(n => {
    const isUnread = n.is_read === 0;
    const timeAgo = (n.created_at || '').substring(0, 16).replace('T', ' ');
    return `
      <div class="p-3.5 rounded-xl border transition ${isUnread ? 'bg-[#182030] border-[#D4AF37]/50 shadow-md' : 'bg-[#121622] border-slate-800 text-slate-400'}">
        <div class="flex items-start justify-between gap-2">
          <div class="flex items-center gap-2">
            ${isUnread ? '<span class="w-2 h-2 rounded-full bg-[#ECC968] animate-ping"></span>' : ''}
            <h4 class="font-extrabold ${isUnread ? 'text-white' : 'text-slate-300'} text-xs leading-snug">${escapeHtml(n.title)}</h4>
          </div>
          <span class="text-[10px] text-slate-500 whitespace-nowrap">${timeAgo}</span>
        </div>
        <p class="text-[11px] ${isUnread ? 'text-slate-300' : 'text-slate-400'} mt-1.5">${escapeHtml(n.message)}</p>
        <div class="pt-2 mt-2 border-t border-slate-800 flex items-center justify-between">
          ${n.task_id ? `
            <button onclick="viewTaskFromNotification(${n.task_id}, ${n.id})" class="text-[11px] font-bold text-[#ECC968] hover:underline flex items-center gap-1">
              <span>Pogledaj zadatak</span>
              <i data-lucide="arrow-right" class="w-3 h-3"></i>
            </button>
          ` : '<span></span>'}
          ${isUnread ? `
            <button onclick="markNotificationAsRead(${n.id})" class="text-[10px] text-slate-400 hover:text-white">Označi pročitano</button>
          ` : ''}
        </div>
      </div>
    `;
  }).join('');
  refreshIcons();
}

async function markNotificationAsRead(id) {
  try {
    await api(`/api/notifications/${id}/read`, { method: 'PUT' });
    fetchNotifications();
  } catch (err) {
    console.error(err);
  }
}

async function markAllNotificationsAsRead() {
  try {
    await api('/api/notifications/read-all', { method: 'POST' });
    fetchNotifications();
  } catch (err) {
    console.error(err);
  }
}

function viewTaskFromNotification(taskId, notifId) {
  if (notifId) markNotificationAsRead(notifId);
  toggleNotificationsDrawer();
  switchTab('tasks');
  setTaskScope('all');
}

function can(permKey) {
  if (!currentUser) return false;
  if (currentUser.role === 'admin') return true;
  if (currentUser.permissions && currentUser.permissions[permKey] !== undefined) {
    return !!currentUser.permissions[permKey];
  }
  // Default role fallbacks
  if (currentUser.role === 'secretary') {
    return permKey !== 'manage_permissions';
  }
  if (permKey === 'view_clients' || permKey === 'log_work_hours' || permKey === 'view_print') {
    return true;
  }
  return false;
}

function setupUIForUser() {
  if (!currentUser) return;

  // Personalized Role Title
  let roleTitle = 'Operativa';
  if (currentUser.username === 'emin' || currentUser.username === 'direktor' || currentUser.role === 'admin') {
    roleTitle = 'Direktor / Vlasnik';
  } else if (currentUser.username === 'amra') {
    roleTitle = 'Project Manager & Finansije';
  } else if (currentUser.username === 'sara') {
    roleTitle = 'Grafički Dizajner';
  } else if (currentUser.username === 'stefan') {
    roleTitle = 'Video Montažer';
  } else if (currentUser.username === 'dejana') {
    roleTitle = 'Marketing & Dizajn';
  } else if (currentUser.username === 'edin' || currentUser.username === 'djapo') {
    roleTitle = 'Operativa & Teren';
  } else if (currentUser.username === 'nermin') {
    roleTitle = 'Video Produkcija & Teren';
  } else if (currentUser.username === 'adi') {
    roleTitle = 'Grafički Dizajner';
  } else if (currentUser.role === 'secretary') {
    roleTitle = 'Finansije & PM';
  }

  // User display name & role
  document.getElementById('currentUserName').textContent = currentUser.full_name;
  document.getElementById('currentUserRole').textContent = roleTitle;
  document.getElementById('mobileUserRole').textContent = roleTitle;
  const userAvatarEl = document.getElementById('userAvatar');
  if (userAvatarEl) {
    userAvatarEl.innerHTML = getUserAvatar(currentUser, 'w-10 h-10', 'text-sm');
    userAvatarEl.className = 'w-10 h-10 rounded-full shrink-0 flex items-center justify-center';
  }
  const mobileAvatarEl = document.getElementById('mobileUserAvatar');
  if (mobileAvatarEl) {
    mobileAvatarEl.innerHTML = getUserAvatar(currentUser, 'w-7 h-7', 'text-[10px]');
  }

  // Granular permissions: Dinamički provjeri ko šta smije raditi i vidjeti na platformi
  const restrictedElements = document.querySelectorAll('.role-restricted');
  const isFinanceAllowed = can('view_finances');
  const isUsersAllowed = can('manage_users');

  restrictedElements.forEach(el => {
    // Users tab: Upravljanje radnicima i nalozima
    if (el.id === 'nav-users') {
      if (isUsersAllowed) {
        el.classList.remove('hidden');
      } else {
        el.classList.add('hidden');
      }
      return;
    } else if (el.id === 'nav-secretary') {
      // Secretary/finance module
      if (isFinanceAllowed) {
        el.classList.remove('hidden');
      } else {
        el.classList.add('hidden');
      }
      return;
    } else {
      if (isFinanceAllowed) {
        el.classList.remove('hidden');
      } else {
        el.classList.add('hidden');
      }
    }
  });

  // Preload clients and users for selects
  loadDropdownData();

  // Set default task scope: workers default to their own tasks, PM/Admin to all
  if (currentUser.role === 'worker') {
    setTaskScope('my');
  } else {
    setTaskScope('all');
  }

  // Request browser notification permission
  requestDesktopNotificationPermission();

  // Start notification polling & initial fetch
  startNotificationPolling();
  fetchNotifications();
}

// Load Dropdown Options (Clients, Users)
async function loadDropdownData() {
  try {
    const clientsData = await api('/api/clients');
    clientsList = clientsData.clients;

    // Populate client selectors
    const clientSelects = ['taskClientId', 'invoiceClientId', 'paymentClientId', 'taskClientFilter', 'whClientId', 'hoursFilterClient'];
    clientSelects.forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      const currentVal = el.value;
      let opts = '';
      if (id === 'taskClientFilter' || id === 'hoursFilterClient') {
        opts = '<option value="">Svi klijenti</option>';
      } else if (id === 'whClientId') {
        opts = '<option value="">Opšti rad u firmi / radionici</option>';
      } else {
        opts = '<option value="">Izaberite klijenta...</option>';
      }
      clientsList.forEach(c => {
        opts += `<option value="${c.id}">${c.name} (${c.city || 'Klijent'})</option>`;
      });
      el.innerHTML = opts;
      if (currentVal) el.value = currentVal;
    });

    const printDatalist = document.getElementById('printClientsDatalist');
    if (printDatalist) {
      printDatalist.innerHTML = clientsList.map(c => `<option value="${escapeHtml(c.name)}">`).join('');
    }

    // Populate assigned users
    const usersData = await api('/api/users');
    usersList = usersData.users;
    
    const taskUserSelect = document.getElementById('taskAssignedUser');
    if (taskUserSelect) {
      let uOpts = '<option value="">Nije dodijeljeno (Bilo ko)</option>';
      usersList.forEach(u => {
        uOpts += `<option value="${u.id}">${u.full_name} (${u.role === 'worker' ? 'Radnik' : u.role})</option>`;
      });
      taskUserSelect.innerHTML = uOpts;
    }

    const taskWorkerFilter = document.getElementById('taskWorkerFilter');
    if (taskWorkerFilter) {
      const cur = taskWorkerFilter.value;
      let wOpts = '<option value="">Svi zaposleni</option>';
      usersList.forEach(u => {
        wOpts += `<option value="${u.id}">${u.full_name}</option>`;
      });
      taskWorkerFilter.innerHTML = wOpts;
      if (cur) taskWorkerFilter.value = cur;
    }

    const whUserSelect = document.getElementById('whUserId');
    if (whUserSelect) {
      let uOpts = '';
      if (currentUser.role === 'worker') {
        uOpts = `<option value="${currentUser.id}">${currentUser.full_name}</option>`;
      } else {
        uOpts = '<option value="">Izaberite radnika...</option>';
        usersList.forEach(u => {
          const rateText = u.hourly_rate ? `${u.hourly_rate} KM/h` : '0 KM/h';
          uOpts += `<option value="${u.id}">${u.full_name} (${rateText})</option>`;
        });
      }
      whUserSelect.innerHTML = uOpts;
      if (currentUser.role === 'worker') {
        whUserSelect.value = currentUser.id;
        whUserSelect.disabled = true;
        const rateInput = document.getElementById('whHourlyRate');
        if (rateInput) {
          rateInput.value = currentUser.hourly_rate || 0;
          rateInput.readOnly = false; // Radnik može slobodno unijeti ili promijeniti svoju satnicu!
        }
      }
    }

    const whFilterUser = document.getElementById('hoursFilterWorker');
    if (whFilterUser) {
      let uOpts = '<option value="">Svi radnici</option>';
      usersList.forEach(u => {
        const rateText = u.hourly_rate ? `${u.hourly_rate} KM/h` : '0 KM/h';
        uOpts += `<option value="${u.id}">${u.full_name} (${rateText})</option>`;
      });
      whFilterUser.innerHTML = uOpts;
    }

    // Update client count badge
    document.getElementById('badgeClientsCount').textContent = clientsList.length;
  } catch (err) {
    console.error('Error preloading dropdowns:', err);
  }
}

// Live calculation helper for Work Hours Modal
function updateWhModalCalculation() {
  const hoursInput = document.getElementById('whHours');
  const otInput = document.getElementById('whOvertime');
  const rateInput = document.getElementById('whHourlyRate');
  const breakdownEl = document.getElementById('whCalcBreakdown');
  const totalEl = document.getElementById('whCalcTotal');
  if (!breakdownEl || !totalEl) return;

  const regHours = parseFloat(hoursInput ? hoursInput.value : 0) || 0;
  const otHours = parseFloat(otInput ? otInput.value : 0) || 0;
  const rate = parseFloat(rateInput ? rateInput.value : 0) || 0;
  const totalHours = Math.round((regHours + otHours) * 100) / 100;
  const totalPay = Math.round((totalHours * rate) * 100) / 100;

  breakdownEl.textContent = `${regHours}h redovno + ${otHours}h dodatno = ${totalHours}h ukupno × ${rate} KM/h`;
  totalEl.textContent = `${formatCurrency(totalPay)}`;
}

document.addEventListener('input', (e) => {
  if (e.target && (e.target.id === 'whHours' || e.target.id === 'whOvertime' || e.target.id === 'whHourlyRate')) {
    updateWhModalCalculation();
  }
});

// User select change listener to update rate and calculation
document.addEventListener('change', (e) => {
  if (e.target && e.target.id === 'whUserId') {
    const selectedUser = usersList.find(u => u.id === parseInt(e.target.value));
    const rateInput = document.getElementById('whHourlyRate');
    if (rateInput && selectedUser) {
      rateInput.value = selectedUser.hourly_rate !== undefined ? selectedUser.hourly_rate : 0;
    }
    updateWhModalCalculation();
  }
});

// ==================== NAVIGATION TABS ====================
function switchTab(tabId) {
  currentTab = tabId;

  // Toggle active class on sidebar items
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.remove('nav-item-active', 'bg-indigo-600', 'text-white', 'font-bold');
    item.classList.add('text-slate-300');
  });

  const activeNav = document.getElementById(`nav-${tabId}`);
  if (activeNav) {
    activeNav.classList.add('nav-item-active', 'bg-indigo-600', 'text-white', 'font-bold');
    activeNav.classList.remove('text-slate-300');
  }

  // Toggle tab contents
  document.querySelectorAll('.tab-content').forEach(section => {
    section.classList.add('hidden');
  });

  const activeSection = document.getElementById(`tab-${tabId}`);
  if (activeSection) {
    activeSection.classList.remove('hidden');
  }

  // Load relevant data
  if (tabId === 'dashboard') loadDashboard();
  if (tabId === 'clients') loadClients();
  if (tabId === 'tasks') loadTasks();
  if (tabId === 'hours') loadWorkHours();
  if (tabId === 'print') loadPrintServices();
  if (tabId === 'secretary') loadSecretaryModule();
  if (tabId === 'users') loadUsers();

  refreshIcons();
}

// ==================== DASHBOARD ====================
async function loadDashboard() {
  try {
    const data = await api('/api/dashboard/stats');
    document.getElementById('statTotalClients').textContent = data.totalClients;
    document.getElementById('statPendingTasks').textContent = data.pendingTasks;
    document.getElementById('statDoneTasks').textContent = data.doneTasks;

    if (data.hoursStats) {
      document.getElementById('statTotalHours').textContent = `${data.hoursStats.totalHours} h`;
      document.getElementById('badgeHoursSummary').textContent = `${data.hoursStats.totalHours}h`;
      const payText = currentUser.role === 'worker' ? 'Vaša zarada' : 'Ukupan obračun';
      if (!isEarningsVisible) {
        document.getElementById('statHoursSubtext').innerHTML = `<span class="cursor-pointer select-none text-slate-500 hover:text-emerald-700 font-semibold" onclick="toggleEarningsVisibility()" title="Kliknite da vidite iznos">${payText}: •••••• KM <i data-lucide="eye" class="w-3 h-3 inline ml-0.5"></i></span>`;
      } else {
        document.getElementById('statHoursSubtext').innerHTML = `<span class="cursor-pointer select-none font-semibold text-emerald-700" onclick="toggleEarningsVisibility()" title="Kliknite da sakrijete">${payText}: ${formatCurrency(data.hoursStats.totalPay)} <i data-lucide="eye-off" class="w-3 h-3 inline ml-0.5 text-slate-400"></i></span>`;
      }
      document.getElementById('statHoursTitle').textContent = currentUser.role === 'worker' ? 'Moji Sati (Mjesec)' : 'Radni Sati (Mjesec)';
    }

    if (data.financeStats) {
      document.getElementById('statTotalDebt').textContent = formatCurrency(data.financeStats.totalDebt);
      document.getElementById('badgeDebtorsCount').textContent = data.financeStats.debtorsCount;

      // Render recent payments
      const pContainer = document.getElementById('dashboardPaymentsList');
      if (data.financeStats.recentPayments && data.financeStats.recentPayments.length > 0) {
        pContainer.innerHTML = data.financeStats.recentPayments.map(p => `
          <div class="flex items-center justify-between p-3 bg-slate-50 hover:bg-emerald-50/50 rounded-xl border border-slate-100 transition">
            <div>
              <div class="font-bold text-slate-800 text-xs">${escapeHtml(p.client_name)}</div>
              <div class="text-[10px] text-slate-400">${p.payment_date} • ${p.payment_method === 'bank' ? 'Preko banke' : 'Gotovina'}</div>
            </div>
            <div class="text-right">
              <span class="font-extrabold text-emerald-600 text-xs">+${formatCurrency(p.amount)}</span>
            </div>
          </div>
        `).join('');
      } else {
        pContainer.innerHTML = '<p class="text-xs text-slate-400 py-3 text-center">Nema nedavnih uplata.</p>';
      }
    }

    // Load recent tasks on dashboard
    const tasksData = await api('/api/tasks');
    const recentTasks = tasksData.tasks.slice(0, 5);
    const tContainer = document.getElementById('dashboardTasksList');
    if (recentTasks.length > 0) {
      tContainer.innerHTML = recentTasks.map(t => `
        <div class="flex items-center justify-between p-3 bg-slate-50 hover:bg-[#D4AF37]/10 rounded-xl border border-slate-800 transition">
          <div class="min-w-0 pr-2">
            <div class="font-bold text-slate-800 text-xs truncate">${escapeHtml(t.title)}</div>
            <div class="text-[10px] text-slate-500 flex items-center gap-1.5 mt-0.5">
              <span>${escapeHtml(t.client_name)}</span>
              <span>•</span>
              <div class="inline-flex items-center gap-1">
                ${getUserAvatar(t.assigned_avatar || t.assigned_name, 'w-4 h-4', 'text-[8px]')}
                <span class="font-medium text-slate-600">${escapeHtml(t.assigned_name || 'Neraspoređeno')}</span>
              </div>
            </div>
          </div>
          <div>
            ${renderTaskStatusBadge(t.status)}
          </div>
        </div>
      `).join('');
    } else {
      tContainer.innerHTML = '<p class="text-xs text-slate-400 py-3 text-center">Nema aktivnih zadataka.</p>';
    }

    refreshIcons();
  } catch (err) {
    console.error('Error loading dashboard:', err);
  }
}

// ==================== CLIENTS ====================
async function loadClients() {
  const search = document.getElementById('clientSearchInput').value;
  const status = document.getElementById('clientStatusFilter').value;

  try {
    const data = await api(`/api/clients?search=${encodeURIComponent(search)}&status=${encodeURIComponent(status)}`);
    const container = document.getElementById('clientsGrid');

    if (data.clients.length === 0) {
      container.innerHTML = `
        <div class="col-span-full py-12 text-center text-slate-400 bg-white rounded-2xl border border-dashed border-slate-300">
          <i data-lucide="user-x" class="w-10 h-10 mx-auto text-slate-300 mb-2"></i>
          <p class="font-bold text-sm">Nema pronađenih klijenata</p>
          <p class="text-xs mt-1">Dodajte novog klijenta klikom na dugme "Novi Klijent"</p>
        </div>
      `;
      refreshIcons();
      return;
    }

    const isFinance = currentUser.role === 'admin' || currentUser.role === 'secretary';

    container.innerHTML = data.clients.map(c => {
      const hasDebt = isFinance && c.total_debt > 0;
      return `
        <div class="bg-white rounded-2xl border border-slate-800 shadow-sm p-5 hover:border-[#D4AF37]/50 transition flex flex-col justify-between">
          <div>
            <div class="flex items-start justify-between gap-2 mb-2">
              <h3 class="font-extrabold text-white text-base leading-tight">${escapeHtml(c.name)}</h3>
              <span class="text-[10px] font-bold px-2 py-0.5 rounded-full ${c.status === 'active' ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800' : 'bg-slate-800 text-slate-400'}">
                ${c.status === 'active' ? 'Aktivan' : c.status}
              </span>
            </div>

            <div class="space-y-1 text-xs text-slate-300 mb-4">
              ${c.contact_person ? `<div class="flex items-center gap-1.5"><i data-lucide="user" class="w-3.5 h-3.5 text-[#DFC68A]"></i><span>${escapeHtml(c.contact_person)}</span></div>` : ''}
              ${c.phone ? `<div class="flex items-center gap-1.5"><i data-lucide="phone" class="w-3.5 h-3.5 text-[#DFC68A]"></i><a href="tel:${c.phone}" class="text-[#ECC968] font-semibold hover:underline">${escapeHtml(c.phone)}</a></div>` : ''}
              ${c.city ? `<div class="flex items-center gap-1.5"><i data-lucide="map-pin" class="w-3.5 h-3.5 text-[#DFC68A]"></i><span>${escapeHtml(c.city)}</span></div>` : ''}
              ${isFinance && c.notes ? `<div class="p-2 bg-[#0B0D13] rounded-lg text-xs text-[#DFC68A] font-medium border border-slate-800 mt-2"><span class="text-[10px] text-slate-400 font-bold uppercase block mb-0.5">Ugovoreni paket:</span>${escapeHtml(c.notes)}</div>` : ''}
            </div>

            <!-- Task stats bar -->
            <div class="p-2.5 bg-[#0B0D13] rounded-xl mb-3 text-xs flex justify-between items-center border border-slate-800">
              <span class="text-slate-400 font-medium">Plan rada:</span>
              <span class="font-bold text-white">
                <span class="text-emerald-400">${c.completed_tasks} urađeno</span> / <span class="text-amber-400">${c.pending_tasks} u toku</span>
              </span>
            </div>

            <!-- Finance stats (only for director & secretary) -->
            ${isFinance ? `
              <div class="p-2.5 rounded-xl text-xs flex justify-between items-center ${hasDebt ? 'bg-rose-950/70 border border-rose-800 text-rose-300' : 'bg-emerald-950/70 border border-emerald-800 text-emerald-300'}">
                <span class="font-semibold">${hasDebt ? 'Duguje:' : 'Stanje:'}</span>
                <span class="font-extrabold">${hasDebt ? formatCurrency(c.total_debt) : 'Izmireno'}</span>
              </div>
            ` : ''}
          </div>

          <div class="pt-4 mt-3 border-t border-slate-800/80 flex items-center justify-between">
            <button onclick="openClientDetail(${c.id})" class="text-xs font-bold text-[#ECC968] hover:text-[#F5D77F] flex items-center gap-1">
              <span>Kartica klijenta</span>
              <i data-lucide="chevron-right" class="w-3.5 h-3.5"></i>
            </button>
            <div class="flex items-center gap-1.5">
              ${isFinance ? `
                <button onclick="openClientModal(${c.id})" title="Uredi podatke i cijenu paketa" class="text-[11px] bg-amber-500/20 hover:bg-amber-500/30 text-[#ECC968] font-bold px-2 py-1 rounded-lg border border-amber-500/40 flex items-center gap-1 transition">
                  <i data-lucide="edit-3" class="w-3 h-3"></i>
                  <span>Uredi</span>
                </button>
              ` : ''}
              <button onclick="quickAddTaskForClient(${c.id}, '${escapeHtml(c.name)}')" class="text-[11px] bg-slate-800 hover:bg-slate-700 text-white font-bold px-2.5 py-1 rounded-lg border border-slate-700">
                + Zadatak
              </button>
            </div>
          </div>
        </div>
      `;
    }).join('');

    refreshIcons();
  } catch (err) {
    console.error('Error loading clients:', err);
  }
}

async function openClientModal(clientId = null) {
  const form = document.getElementById('clientForm');
  if (form) form.reset();

  const titleEl = document.getElementById('clientModalTitle');
  const idEl = document.getElementById('clientId');
  const deleteBtn = document.getElementById('btnDeleteClient');
  const submitBtn = document.getElementById('clientSubmitBtn');

  if (clientId) {
    try {
      const data = await api(`/api/clients/${clientId}`);
      const c = data.client;
      if (idEl) idEl.value = c.id;
      if (titleEl) titleEl.textContent = `Uredi Klijenta: ${c.name}`;
      if (submitBtn) submitBtn.textContent = 'Sačuvaj Izmjene';
      if (deleteBtn) deleteBtn.classList.remove('hidden');

      document.getElementById('clientName').value = c.name || '';
      document.getElementById('clientContact').value = c.contact_person || '';
      document.getElementById('clientPhone').value = c.phone || '';
      document.getElementById('clientEmail').value = c.email || '';
      document.getElementById('clientCity').value = c.city || '';
      document.getElementById('clientAddress').value = c.address || '';
      document.getElementById('clientNotes').value = c.notes || '';
      document.getElementById('clientMonthlyPackage').value = c.monthly_package || '';
      document.getElementById('clientPaymentDay').value = c.payment_day_desc || '';
      document.getElementById('clientCurrency').value = c.currency || 'KM';
      document.getElementById('clientStatus').value = c.status || 'active';

      // Dugovanja klijenta
      const debtAmountEl = document.getElementById('clientDebtAmount');
      const oldDebtEl = document.getElementById('clientOldDebtAmount');
      const debtNotesEl = document.getElementById('clientDebtNotes');

      const totalDebt = (data.financeSummary && data.financeSummary.totalDebt !== undefined) 
        ? data.financeSummary.totalDebt 
        : 0;

      const debtBill = data.billing?.find(b => b.billing_type === 'debt' && b.status !== 'paid');
      const oldDebtVal = debtBill ? (debtBill.total_amount - debtBill.paid_amount) : 0;

      if (debtAmountEl) debtAmountEl.value = totalDebt;
      if (oldDebtEl) oldDebtEl.value = oldDebtVal;
      if (debtNotesEl) debtNotesEl.value = debtBill?.notes || c.notes || '';
    } catch (err) {
      alert('Greška pri učitavanju klijenta: ' + err.message);
      return;
    }
  } else {
    if (idEl) idEl.value = '';
    if (titleEl) titleEl.textContent = 'Novi Klijent';
    if (submitBtn) submitBtn.textContent = 'Sačuvaj Klijenta';
    if (deleteBtn) deleteBtn.classList.add('hidden');
    document.getElementById('clientCurrency').value = 'KM';
    document.getElementById('clientStatus').value = 'active';

    const debtAmountEl = document.getElementById('clientDebtAmount');
    const oldDebtEl = document.getElementById('clientOldDebtAmount');
    const debtNotesEl = document.getElementById('clientDebtNotes');
    if (debtAmountEl) debtAmountEl.value = '0';
    if (oldDebtEl) oldDebtEl.value = '0';
    if (debtNotesEl) debtNotesEl.value = '';
  }

  openModal('clientModal');
}

function setClientDebtToZero() {
  const debtAmountEl = document.getElementById('clientDebtAmount');
  const oldDebtEl = document.getElementById('clientOldDebtAmount');
  const debtNotesEl = document.getElementById('clientDebtNotes');
  if (debtAmountEl) debtAmountEl.value = '0';
  if (oldDebtEl) oldDebtEl.value = '0';
  if (debtNotesEl) debtNotesEl.value = 'Sve izmireno u cjelosti.';
}

async function handleSaveClient(e) {
  e.preventDefault();
  const id = document.getElementById('clientId').value;
  const name = document.getElementById('clientName').value.trim();
  const contact_person = document.getElementById('clientContact').value.trim();
  const phone = document.getElementById('clientPhone').value.trim();
  const email = document.getElementById('clientEmail').value.trim();
  const city = document.getElementById('clientCity').value.trim();
  const address = document.getElementById('clientAddress').value.trim();
  const notes = document.getElementById('clientNotes').value.trim();
  const monthly_package = document.getElementById('clientMonthlyPackage').value;
  const payment_day_desc = document.getElementById('clientPaymentDay').value.trim();
  const currency = document.getElementById('clientCurrency').value;
  const status = document.getElementById('clientStatus').value;

  const target_debt = document.getElementById('clientDebtAmount')?.value;
  const old_debt = document.getElementById('clientOldDebtAmount')?.value;
  const debt_notes = document.getElementById('clientDebtNotes')?.value.trim();

  const payload = {
    name,
    contact_person,
    phone,
    email,
    city,
    address,
    notes,
    monthly_package: monthly_package !== '' ? parseFloat(monthly_package) : 0,
    payment_day_desc,
    currency,
    status,
    target_debt: (target_debt !== '' && target_debt !== undefined) ? parseFloat(target_debt) : undefined,
    old_debt: (old_debt !== '' && old_debt !== undefined) ? parseFloat(old_debt) : undefined,
    debt_notes: debt_notes || undefined
  };

  try {
    if (id) {
      await api(`/api/clients/${id}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      });
      showNotification('Podaci o klijentu i cijeni paketa uspješno ažurirani!');
    } else {
      await api('/api/clients', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
      showNotification('Novi klijent je uspješno sačuvan!');
    }

    closeModal('clientModal');
    await loadDropdownData();
    if (currentTab === 'clients') loadClients();
    if (currentTab === 'secretary') loadMonthlyClients();
    if (currentTab === 'dashboard') loadDashboard();
  } catch (err) {
    alert(err.message);
  }
}

async function handleDeleteCurrentClient() {
  const id = document.getElementById('clientId').value;
  const name = document.getElementById('clientName').value;
  if (!id) return;

  if (!confirm(`Jeste li sigurni da želite obrisati klijenta "${name}"?`)) return;

  try {
    await api(`/api/clients/${id}`, { method: 'DELETE' });
    closeModal('clientModal');
    await loadDropdownData();
    if (currentTab === 'clients') loadClients();
    if (currentTab === 'secretary') loadMonthlyClients();
    if (currentTab === 'dashboard') loadDashboard();
    showNotification(`Klijent "${name}" je uspješno obrisan!`);
  } catch (err) {
    alert(err.message);
  }
}

function editClientFromDetail() {
  if (!currentDetailedClientId) return;
  const id = currentDetailedClientId;
  closeModal('clientDetailModal');
  openClientModal(id);
}

// Client Details Modal
async function openClientDetail(clientId) {
  currentDetailedClientId = clientId;
  try {
    const data = await api(`/api/clients/${clientId}`);
    const c = data.client;

    document.getElementById('cdName').textContent = c.name;
    document.getElementById('cdMeta').textContent = `${c.contact_person || 'Nema kontakta'} • ${c.city || 'Grad nije naveden'}`;
    document.getElementById('cdPhone').textContent = c.phone || '-';
    document.getElementById('cdEmail').textContent = c.email || '-';
    document.getElementById('cdAddress').textContent = `${c.address || ''} ${c.city ? '(' + c.city + ')' : ''}` || '-';

    const pkgEl = document.getElementById('cdPackage');
    if (pkgEl) {
      if (c.monthly_package > 0) {
        pkgEl.textContent = `${formatCurrency(c.monthly_package)} (${c.payment_day_desc || 'po dogovoru'})`;
      } else {
        pkgEl.textContent = c.notes ? c.notes.substring(0, 30) : 'Bez fiksnog paketa';
      }
    }

    // Tasks for client
    const tasksContainer = document.getElementById('cdTasksList');
    if (data.tasks.length === 0) {
      tasksContainer.innerHTML = '<p class="text-slate-400 text-xs italic py-2">Nema zadataka za ovog klijenta. Kliknite "+ Dodaj zadatak".</p>';
    } else {
      tasksContainer.innerHTML = data.tasks.map(t => `
        <div class="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between gap-3">
          <div class="min-w-0">
            <div class="font-bold text-slate-900">${escapeHtml(t.title)}</div>
            <div class="text-[11px] text-slate-500 mt-0.5">${escapeHtml(t.description || 'Bez dodatnog opisa')}</div>
            ${t.completed_note ? `<div class="text-[10px] text-emerald-700 font-semibold mt-1 bg-emerald-50 p-1.5 rounded">✓ Urađeno: ${escapeHtml(t.completed_note)}</div>` : ''}
          </div>
          <div class="flex items-center gap-2 shrink-0">
            ${renderTaskStatusBadge(t.status)}
            ${t.status !== 'done' ? `<button onclick="promptCompleteTask(${t.id})" class="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[10px] font-bold">Završi</button>` : ''}
          </div>
        </div>
      `).join('');
    }

    // Finance section (if allowed)
    const isFinance = currentUser.role === 'admin' || currentUser.role === 'secretary';
    const finSec = document.getElementById('cdFinanceSection');
    const finBlock = document.getElementById('cdFinanceBlock');

    if (isFinance && data.financeSummary) {
      finSec.classList.remove('hidden');
      finBlock.classList.remove('hidden');
      document.getElementById('cdDebt').textContent = formatCurrency(data.financeSummary.totalDebt);

      const invContainer = document.getElementById('cdInvoicesList');
      if (data.billing.length === 0) {
        invContainer.innerHTML = '<p class="text-slate-400 text-xs italic py-2">Nema zaduženja za ovog klijenta.</p>';
      } else {
        invContainer.innerHTML = data.billing.map(b => {
          const debt = b.total_amount - b.paid_amount;
          return `
            <div class="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
              <div>
                <div class="font-bold text-slate-900">${escapeHtml(b.title)} <span class="text-slate-400 font-normal">(${b.invoice_number || 'Bez broja'})</span></div>
                <div class="text-[11px] text-slate-500">Rok: ${b.due_date || 'Nije postavljen'}</div>
              </div>
              <div class="text-right">
                <div>Ugovoreno: <span class="font-bold">${formatCurrency(b.total_amount)}</span></div>
                <div>Plaćeno: <span class="font-bold text-emerald-600">${formatCurrency(b.paid_amount)}</span></div>
                ${debt > 0 ? `<div class="text-rose-600 font-extrabold">Dug: ${formatCurrency(debt)}</div>` : '<div class="text-emerald-700 font-bold">Plaćeno u cjelosti</div>'}
              </div>
            </div>
          `;
        }).join('');
      }
    } else {
      finSec.classList.add('hidden');
      finBlock.classList.add('hidden');
    }

    openModal('clientDetailModal');
    refreshIcons();
  } catch (err) {
    alert('Greška pri učitavanju detalja: ' + err.message);
  }
}

function openAddTaskForClient() {
  closeModal('clientDetailModal');
  document.getElementById('taskClientId').value = currentDetailedClientId;
  openModal('taskModal');
}

function openAddInvoiceForClient() {
  closeModal('clientDetailModal');
  document.getElementById('invoiceClientId').value = currentDetailedClientId;
  openModal('invoiceModal');
}

function openAddPaymentForClient() {
  closeModal('clientDetailModal');
  document.getElementById('paymentClientId').value = currentDetailedClientId;
  loadClientUnpaidBills(currentDetailedClientId);
  openModal('paymentModal');
}

function quickAddTaskForClient(clientId, clientName) {
  document.getElementById('taskClientId').value = clientId;
  openModal('taskModal');
}

// ==================== TASKS (PLAN I PROGRAM RADA) ====================
let currentTasksView = 'kanban'; // 'kanban' or 'table'

function setTasksView(mode) {
  currentTasksView = mode;
  const kanbanContainer = document.getElementById('tasksKanbanView');
  const tableContainer = document.getElementById('tasksTableView');
  const btnKanban = document.getElementById('btnViewKanban');
  const btnTable = document.getElementById('btnViewTable');

  if (mode === 'table') {
    if (kanbanContainer) kanbanContainer.classList.add('hidden');
    if (tableContainer) tableContainer.classList.remove('hidden');
    if (btnTable) {
      btnTable.className = 'px-3 py-1.5 rounded-lg text-xs font-bold gold-btn text-slate-950 transition flex items-center gap-1.5 shadow';
    }
    if (btnKanban) {
      btnKanban.className = 'px-3 py-1.5 rounded-lg text-xs font-bold bg-[#121622] text-slate-300 hover:text-white transition flex items-center gap-1.5';
    }
  } else {
    if (tableContainer) tableContainer.classList.add('hidden');
    if (kanbanContainer) kanbanContainer.classList.remove('hidden');
    if (btnKanban) {
      btnKanban.className = 'px-3 py-1.5 rounded-lg text-xs font-bold gold-btn text-slate-950 transition flex items-center gap-1.5 shadow';
    }
    if (btnTable) {
      btnTable.className = 'px-3 py-1.5 rounded-lg text-xs font-bold bg-[#121622] text-slate-300 hover:text-white transition flex items-center gap-1.5';
    }
  }
}

async function loadTasks() {
  const search = document.getElementById('taskSearchInput')?.value || '';
  const status = document.getElementById('taskStatusFilter')?.value || 'all';
  const clientId = document.getElementById('taskClientFilter')?.value || '';
  let workerId = document.getElementById('taskWorkerFilter')?.value || '';
  const taskType = document.getElementById('taskTypeFilter')?.value || '';

  // Ako gleda "Moji zadaci", filtriraj automatski po trenutno prijavljenom radniku
  if (currentTaskScope === 'my' && currentUser) {
    workerId = currentUser.id;
  }

  try {
    let url = `/api/tasks?search=${encodeURIComponent(search)}&status=${encodeURIComponent(status)}&client_id=${clientId}`;
    if (workerId) url += `&assigned_user_id=${workerId}`;
    if (taskType) url += `&task_type=${encodeURIComponent(taskType)}`;

    const data = await api(url);
    const tasks = data.tasks;

    const pendingCount = tasks.filter(t => t.status !== 'done').length;
    const badgeTasks = document.getElementById('badgeTasksCount');
    if (badgeTasks) badgeTasks.textContent = pendingCount;

    // Distribute into 3 columns: Todo, In Progress, Done
    const colTodo = document.getElementById('colTasksTodo');
    const colInProgress = document.getElementById('colTasksInProgress');
    const colDone = document.getElementById('colTasksDone');

    const tasksTodo = tasks.filter(t => t.status === 'todo' || t.status === 'blocked');
    const tasksInProgress = tasks.filter(t => t.status === 'in_progress');
    const tasksDone = tasks.filter(t => t.status === 'done');

    if (document.getElementById('countColTodo')) document.getElementById('countColTodo').textContent = tasksTodo.length;
    if (document.getElementById('countColInProgress')) document.getElementById('countColInProgress').textContent = tasksInProgress.length;
    if (document.getElementById('countColDone')) document.getElementById('countColDone').textContent = tasksDone.length;

    // Update KPI metric counters
    if (document.getElementById('taskStatTotal')) document.getElementById('taskStatTotal').textContent = tasks.length;
    if (document.getElementById('taskStatDone')) document.getElementById('taskStatDone').textContent = tasksDone.length;
    if (document.getElementById('taskStatInProgress')) document.getElementById('taskStatInProgress').textContent = tasksInProgress.length;
    if (document.getElementById('taskStatTodo')) document.getElementById('taskStatTodo').textContent = tasksTodo.length;

    if (colTodo) renderTaskColumn(colTodo, tasksTodo);
    if (colInProgress) renderTaskColumn(colInProgress, tasksInProgress);
    if (colDone) renderTaskColumn(colDone, tasksDone);

    renderTasksTable(tasks);

    refreshIcons();
  } catch (err) {
    console.error('Error loading tasks:', err);
  }
}

function renderTaskColumn(container, tasks) {
  if (tasks.length === 0) {
    container.innerHTML = '<div class="p-6 text-center text-xs text-slate-400 bg-white/60 rounded-xl border border-dashed border-slate-200">Nema zadataka u ovoj koloni</div>';
    return;
  }

  container.innerHTML = tasks.map(t => {
    let priorityBadge = '';
    if (t.priority === 'urgent') {
      priorityBadge = '<span class="text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded bg-rose-500/20 text-rose-400 border border-rose-500/30">Hitno</span>';
    } else if (t.priority === 'high') {
      priorityBadge = '<span class="text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">Visok</span>';
    } else {
      priorityBadge = '<span class="text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30">Srednji</span>';
    }

    let typeBadge = t.task_type ? `<span class="text-[10px] font-bold px-2 py-0.5 rounded bg-[#D4AF37]/15 text-[#DFC68A] border border-[#D4AF37]/30">${escapeHtml(t.task_type)}</span>` : '';

    return `
      <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition space-y-2">
        <div class="flex items-start justify-between gap-2">
          <div class="flex items-center gap-1.5 flex-wrap">
            ${priorityBadge}
            ${typeBadge}
          </div>
          <span class="text-[10px] text-slate-400 font-medium whitespace-nowrap">${t.due_date ? 'Rok: ' + t.due_date : (t.task_date || '')}</span>
        </div>

        <div>
          <h4 class="font-bold text-slate-900 text-sm leading-snug">${escapeHtml(t.title)}</h4>
          <p class="text-xs text-[#ECC968] font-extrabold mt-1">${escapeHtml(t.client_name)}</p>
          ${t.description ? `<p class="text-xs text-slate-400 mt-1 line-clamp-2">${escapeHtml(t.description)}</p>` : ''}
        </div>

        ${t.completed_note ? `
          <div class="p-2 bg-emerald-500/10 rounded-lg text-[11px] text-emerald-400 border border-emerald-500/20">
            <strong>✓ Izvještaj o radu:</strong> ${escapeHtml(t.completed_note)}
          </div>
        ` : ''}

        <div class="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
          <div class="flex items-center gap-1.5 text-slate-400 text-[11px]">
            ${getUserAvatar(t.assigned_avatar || t.assigned_name, 'w-5 h-5', 'text-[9px]')}
            <span class="font-semibold text-slate-300">${escapeHtml(t.assigned_name || 'Neraspoređeno')}</span>
          </div>

          <!-- Quick state change buttons -->
          <div class="flex gap-1">
            ${t.status === 'todo' ? `
              <button onclick="updateTaskStatus(${t.id}, 'in_progress')" class="px-2 py-1 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded text-[10px] font-extrabold shadow-sm transition">Počni rad</button>
              <button onclick="updateTaskStatus(${t.id}, 'done')" class="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[10px] font-bold shadow-sm transition">Završi</button>
            ` : ''}

            ${t.status === 'in_progress' ? `
              <button onclick="promptCompleteTask(${t.id})" class="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[10px] font-bold shadow-sm transition">Završi rad</button>
            ` : ''}

            ${t.status === 'done' ? `
              <button onclick="updateTaskStatus(${t.id}, 'todo')" class="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[10px] font-semibold border border-slate-700 transition">Vrati u rad</button>
            ` : ''}
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function renderTasksTable(tasks) {
  const tbody = document.getElementById('tasksTableBody');
  if (!tbody) return;

  if (tasks.length === 0) {
    tbody.innerHTML = '<tr><td colspan="10" class="p-8 text-center text-sm text-slate-400">Nema pronađenih zadataka prema izabranim filterima.</td></tr>';
    return;
  }

  tbody.innerHTML = tasks.map(t => {
    let priorityBadge = '';
    if (t.priority === 'urgent') {
      priorityBadge = '<span class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider bg-rose-500/20 text-rose-400 border border-rose-500/30">Hitno</span>';
    } else if (t.priority === 'high') {
      priorityBadge = '<span class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">Visok</span>';
    } else {
      priorityBadge = '<span class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider bg-blue-500/20 text-blue-300 border border-blue-500/30">Srednji</span>';
    }

    let statusBadge = '';
    if (t.status === 'done') {
      statusBadge = '<span class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">Završeno</span>';
    } else if (t.status === 'in_progress') {
      statusBadge = '<span class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">U toku</span>';
    } else {
      statusBadge = '<span class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider bg-sky-500/20 text-sky-300 border border-sky-500/30">Čeka</span>';
    }

    let typeBadge = t.task_type ? `<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-[#D4AF37]/15 text-[#DFC68A] border border-[#D4AF37]/30">${escapeHtml(t.task_type)}</span>` : '<span class="text-slate-500">-</span>';

    return `
      <tr class="border-b border-slate-800/60 hover:bg-slate-800/30 transition text-xs">
        <td class="p-3 text-slate-400 font-mono whitespace-nowrap">${t.task_date || '-'}</td>
        <td class="p-3 font-extrabold text-[#ECC968] whitespace-nowrap">${escapeHtml(t.client_name)}</td>
        <td class="p-3 font-bold text-slate-100 max-w-xs md:max-w-md">${escapeHtml(t.title)}</td>
        <td class="p-3 font-semibold text-slate-300 whitespace-nowrap">
          <div class="flex items-center gap-2">
            ${getUserAvatar(t.assigned_avatar || t.assigned_name, 'w-6 h-6', 'text-[10px]')}
            <span>${escapeHtml(t.assigned_name || 'Neraspoređeno')}</span>
          </div>
        </td>
        <td class="p-3 whitespace-nowrap">${priorityBadge}</td>
        <td class="p-3 whitespace-nowrap">${statusBadge}</td>
        <td class="p-3 text-slate-300 whitespace-nowrap">${t.due_date || '-'}</td>
        <td class="p-3 whitespace-nowrap">${typeBadge}</td>
        <td class="p-3 text-slate-400 text-[11px] max-w-xs">${escapeHtml(t.description || '-')}</td>
        <td class="p-3 text-right whitespace-nowrap">
          <div class="flex items-center justify-end gap-1">
            ${t.status !== 'done' ? `
              <button onclick="updateTaskStatus(${t.id}, 'done')" title="Označi kao završeno" class="p-1.5 rounded bg-emerald-600/20 hover:bg-emerald-600/40 text-emerald-400 border border-emerald-500/30 transition">
                <i data-lucide="check" class="w-3.5 h-3.5"></i>
              </button>
            ` : `
              <button onclick="updateTaskStatus(${t.id}, 'todo')" title="Vrati u čeka" class="p-1.5 rounded bg-slate-700 hover:bg-slate-600 text-slate-300 transition">
                <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>
              </button>
            `}
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

async function handleCreateTask(e) {
  e.preventDefault();
  const client_id = document.getElementById('taskClientId').value;
  const title = document.getElementById('taskTitle').value.trim();
  const description = document.getElementById('taskDescription').value.trim();
  const assigned_user_id = document.getElementById('taskAssignedUser').value;
  const priority = document.getElementById('taskPriority').value;
  const due_date = document.getElementById('taskDueDate').value;
  const task_type = document.getElementById('taskModalType')?.value || 'Dizajn';

  try {
    await api('/api/tasks', {
      method: 'POST',
      body: JSON.stringify({ client_id, title, description, assigned_user_id, priority, due_date, task_type })
    });
    closeModal('taskModal');
    document.getElementById('taskForm').reset();
    loadTasks();
    fetchNotifications();
    showNotification('Zadatak uspješno dodat u plan rada i radnik je obaviješten!');
  } catch (err) {
    alert(err.message);
  }
}

async function updateTaskStatus(taskId, newStatus) {
  try {
    await api(`/api/tasks/${taskId}`, {
      method: 'PUT',
      body: JSON.stringify({ status: newStatus })
    });
    loadTasks();
    if (newStatus === 'in_progress') {
      showNotification('⚡ Preuzeli ste projekat! Direktor (Emin) i Amra su obaviješteni.');
    } else if (newStatus === 'done') {
      showNotification('✅ Projekat završen! Direktor (Emin) i Amra su obaviješteni.');
    } else {
      showNotification('Status zadatka uspješno ažuriran.');
    }
    fetchNotifications();
  } catch (err) {
    alert(err.message);
  }
}

function promptCompleteTask(taskId) {
  document.getElementById('completeTaskId').value = taskId;
  document.getElementById('completeTaskNote').value = '';
  openModal('completeTaskModal');
}

async function handleCompleteTask(e) {
  e.preventDefault();
  const taskId = document.getElementById('completeTaskId').value;
  const completed_note = document.getElementById('completeTaskNote').value.trim();

  try {
    await api(`/api/tasks/${taskId}`, {
      method: 'PUT',
      body: JSON.stringify({ status: 'done', completed_note })
    });
    closeModal('completeTaskModal');
    loadTasks();
    if (currentDetailedClientId) {
      openClientDetail(currentDetailedClientId);
    }
    showNotification('✅ Posao uspješno označen kao završen! Obavještenje je poslato direktoru i Amri.');
    fetchNotifications();
  } catch (err) {
    alert(err.message);
  }
}

// ==================== SEKRETARICA & FINANSIJE ====================
let currentFinanceMonth = '2026-10';
let currentMonthlyMeta = {
  cash_withdrawn: 0,
  opening_cash_balance: 0,
  opening_bank_balance: 0,
  notes: ''
};
let currentExpensesCache = [];

function changeFinanceMonth(month) {
  currentFinanceMonth = month;
  const select1 = document.getElementById('summaryMonthSelect');
  const select2 = document.getElementById('expensesMonthSelect');
  if (select1) select1.value = month;
  if (select2) select2.value = month;
  const badge = document.getElementById('summaryMonthBadge');
  if (badge) {
    const monthNames = {
      '2026-09': 'SEPTEMBAR 2026',
      '2026-10': 'OKTOBAR 2026',
      '2026-11': 'NOVEMBAR 2026',
      '2026-12': 'DECEMBAR 2026'
    };
    badge.textContent = `UNIKAT MD — ${monthNames[month] || month}`;
  }
  loadMonthlySummary(month);
}

function changeExpenseMonth(month) {
  changeFinanceMonth(month);
  loadExpenses(month);
}

async function loadSecretaryModule() {
  setSecretaryView('summary');
}

async function loadSecretaryStats() {
  try {
    const data = await api('/api/dashboard/stats');
    if (data.financeStats) {
      const bEl = document.getElementById('secTotalBilled');
      if (bEl) bEl.textContent = formatCurrency(data.financeStats.totalBilled);
      const cEl = document.getElementById('secTotalCollected');
      if (cEl) cEl.textContent = formatCurrency(data.financeStats.totalCollected);
      const dEl = document.getElementById('secTotalDebt');
      if (dEl) dEl.textContent = formatCurrency(data.financeStats.totalDebt);
    }
  } catch (err) {
    console.error('Error loading finance stats:', err);
  }
}

function setSecretaryView(view) {
  const views = ['summary', 'expenses', 'debtors', 'invoices', 'payments'];
  views.forEach(v => {
    const el = document.getElementById(`secView${capitalize(v)}`);
    if (el) el.classList.add('hidden');
    const btn = document.getElementById(`secBtn${capitalize(v)}`);
    if (btn) {
      btn.classList.remove('border-[#D4AF37]', 'text-[#ECC968]', 'border-indigo-600', 'text-indigo-600');
      btn.classList.add('border-transparent', 'text-slate-400');
    }
  });

  const activeEl = document.getElementById(`secView${capitalize(view)}`);
  if (activeEl) activeEl.classList.remove('hidden');
  const activeBtn = document.getElementById(`secBtn${capitalize(view)}`);
  if (activeBtn) {
    activeBtn.classList.add('border-[#D4AF37]', 'text-[#ECC968]');
    activeBtn.classList.remove('border-transparent', 'text-slate-400');
  }

  if (view === 'summary') loadMonthlySummary(currentFinanceMonth);
  if (view === 'expenses') loadExpenses(currentFinanceMonth);
  if (view === 'debtors') loadMonthlyClients(selectedClientsMonth, currentClientsFilter);
  if (view === 'invoices') loadInvoices();
  if (view === 'payments') loadPaymentsHistory();
}

async function loadMonthlySummary(month = currentFinanceMonth) {
  try {
    const data = await api(`/api/finance/monthly-summary?month=${month}`);
    currentMonthlyMeta = data.meta || currentMonthlyMeta;

    // Top Cards
    const statsData = await api('/api/dashboard/stats');
    if (statsData.financeStats) {
      const bEl = document.getElementById('secTotalBilled');
      if (bEl) bEl.textContent = formatCurrency(statsData.financeStats.totalBilled);
      const cEl = document.getElementById('secTotalCollected');
      if (cEl) cEl.textContent = formatCurrency(statsData.financeStats.totalCollected);
    }
    const expTop = document.getElementById('secTotalExpensesTop');
    if (expTop) expTop.textContent = formatCurrency(data.expenses.total);
    const profitTop = document.getElementById('secTotalNetProfitTop');
    if (profitTop) {
      const isPositive = data.balances.netProfit >= 0;
      profitTop.textContent = (isPositive ? '+' : '') + formatCurrency(data.balances.netProfit);
      profitTop.className = `text-2xl font-extrabold mt-1 ${isPositive ? 'text-[#ECC968]' : 'text-rose-500'}`;
    }

    // Hero Cards
    const heroInc = document.getElementById('sumHeroIncome');
    if (heroInc) heroInc.textContent = formatCurrency(data.income.total);
    const heroIncCount = document.getElementById('sumHeroIncomeCount');
    if (heroIncCount) heroIncCount.textContent = `(${data.income.count} uplata)`;

    const heroExp = document.getElementById('sumHeroExpenses');
    if (heroExp) heroExp.textContent = formatCurrency(data.expenses.total);
    const heroExpCount = document.getElementById('sumHeroExpenseCount');
    if (heroExpCount) heroExpCount.textContent = `(${data.expenses.count} stavki)`;

    const heroProf = document.getElementById('sumHeroProfit');
    if (heroProf) {
      const isPos = data.balances.netProfit >= 0;
      heroProf.textContent = (isPos ? '+' : '') + formatCurrency(data.balances.netProfit);
      heroProf.className = `text-3xl font-black mt-2 ${isPos ? 'text-emerald-700' : 'text-rose-600'}`;
    }

    // Gotovina breakdown
    const cashInc = document.getElementById('sumCashIncome');
    if (cashInc) cashInc.textContent = formatCurrency(data.income.cash);
    const cashWith = document.getElementById('sumCashWithdrawn');
    if (cashWith) cashWith.textContent = formatCurrency(data.meta.cash_withdrawn);
    const cashExp = document.getElementById('sumCashExpenses');
    if (cashExp) cashExp.textContent = formatCurrency(data.expenses.cash);
    const cashOpen = document.getElementById('sumCashOpening');
    if (cashOpen) cashOpen.textContent = formatCurrency(data.meta.opening_cash_balance);
    const cashBal = document.getElementById('sumCashBalance');
    if (cashBal) {
      const isPos = data.balances.cashBalance >= 0;
      cashBal.textContent = (isPos ? '+' : '') + formatCurrency(data.balances.cashBalance);
      cashBal.className = `text-xl font-black ${isPos ? 'text-emerald-700' : 'text-amber-950'}`;
    }

    // Žiralno breakdown
    const bankInc = document.getElementById('sumBankIncome');
    if (bankInc) bankInc.textContent = formatCurrency(data.income.bank);
    const bankWith = document.getElementById('sumBankWithdrawn');
    if (bankWith) bankWith.textContent = '-' + formatCurrency(data.meta.cash_withdrawn);
    const bankExp = document.getElementById('sumBankExpenses');
    if (bankExp) bankExp.textContent = '-' + formatCurrency(data.expenses.bank);
    const bankOpen = document.getElementById('sumBankOpening');
    if (bankOpen) bankOpen.textContent = formatCurrency(data.meta.opening_bank_balance);
    const bankBal = document.getElementById('sumBankBalance');
    if (bankBal) {
      const isPos = data.balances.bankBalance >= 0;
      bankBal.textContent = (isPos ? '+' : '') + formatCurrency(data.balances.bankBalance);
      bankBal.className = `text-xl font-black ${isPos ? 'text-indigo-950' : 'text-rose-600'}`;
    }

    // Stanje Box
    const boxCash = document.getElementById('sumBoxCash');
    if (boxCash) boxCash.textContent = formatCurrency(data.balances.cashBalance);
    const boxBank = document.getElementById('sumBoxBank');
    if (boxBank) boxBank.textContent = formatCurrency(data.balances.bankBalance);
    const boxFunds = document.getElementById('sumBoxFunds');
    if (boxFunds) boxFunds.textContent = formatCurrency(data.balances.totalAvailableFunds);
    const boxProfit = document.getElementById('sumBoxProfit');
    if (boxProfit) {
      const isPos = data.balances.netProfit >= 0;
      boxProfit.textContent = (isPos ? '+' : '') + formatCurrency(data.balances.netProfit);
      boxProfit.className = `text-lg font-black mt-1 ${isPos ? 'text-emerald-700' : 'text-rose-600'}`;
    }

    // NAMA DUG Table (Potraživanja)
    const recBadge = document.getElementById('receivablesTotalBadge');
    if (recBadge) recBadge.textContent = formatCurrency(data.receivables.total);
    const recBody = document.getElementById('receivablesTableBody');
    if (recBody) {
      if (data.receivables.list.length === 0) {
        recBody.innerHTML = '<tr><td colspan="3" class="p-4 text-center text-slate-400">Sva potraživanja su izmirena! Nema dužnika.</td></tr>';
      } else {
        recBody.innerHTML = data.receivables.list.map(r => `
          <tr class="hover:bg-rose-50/40 transition">
            <td class="p-2.5 font-bold text-slate-900">${escapeHtml(r.name)}</td>
            <td class="p-2.5 text-slate-500 text-[11px]">${escapeHtml(r.note || 'Mjesečni paket marketinga')}</td>
            <td class="p-2.5 text-right font-extrabold text-rose-600 text-xs">${formatCurrency(r.debt)}</td>
          </tr>
        `).join('');
      }
    }

    // DUGUJEMO Table (Obaveze firme)
    const libBody = document.getElementById('liabilitiesTableBody');
    if (libBody) {
      if (data.liabilities.list.length === 0) {
        libBody.innerHTML = '<tr><td colspan="5" class="p-4 text-center text-slate-400">Firma nema evidentiranih dugovanja prema trećim licima.</td></tr>';
      } else {
        libBody.innerHTML = data.liabilities.list.map(l => {
          const remaining = l.amount - (l.paid_amount || 0);
          return `
            <tr class="hover:bg-slate-50 transition">
              <td class="p-2.5 font-bold text-slate-900">${escapeHtml(l.creditor_name)}</td>
              <td class="p-2.5 text-slate-500 text-[11px]">${escapeHtml(l.description || '-')}</td>
              <td class="p-2.5 text-right font-extrabold text-slate-800">${formatCurrency(remaining)}</td>
              <td class="p-2.5 text-center">
                <span class="px-2 py-0.5 rounded text-[10px] font-bold ${l.status === 'paid' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}">
                  ${l.status === 'paid' ? 'Izmireno' : 'Dugujemo'}
                </span>
              </td>
              <td class="p-2.5 text-center">
                <button onclick="deleteLiability(${l.id})" class="text-rose-500 hover:text-rose-700 text-xs p-1" title="Obriši">
                  <i data-lucide="trash-2" class="w-3.5 h-3.5 inline"></i>
                </button>
              </td>
            </tr>
          `;
        }).join('');
      }
    }

    if (window.lucide) lucide.createIcons();
  } catch (err) {
    console.error('Error loading monthly summary:', err);
  }
}

async function loadExpenses(month = currentFinanceMonth) {
  try {
    const data = await api(`/api/finance/expenses?month=${month}`);
    currentExpensesCache = data.expenses;

    const grand = document.getElementById('expGrandTotal');
    if (grand) grand.textContent = formatCurrency(data.totals.totalExpenses);
    const cash = document.getElementById('expCashTotal');
    if (cash) cash.textContent = formatCurrency(data.totals.totalCash);
    const bank = document.getElementById('expBankTotal');
    if (bank) bank.textContent = formatCurrency(data.totals.totalBank);

    const tbody = document.getElementById('expensesTableBody');
    if (!tbody) return;

    if (data.expenses.length === 0) {
      tbody.innerHTML = '<tr><td colspan="7" class="p-6 text-center text-slate-400">Nema unesenih troškova za odabrani mjesec.</td></tr>';
      return;
    }

    tbody.innerHTML = data.expenses.map(e => {
      const isCash = e.payment_method === 'gotovina';
      const isBank = e.payment_method === 'ziralno';
      const methodBadge = isCash 
        ? '<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">Gotovina</span>'
        : (isBank ? '<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-900 border border-blue-300">Žiralno</span>'
        : '<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-800">Ostalo</span>');

      return `
        <tr class="hover:bg-slate-50/80 transition">
          <td class="p-3 text-center font-bold text-slate-400">${e.item_order || '-'}</td>
          <td class="p-3">
            <div class="font-extrabold text-slate-900 text-xs">${escapeHtml(e.title)}</div>
          </td>
          <td class="p-3 text-slate-600 font-medium">${escapeHtml(e.payment_date_desc || '-')}</td>
          <td class="p-3 text-right font-black text-rose-600 text-sm">
            ${e.amount > 0 ? formatCurrency(e.amount) : '<span class="text-slate-400 font-normal">0,00 KM</span>'}
          </td>
          <td class="p-3 text-center">${methodBadge}</td>
          <td class="p-3 text-slate-500 text-[11px]">${escapeHtml(e.notes || '-')}</td>
          <td class="p-3 text-center">
            <div class="flex items-center justify-center gap-1.5">
              <button onclick="openExpenseModal(${e.id})" class="px-2 py-1 text-[11px] font-bold rounded bg-slate-100 hover:bg-slate-200 text-slate-700 transition" title="Uredi trošak">
                Uredi
              </button>
              <button onclick="deleteExpense(${e.id})" class="p-1 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded transition" title="Obriši">
                <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');

    if (window.lucide) lucide.createIcons();
  } catch (err) {
    console.error('Error loading expenses:', err);
  }
}

function openExpenseModal(expenseId = null) {
  const modal = document.getElementById('expenseModal');
  const form = document.getElementById('expenseForm');
  form.reset();

  if (expenseId) {
    const item = currentExpensesCache.find(e => e.id === expenseId);
    if (item) {
      document.getElementById('expenseModalTitle').innerHTML = '<i data-lucide="receipt" class="w-5 h-5 text-rose-600"></i><span>Uredi Trošak</span>';
      document.getElementById('expenseId').value = item.id;
      document.getElementById('expenseMonth').value = item.month;
      document.getElementById('expenseOrder').value = item.item_order || '';
      document.getElementById('expenseTitle').value = item.title;
      document.getElementById('expenseAmount').value = item.amount;
      document.getElementById('expensePaymentMethod').value = item.payment_method;
      document.getElementById('expenseDateDesc').value = item.payment_date_desc || '';
      document.getElementById('expenseNotes').value = item.notes || '';
    }
  } else {
    document.getElementById('expenseModalTitle').innerHTML = '<i data-lucide="receipt" class="w-5 h-5 text-rose-600"></i><span>Evidentiraj Mjesečni Trošak</span>';
    document.getElementById('expenseId').value = '';
    document.getElementById('expenseMonth').value = currentFinanceMonth;
    document.getElementById('expenseOrder').value = (currentExpensesCache.length + 1);
  }

  modal.classList.remove('hidden');
  if (window.lucide) lucide.createIcons();
}

async function handleSaveExpense(e) {
  e.preventDefault();
  const id = document.getElementById('expenseId').value;
  const month = document.getElementById('expenseMonth').value.trim();
  const item_order = document.getElementById('expenseOrder').value;
  const title = document.getElementById('expenseTitle').value.trim();
  const amount = document.getElementById('expenseAmount').value;
  const payment_method = document.getElementById('expensePaymentMethod').value;
  const payment_date_desc = document.getElementById('expenseDateDesc').value.trim();
  const notes = document.getElementById('expenseNotes').value.trim();

  try {
    if (id) {
      await api(`/api/finance/expenses/${id}`, {
        method: 'PUT',
        body: JSON.stringify({ title, amount, payment_method, payment_date_desc, notes, item_order })
      });
      showNotification('Trošak uspješno ažuriran!');
    } else {
      await api('/api/finance/expenses', {
        method: 'POST',
        body: JSON.stringify({ month, title, amount, payment_method, payment_date_desc, notes, item_order })
      });
      showNotification('Novi trošak uspješno evidentiran!');
    }

    closeModal('expenseModal');
    loadExpenses(month);
    loadMonthlySummary(month);
  } catch (err) {
    alert(err.message);
  }
}

async function deleteExpense(id) {
  if (!confirm('Da li ste sigurni da želite obrisati ovaj trošak?')) return;
  try {
    await api(`/api/finance/expenses/${id}`, { method: 'DELETE' });
    showNotification('Trošak obrisan.');
    loadExpenses(currentFinanceMonth);
    loadMonthlySummary(currentFinanceMonth);
  } catch (err) {
    alert(err.message);
  }
}

function openFinanceMetaModal() {
  document.getElementById('metaCashWithdrawn').value = currentMonthlyMeta.cash_withdrawn || 0;
  document.getElementById('metaCashOpening').value = currentMonthlyMeta.opening_cash_balance || 0;
  document.getElementById('metaBankOpening').value = currentMonthlyMeta.opening_bank_balance || 0;
  document.getElementById('metaNotes').value = currentMonthlyMeta.notes || '';
  document.getElementById('financeMetaModal').classList.remove('hidden');
}

async function handleSaveFinanceMeta(e) {
  e.preventDefault();
  const cash_withdrawn = document.getElementById('metaCashWithdrawn').value;
  const opening_cash_balance = document.getElementById('metaCashOpening').value;
  const opening_bank_balance = document.getElementById('metaBankOpening').value;
  const notes = document.getElementById('metaNotes').value.trim();

  try {
    await api(`/api/finance/monthly-meta/${currentFinanceMonth}`, {
      method: 'PUT',
      body: JSON.stringify({ cash_withdrawn, opening_cash_balance, opening_bank_balance, notes })
    });
    closeModal('financeMetaModal');
    showNotification('Parametri kase i računa uspješno ažurirani!');
    loadMonthlySummary(currentFinanceMonth);
  } catch (err) {
    alert(err.message);
  }
}

async function handleSaveLiability(e) {
  e.preventDefault();
  const id = document.getElementById('liabilityId').value;
  const creditor_name = document.getElementById('liabilityCreditor').value.trim();
  const description = document.getElementById('liabilityDescription').value.trim();
  const amount = document.getElementById('liabilityAmount').value;
  const paid_amount = document.getElementById('liabilityPaidAmount').value;
  const due_date = document.getElementById('liabilityDueDate').value;
  const status = document.getElementById('liabilityStatus').value;
  const notes = document.getElementById('liabilityNotes').value.trim();

  try {
    if (id) {
      await api(`/api/finance/liabilities/${id}`, {
        method: 'PUT',
        body: JSON.stringify({ creditor_name, description, amount, paid_amount, due_date, status, notes })
      });
      showNotification('Obaveza uspješno ažurirana!');
    } else {
      await api('/api/finance/liabilities', {
        method: 'POST',
        body: JSON.stringify({ month: currentFinanceMonth, creditor_name, description, amount, due_date, notes })
      });
      showNotification('Nova obaveza uspješno evidentirana!');
    }

    closeModal('liabilityModal');
    document.getElementById('liabilityForm').reset();
    loadMonthlySummary(currentFinanceMonth);
  } catch (err) {
    alert(err.message);
  }
}

async function deleteLiability(id) {
  if (!confirm('Da li ste sigurni da želite obrisati ovu obavezu?')) return;
  try {
    await api(`/api/finance/liabilities/${id}`, { method: 'DELETE' });
    showNotification('Obaveza obrisana.');
    loadMonthlySummary(currentFinanceMonth);
  } catch (err) {
    alert(err.message);
  }
}

let selectedClientsMonth = '2026-11';
let currentClientsFilter = 'all';

function selectClientsMonth(month) {
  selectedClientsMonth = month;

  const btnNov = document.getElementById('btnClientsMonthNov');
  const btnOct = document.getElementById('btnClientsMonthOct');
  const btnAll = document.getElementById('btnClientsMonthAll');
  const dropdown = document.getElementById('clientsMonthDropdown');

  const activeClass = 'px-3.5 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 bg-[#D4AF37] text-slate-950 shadow-md';
  const inactiveClass = 'px-3.5 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700';

  if (btnNov) btnNov.className = (month === '2026-11' ? activeClass : inactiveClass);
  if (btnOct) btnOct.className = (month === '2026-10' ? activeClass : inactiveClass);
  if (btnAll) btnAll.className = (month === 'all' ? activeClass : inactiveClass);
  if (dropdown) dropdown.value = month;

  loadMonthlyClients(month, currentClientsFilter);
}

function reloadCurrentClientsMonth() {
  loadMonthlyClients(selectedClientsMonth, currentClientsFilter);
}

function filterMonthlyClients(filter) {
  currentClientsFilter = filter;

  const btnAll = document.getElementById('btnFiltAll');
  const btnDebtors = document.getElementById('btnFiltDebtors');
  const btnPaid = document.getElementById('btnFiltPaid');

  if (btnAll) btnAll.className = `px-2.5 py-1 text-xs font-bold rounded-lg ${filter === 'all' ? 'bg-slate-900 text-white' : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'}`;
  if (btnDebtors) btnDebtors.className = `px-2.5 py-1 text-xs font-bold rounded-lg ${filter === 'debtors_only' ? 'bg-rose-600 text-white' : 'bg-white text-rose-700 border border-rose-300 hover:bg-rose-50'}`;
  if (btnPaid) btnPaid.className = `px-2.5 py-1 text-xs font-bold rounded-lg ${filter === 'paid_only' ? 'bg-emerald-600 text-white' : 'bg-white text-emerald-700 border border-emerald-300 hover:bg-emerald-50'}`;

  loadMonthlyClients(selectedClientsMonth, filter);
}

async function loadMonthlyClients(month = selectedClientsMonth, filter = currentClientsFilter) {
  try {
    const data = await api(`/api/finance/monthly-clients?month=${month}&filter=${filter}`);
    window.currentMonthlyClients = data.clients;
    const tbody = document.getElementById('debtorsTableBody');
    if (!tbody) return;

    // Update banner text
    const titleEl = document.getElementById('clientsBannerTitle');
    const subEl = document.getElementById('clientsBannerSubtitle');

    if (month === '2026-11') {
      if (titleEl) titleEl.textContent = 'Plan naplate za NOVEMBAR 2026 — Šta treba da naplatimo';
      if (subEl) subEl.textContent = 'Redovni mjesečni paketi za tekući mjesec, ugovoreni datumi plaćanja i izdvojeno stanje prethodnog duga';
    } else if (month === '2026-10') {
      if (titleEl) titleEl.textContent = 'Obračun za OKTOBAR 2026 — Šta je naplaćeno i šta je ostalo duga';
      if (subEl) subEl.textContent = 'Evidencija naplaćenih sredstava iz prošlog mjeseca i preostala zaostala dugovanja po klijentima';
    } else if (month === 'all') {
      if (titleEl) titleEl.textContent = 'Zbirni pregled svih klijenata i paketa (Sve ukupno)';
      if (subEl) subEl.textContent = 'Ukupno fakturisano, ukupno naplaćeno i trenutno stanje potraživanja kroz sve mjesece';
    } else {
      if (titleEl) titleEl.textContent = `Pregled za ${data.monthLabel || month} — Klijenti i paketi`;
      if (subEl) subEl.textContent = 'Ugovoreni paketi i evidencija plaćanja';
    }

    // Update 5 KPI Cards
    const cardPkg = document.getElementById('cardMonthlyPackagesVal');
    if (cardPkg) cardPkg.textContent = formatCurrency(data.totals.totalPackages);

    const cardPaid = document.getElementById('cardMonthlyPaidVal');
    if (cardPaid) cardPaid.textContent = formatCurrency(data.totals.totalPaid);

    const cardMonthDebt = document.getElementById('cardMonthlyPackageDebtVal');
    if (cardMonthDebt) cardMonthDebt.textContent = formatCurrency(data.totals.totalMonthDebt);

    const cardPrevDebt = document.getElementById('cardMonthlyPrevDebtVal');
    if (cardPrevDebt) cardPrevDebt.textContent = formatCurrency(data.totals.totalPrevDebt);

    const cardGrandDebt = document.getElementById('cardMonthlyGrandDebtVal');
    if (cardGrandDebt) {
      cardGrandDebt.textContent = formatCurrency(data.totals.grandTotalDebt);
      cardGrandDebt.className = `text-xl font-black mt-1 ${data.totals.grandTotalDebt > 0 ? 'text-rose-600' : 'text-emerald-600'}`;
    }

    // Populate rows
    if (data.clients.length === 0) {
      tbody.innerHTML = '<tr><td colspan="9" class="p-6 text-center text-slate-400">Nema evidentiranih klijenata za odabrani filter.</td></tr>';
      return;
    }

    tbody.innerHTML = data.clients.map(r => {
      const isPaidFull = r.total_debt <= 0;
      const hasOldDebt = r.previous_debt > 0;
      const isNov = month === '2026-11';

      let statusBadge = '';
      if (isPaidFull) {
        statusBadge = '<span class="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-300 whitespace-nowrap">✓ Izmireno</span>';
      } else if (r.status === 'partial') {
        statusBadge = '<span class="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-amber-100 text-amber-800 border border-amber-300 whitespace-nowrap">Djelimično</span>';
      } else if (isNov && r.paid_in_month === 0) {
        statusBadge = '<span class="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-blue-100 text-blue-800 border border-blue-300 whitespace-nowrap">⏳ Čeka datum</span>';
      } else {
        statusBadge = '<span class="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-rose-100 text-rose-800 border border-rose-300 whitespace-nowrap">⚠️ Duguje</span>';
      }

      return `
        <tr class="hover:bg-amber-50/20 transition">
          <td class="p-3">
            <div class="font-extrabold text-slate-900 text-xs">${escapeHtml(r.client_name)}</div>
            <div class="text-[11px] text-slate-500">${escapeHtml(r.contact_person || 'Marketing')} ${r.phone ? `• <a href="tel:${r.phone}" class="text-indigo-600 font-bold hover:underline">${escapeHtml(r.phone)}</a>` : ''}</div>
            ${r.notes ? `<div class="text-[10px] text-amber-700 font-semibold mt-0.5">${escapeHtml(r.notes)}</div>` : ''}
          </td>
          <td class="p-3 text-right">
            <div class="font-black text-slate-900 text-xs">${formatCurrency(r.monthly_package)}</div>
            ${r.currency && r.currency.includes('€') ? `<div class="text-[10px] text-slate-400 font-bold">(${escapeHtml(r.currency)})</div>` : ''}
          </td>
          <td class="p-3 text-center">
            <span class="px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-700 border border-slate-200 whitespace-nowrap">
              ${escapeHtml(r.payment_day_desc || 'U toku')}
            </span>
          </td>
          <td class="p-3 text-right">
            <span class="font-extrabold text-xs ${r.paid_in_month > 0 ? 'text-emerald-600' : 'text-slate-400'}">
              ${r.paid_in_month > 0 ? formatCurrency(r.paid_in_month) : '0,00 KM'}
            </span>
          </td>
          <td class="p-3 text-right">
            <span class="font-bold text-xs ${r.month_debt > 0 ? 'text-indigo-600' : 'text-slate-400'}">
              ${formatCurrency(r.month_debt)}
            </span>
          </td>
          <td class="p-3 text-right">
            <span class="font-bold text-xs ${hasOldDebt ? 'text-amber-800' : 'text-slate-300'}">
              ${hasOldDebt ? formatCurrency(r.previous_debt) : '0,00 KM'}
            </span>
          </td>
          <td class="p-3 text-right">
            <span class="font-black text-xs ${r.total_debt > 0 ? 'text-rose-600' : 'text-emerald-600'}">
              ${formatCurrency(r.total_debt)}
            </span>
          </td>
          <td class="p-3 text-center">
            ${statusBadge}
          </td>
          <td class="p-3 text-center whitespace-nowrap">
            <div class="inline-flex items-center gap-1.5">
              <button onclick="quickPayForClient(${r.client_id}, ${r.total_debt || r.monthly_package})" class="px-2.5 py-1.5 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:brightness-110 text-slate-950 rounded-lg text-[11px] font-black transition shadow-xs whitespace-nowrap">
                Zabilježi uplatu
              </button>
              <button onclick="openEditClientDebtModal(${r.client_id}, '${month}')" title="Uredi dugovanje i paket klijenta" class="px-2.5 py-1.5 text-amber-900 hover:text-black rounded-lg bg-amber-100/90 hover:bg-amber-200 border border-amber-300 transition shadow-xs flex items-center gap-1 font-extrabold text-[11px] whitespace-nowrap">
                <i data-lucide="edit-3" class="w-3.5 h-3.5 text-amber-700"></i>
                <span>Uredi dug</span>
              </button>
              <button onclick="openClientModal(${r.client_id})" title="Uredi profil i osnovne podatke klijenta" class="p-1.5 text-slate-400 hover:text-amber-600 rounded-lg hover:bg-amber-50 border border-slate-200 bg-white transition shadow-xs">
                <i data-lucide="user-cog" class="w-3.5 h-3.5"></i>
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');

    if (window.lucide) lucide.createIcons();
  } catch (err) {
    console.error('Error loading monthly clients:', err);
  }
}

function openEditClientDebtModal(clientId, month = null) {
  const targetMonth = month || selectedClientsMonth || '2026-11';
  const clientData = window.currentMonthlyClients?.find(c => c.client_id === clientId);

  const titleEl = document.getElementById('editDebtModalTitle');
  const idEl = document.getElementById('editDebtClientId');
  const monthEl = document.getElementById('editDebtMonth');
  const nameEl = document.getElementById('editDebtClientName');
  const badgeEl = document.getElementById('editDebtMonthBadge');
  const pkgEl = document.getElementById('editDebtPackage');
  const payDayEl = document.getElementById('editDebtPayDay');
  const paidEl = document.getElementById('editDebtPaid');
  const monthDebtEl = document.getElementById('editDebtMonthDebt');
  const prevDebtEl = document.getElementById('editDebtPrevDebt');
  const totalDebtEl = document.getElementById('editDebtTotal');
  const notesEl = document.getElementById('editDebtNotes');

  if (idEl) idEl.value = clientId;
  if (monthEl) monthEl.value = targetMonth;

  const monthNames = {
    '2026-09': 'Septembar 2026',
    '2026-10': 'Oktobar 2026',
    '2026-11': 'Novembar 2026',
    '2026-12': 'Decembar 2026',
    'all': 'Sve ukupno'
  };

  if (badgeEl) badgeEl.textContent = monthNames[targetMonth] || targetMonth;

  if (clientData) {
    if (titleEl) titleEl.textContent = `Uredi Dugovanje i Paket: ${clientData.client_name}`;
    if (nameEl) nameEl.textContent = clientData.client_name;
    if (pkgEl) pkgEl.value = clientData.monthly_package || 0;
    if (payDayEl) payDayEl.value = clientData.payment_day_desc || '';
    if (paidEl) paidEl.value = clientData.paid_in_month || 0;
    if (monthDebtEl) monthDebtEl.value = clientData.month_debt || 0;
    if (prevDebtEl) prevDebtEl.value = clientData.previous_debt || 0;
    if (totalDebtEl) totalDebtEl.value = clientData.total_debt || 0;
    if (notesEl) notesEl.value = clientData.notes || '';
  } else {
    const matched = clientsList?.find(c => c.id === clientId);
    const clientName = matched ? matched.name : `Klijent #${clientId}`;
    if (titleEl) titleEl.textContent = `Uredi Dugovanje i Paket: ${clientName}`;
    if (nameEl) nameEl.textContent = clientName;
    if (pkgEl) pkgEl.value = matched?.monthly_package || 0;
    if (payDayEl) payDayEl.value = matched?.payment_day_desc || '';
    if (paidEl) paidEl.value = 0;
    if (monthDebtEl) monthDebtEl.value = matched?.monthly_package || 0;
    if (prevDebtEl) prevDebtEl.value = 0;
    if (totalDebtEl) totalDebtEl.value = matched?.monthly_package || 0;
    if (notesEl) notesEl.value = matched?.notes || '';
  }

  openModal('editClientDebtModal');
  refreshIcons();
}

function recalcDebtModalTotals(isMonthDebtManual = false) {
  const pkgVal = parseFloat(document.getElementById('editDebtPackage')?.value) || 0;
  const paidVal = parseFloat(document.getElementById('editDebtPaid')?.value) || 0;
  const prevVal = parseFloat(document.getElementById('editDebtPrevDebt')?.value) || 0;
  const monthDebtInput = document.getElementById('editDebtMonthDebt');
  const totalDebtInput = document.getElementById('editDebtTotal');

  let monthDebt = 0;
  if (isMonthDebtManual) {
    monthDebt = parseFloat(monthDebtInput?.value) || 0;
  } else {
    monthDebt = Math.max(0, pkgVal - paidVal);
    if (monthDebtInput) monthDebtInput.value = monthDebt.toFixed(2);
  }

  const grandTotal = monthDebt + prevVal;
  if (totalDebtInput) totalDebtInput.value = grandTotal.toFixed(2);
}

function setDebtModalAllPaid() {
  const pkgVal = parseFloat(document.getElementById('editDebtPackage')?.value) || 0;
  const paidEl = document.getElementById('editDebtPaid');
  const monthDebtEl = document.getElementById('editDebtMonthDebt');
  const prevDebtEl = document.getElementById('editDebtPrevDebt');
  const totalDebtEl = document.getElementById('editDebtTotal');
  const notesEl = document.getElementById('editDebtNotes');

  if (paidEl) paidEl.value = pkgVal.toFixed(2);
  if (monthDebtEl) monthDebtEl.value = '0.00';
  if (prevDebtEl) prevDebtEl.value = '0.00';
  if (totalDebtEl) totalDebtEl.value = '0.00';
  if (notesEl) notesEl.value = 'Sve izmireno u cjelosti.';
}

async function handleSaveClientDebt(e) {
  e.preventDefault();
  const clientId = document.getElementById('editDebtClientId')?.value;
  const month = document.getElementById('editDebtMonth')?.value || selectedClientsMonth || '2026-11';
  const pkgVal = parseFloat(document.getElementById('editDebtPackage')?.value) || 0;
  const payDay = document.getElementById('editDebtPayDay')?.value.trim();
  const paidVal = parseFloat(document.getElementById('editDebtPaid')?.value) || 0;
  const monthDebtVal = parseFloat(document.getElementById('editDebtMonthDebt')?.value) || 0;
  const prevDebtVal = parseFloat(document.getElementById('editDebtPrevDebt')?.value) || 0;
  const totalDebtVal = parseFloat(document.getElementById('editDebtTotal')?.value) || 0;
  const notesVal = document.getElementById('editDebtNotes')?.value.trim();

  const payload = {
    month,
    monthly_package: pkgVal,
    payment_day_desc: payDay,
    paid_in_month: paidVal,
    month_debt: monthDebtVal,
    previous_debt: prevDebtVal,
    total_debt: totalDebtVal,
    notes: notesVal
  };

  try {
    await api(`/api/finance/clients/${clientId}/adjust-debt`, {
      method: 'POST',
      body: JSON.stringify(payload)
    });

    closeModal('editClientDebtModal');
    showNotification('Dugovanje i podaci klijenta su uspješno ažurirani!');

    await loadMonthlyClients(selectedClientsMonth, currentClientsFilter);
    if (currentTab === 'clients') loadClients();
    if (currentTab === 'dashboard') loadDashboard();
    if (currentTab === 'secretary') loadSecretaryStats();
  } catch (err) {
    alert('Greška pri ažuriranju dugovanja: ' + err.message);
  }
}

function quickPayForClient(clientId, defaultAmount) {
  openModal('paymentModal');
  const sel = document.getElementById('paymentClientId');
  if (sel) {
    sel.value = clientId;
    loadClientUnpaidBills(clientId);
  }
  const amt = document.getElementById('paymentAmount');
  if (amt && defaultAmount > 0) {
    amt.value = defaultAmount;
  }
}

function quickPayForDebtor(clientId) {
  quickPayForClient(clientId, 0);
}

async function loadDebtors(filter = 'all') {
  loadMonthlyClients(selectedClientsMonth, filter);
}

let currentInvoicesList = [];

async function loadInvoices() {
  try {
    const data = await api('/api/finance/invoices');
    currentInvoicesList = data.invoices || [];
    const tbody = document.getElementById('invoicesTableBody');

    if (currentInvoicesList.length === 0) {
      tbody.innerHTML = '<tr><td colspan="8" class="p-6 text-center text-slate-400">Nema unesenih računa i zaduženja.</td></tr>';
      return;
    }

    tbody.innerHTML = currentInvoicesList.map(inv => {
      const remaining = inv.total_amount - inv.paid_amount;
      return `
        <tr class="hover:bg-slate-50/80 transition">
          <td class="p-3">
            <div class="font-bold text-slate-900">${escapeHtml(inv.title)}</div>
            <div class="text-[10px] text-slate-400 font-mono">${inv.invoice_number || 'Bez fakture'}</div>
            ${inv.notes ? `<div class="text-[10px] text-amber-600 font-medium mt-0.5">${escapeHtml(inv.notes)}</div>` : ''}
          </td>
          <td class="p-3 font-semibold text-slate-700">${escapeHtml(inv.client_name)}</td>
          <td class="p-3 text-slate-500">${inv.due_date || 'Po dogovoru'}</td>
          <td class="p-3 text-right font-semibold">${formatCurrency(inv.total_amount)}</td>
          <td class="p-3 text-right text-emerald-600 font-semibold">${formatCurrency(inv.paid_amount)}</td>
          <td class="p-3 text-right font-bold text-rose-600">${formatCurrency(remaining)}</td>
          <td class="p-3 text-center">
            ${inv.status === 'paid' ? '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">Plaćeno</span>' : ''}
            ${inv.status === 'partial' ? '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800">Djelimično</span>' : ''}
            ${inv.status === 'unpaid' ? '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800">Neplaćeno</span>' : ''}
          </td>
          <td class="p-3 text-right whitespace-nowrap">
            <div class="inline-flex items-center gap-1">
              <button onclick="openInvoiceModal(${inv.id})" title="Uredi zaduženje" class="p-1.5 text-slate-400 hover:text-amber-600 rounded-lg hover:bg-amber-50 transition">
                <i data-lucide="edit-3" class="w-3.5 h-3.5"></i>
              </button>
              <button onclick="deleteInvoice(${inv.id})" title="Obriši zaduženje" class="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition">
                <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');

    refreshIcons();
  } catch (err) {
    console.error('Error loading invoices:', err);
  }
}

async function loadPaymentsHistory() {
  try {
    const data = await api('/api/finance/payments');
    const tbody = document.getElementById('paymentsTableBody');

    if (data.payments.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" class="p-6 text-center text-slate-400">Nema zabilježenih uplata u sistemu.</td></tr>';
      return;
    }

    tbody.innerHTML = data.payments.map(p => `
      <tr class="hover:bg-slate-50/80 transition">
        <td class="p-3 font-semibold text-slate-900">${p.payment_date}</td>
        <td class="p-3 font-bold text-slate-800">${escapeHtml(p.client_name)}</td>
        <td class="p-3 font-extrabold text-emerald-600 text-sm">+${formatCurrency(p.amount)}</td>
        <td class="p-3">
          <span class="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-bold">
            ${p.payment_method === 'bank' ? 'Banka / Virman' : p.payment_method === 'cash' ? 'Gotovina' : 'Ostalo'}
          </span>
        </td>
        <td class="p-3 text-slate-500">${escapeHtml(p.note || '-')}</td>
        <td class="p-3 text-slate-600">${escapeHtml(p.recorder_name || 'Sekretarica')}</td>
      </tr>
    `).join('');
  } catch (err) {
    console.error('Error loading payments history:', err);
  }
}

function openInvoiceModal(invoiceId = null) {
  const form = document.getElementById('invoiceForm');
  if (form) form.reset();

  const titleEl = document.getElementById('invoiceModalTitle');
  const idEl = document.getElementById('invoiceId');
  const deleteBtn = document.getElementById('btnDeleteInvoice');
  const submitBtn = document.getElementById('invoiceSubmitBtn');

  if (invoiceId) {
    const inv = currentInvoicesList.find(i => i.id === invoiceId);
    if (inv) {
      if (idEl) idEl.value = inv.id;
      if (titleEl) titleEl.textContent = 'Uredi Zaduženje / Fakturu';
      if (submitBtn) submitBtn.textContent = 'Sačuvaj Izmjene';
      if (deleteBtn) deleteBtn.classList.remove('hidden');

      document.getElementById('invoiceClientId').value = inv.client_id;
      document.getElementById('invoiceNumber').value = inv.invoice_number || '';
      document.getElementById('invoiceAmount').value = inv.total_amount || '';
      document.getElementById('invoicePaidAmount').value = (inv.paid_amount !== undefined) ? inv.paid_amount : 0;
      document.getElementById('invoiceStatus').value = inv.status || 'unpaid';
      document.getElementById('invoiceMonth').value = inv.month || '2026-11';
      document.getElementById('invoiceBillingType').value = inv.billing_type || 'service';
      document.getElementById('invoiceTitle').value = inv.title || '';
      document.getElementById('invoiceDueDate').value = inv.due_date || '';
      document.getElementById('invoiceNotes').value = inv.notes || '';
    }
  } else {
    if (idEl) idEl.value = '';
    if (titleEl) titleEl.textContent = 'Novo Zaduženje / Faktura za Klijenta';
    if (submitBtn) submitBtn.textContent = 'Evidentiraj Zaduženje';
    if (deleteBtn) deleteBtn.classList.add('hidden');

    const paidEl = document.getElementById('invoicePaidAmount');
    if (paidEl) paidEl.value = '0';
    const statusEl = document.getElementById('invoiceStatus');
    if (statusEl) statusEl.value = 'unpaid';
    const monthEl = document.getElementById('invoiceMonth');
    if (monthEl) monthEl.value = selectedClientsMonth && selectedClientsMonth !== 'all' ? selectedClientsMonth : '2026-11';
    const typeEl = document.getElementById('invoiceBillingType');
    if (typeEl) typeEl.value = 'service';
  }

  openModal('invoiceModal');
}

async function handleSaveInvoice(e) {
  e.preventDefault();
  const id = document.getElementById('invoiceId').value;
  const client_id = document.getElementById('invoiceClientId').value;
  const title = document.getElementById('invoiceTitle').value.trim();
  const invoice_number = document.getElementById('invoiceNumber').value.trim();
  const total_amount = document.getElementById('invoiceAmount').value;
  const paid_amount = document.getElementById('invoicePaidAmount')?.value;
  const status = document.getElementById('invoiceStatus')?.value;
  const month = document.getElementById('invoiceMonth')?.value.trim();
  const billing_type = document.getElementById('invoiceBillingType')?.value;
  const due_date = document.getElementById('invoiceDueDate').value;
  const notes = document.getElementById('invoiceNotes').value.trim();

  const payload = {
    client_id: parseInt(client_id),
    title,
    invoice_number,
    total_amount: parseFloat(total_amount),
    paid_amount: paid_amount !== '' && paid_amount !== undefined ? parseFloat(paid_amount) : 0,
    status: status || undefined,
    month: month || '2026-11',
    billing_type: billing_type || 'service',
    due_date: due_date || null,
    notes: notes || null
  };

  try {
    if (id) {
      await api(`/api/finance/invoices/${id}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      });
      showNotification('Zaduženje / faktura uspješno ažurirana!');
    } else {
      await api('/api/finance/invoices', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
      showNotification('Zaduženje / faktura uspješno kreirana!');
    }

    closeModal('invoiceModal');
    loadSecretaryStats();
    loadDebtors();
    loadInvoices();
  } catch (err) {
    alert(err.message);
  }
}

async function handleDeleteCurrentInvoice() {
  const id = document.getElementById('invoiceId').value;
  if (!id) return;
  if (!confirm('Jeste li sigurni da želite obrisati ovaj račun/zaduženje?')) return;

  try {
    await api(`/api/finance/invoices/${id}`, { method: 'DELETE' });
    closeModal('invoiceModal');
    loadSecretaryStats();
    loadDebtors();
    loadInvoices();
    showNotification('Zaduženje / faktura je obrisana!');
  } catch (err) {
    alert(err.message);
  }
}

async function deleteInvoice(id) {
  if (!confirm('Jeste li sigurni da želite obrisati ovaj račun/zaduženje?')) return;
  try {
    await api(`/api/finance/invoices/${id}`, { method: 'DELETE' });
    loadSecretaryStats();
    loadDebtors();
    loadInvoices();
    showNotification('Zaduženje / faktura je obrisana!');
  } catch (err) {
    alert(err.message);
  }
}

async function loadClientUnpaidBills(clientId) {
  if (!clientId) {
    document.getElementById('paymentBillContainer').classList.add('hidden');
    return;
  }

  try {
    const data = await api(`/api/clients/${clientId}`);
    const unpaid = data.billing.filter(b => b.status !== 'paid');
    const billSelect = document.getElementById('paymentBillingId');
    const container = document.getElementById('paymentBillContainer');

    if (unpaid.length > 0) {
      container.classList.remove('hidden');
      let opts = '<option value="">Automatski raspodijeli na najstariji dug</option>';
      unpaid.forEach(b => {
        const remaining = b.total_amount - b.paid_amount;
        opts += `<option value="${b.id}">${b.title} (Duguje još: ${formatCurrency(remaining)})</option>`;
      });
      billSelect.innerHTML = opts;
    } else {
      container.classList.add('hidden');
      billSelect.innerHTML = '<option value="">Nema otvorenih računa</option>';
    }
  } catch (err) {
    console.error('Error fetching unpaid bills:', err);
  }
}

function quickPayForDebtor(clientId) {
  document.getElementById('paymentClientId').value = clientId;
  loadClientUnpaidBills(clientId);
  openModal('paymentModal');
}

async function handleCreatePayment(e) {
  e.preventDefault();
  const client_id = document.getElementById('paymentClientId').value;
  const billing_id = document.getElementById('paymentBillingId').value;
  const amount = document.getElementById('paymentAmount').value;
  const payment_date = document.getElementById('paymentDate').value;
  const payment_method = document.getElementById('paymentMethod').value;
  const note = document.getElementById('paymentNote').value.trim();

  try {
    await api('/api/finance/payments', {
      method: 'POST',
      body: JSON.stringify({ client_id, billing_id, amount, payment_date, payment_method, note })
    });
    closeModal('paymentModal');
    document.getElementById('paymentForm').reset();
    loadSecretaryStats();
    loadDebtors();
    if (currentTab === 'dashboard') loadDashboard();
    if (currentTab === 'clients') loadClients();
    if (currentDetailedClientId) openClientDetail(currentDetailedClientId);
    showNotification('Uplata je uspješno zabilježena! Dug klijenta je umanjen.');
  } catch (err) {
    alert(err.message);
  }
}

// ==================== USERS & TEAM (ADMIN & AMRA / SEKRETARICA) ====================
async function loadUsers() {
  try {
    const data = await api('/api/users');
    usersList = data.users || [];
    const tbody = document.getElementById('usersTableBody');
    if (!tbody) return;

    tbody.innerHTML = usersList.map(u => {
      const roleBadge = u.role === 'admin' 
        ? '<span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-[#D4AF37]/20 text-[#ECC968] border border-[#D4AF37]/40">👑 Direktor / Admin</span>' 
        : u.role === 'secretary' 
        ? '<span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-950/80 text-emerald-300 border border-emerald-800">💼 Menadžer / Sekretarica</span>'
        : '<span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-950/80 text-amber-300 border border-amber-800">🔧 Radnik</span>';

      const canManage = (currentUser?.role === 'admin' || currentUser?.role === 'secretary');
      const isSelf = (u.id === currentUser?.id);
      const isTargetAdmin = (u.role === 'admin');
      const canDelete = canManage && !isSelf && (currentUser?.role === 'admin' || !isTargetAdmin);

      let permissionsCell = '';
      if (isTargetAdmin) {
        permissionsCell = `
          <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-[#D4AF37]/20 text-amber-900 border border-[#D4AF37]/50 whitespace-nowrap">
            <i data-lucide="crown" class="w-3 h-3 text-amber-600"></i> Sve dozvole (Direktor)
          </span>
        `;
      } else {
        const activePermsCount = u.permissions ? Object.values(u.permissions).filter(Boolean).length : 0;
        const canEditPerms = (currentUser?.role === 'admin' || can('manage_permissions'));
        permissionsCell = `
          <div class="inline-flex items-center gap-2">
            ${canEditPerms ? `
              <button onclick="openPermissionsModal(${u.id})" class="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-black bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 transition shadow-2xs whitespace-nowrap">
                <i data-lucide="shield-check" class="w-3.5 h-3.5 text-amber-700"></i>
                <span>Podesi Dozvole</span>
              </button>
            ` : ''}
            <span class="text-[10px] font-extrabold text-slate-500 bg-slate-100 px-2 py-0.5 rounded border border-slate-200 whitespace-nowrap">${activePermsCount} dozvola</span>
          </div>
        `;
      }

      return `
        <tr class="hover:bg-slate-50 transition">
          <td class="p-4">
            <div class="flex items-center gap-3">
              ${getUserAvatar(u, 'w-10 h-10', 'text-xs')}
              <div>
                <div class="font-extrabold text-slate-900 leading-snug">${escapeHtml(u.full_name)}</div>
                <div class="text-[10px] text-slate-400">@${escapeHtml(u.username)}</div>
              </div>
            </div>
          </td>
          <td class="p-4 font-mono text-slate-600">${escapeHtml(u.username)}</td>
          <td class="p-4">${roleBadge}</td>
          <td class="p-4">${permissionsCell}</td>
          <td class="p-4 text-slate-500">${escapeHtml(u.phone || '-')}</td>
          <td class="p-4 text-right whitespace-nowrap">
            <div class="inline-flex items-center gap-1.5 justify-end">
              <input type="number" step="0.5" id="userRateInput_${u.id}" value="${u.hourly_rate || 0}" class="w-20 p-1.5 text-xs text-right border border-slate-300 rounded-lg font-extrabold text-emerald-700 bg-white focus:ring-2 focus:ring-[#D4AF37]">
              <span class="text-[10px] text-slate-400 font-bold">KM</span>
              <button onclick="saveUserHourlyRate(${u.id})" class="px-2.5 py-1 bg-slate-900 hover:bg-[#ECC968] hover:text-slate-950 text-white font-bold rounded-lg text-[10px] transition shadow-xs">Sačuvaj</button>
            </div>
          </td>
          <td class="p-4 text-center whitespace-nowrap">
            <div class="inline-flex items-center gap-1.5 justify-center">
              <button onclick="openUserModal(${u.id})" class="p-1.5 text-slate-400 hover:text-amber-600 rounded-lg hover:bg-amber-50 transition" title="Uredi nalog zaposlenog">
                <i data-lucide="edit-3" class="w-4 h-4"></i>
              </button>
              ${canDelete ? `
                <button onclick="deleteUser(${u.id})" class="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition" title="Obriši korisnika">
                  <i data-lucide="trash-2" class="w-4 h-4"></i>
                </button>
              ` : (isSelf ? '<span class="text-slate-400 text-[10px]">Vaš nalog</span>' : '')}
            </div>
          </td>
        </tr>
      `;
    }).join('');

    refreshIcons();
  } catch (err) {
    console.error('Error loading users:', err);
  }
}

function openUserModal(id = null) {
  const form = document.getElementById('userForm');
  if (form) form.reset();

  const titleEl = document.getElementById('userModalTitle');
  const idEl = document.getElementById('userId');
  const nameEl = document.getElementById('userFullName');
  const uNameEl = document.getElementById('userUsername');
  const passEl = document.getElementById('userPassword');
  const roleEl = document.getElementById('userRole');
  const rateEl = document.getElementById('userHourlyRate');
  const phoneEl = document.getElementById('userPhone');
  const btnSubmit = document.getElementById('btnUserSubmit');

  if (id) {
    const user = usersList.find(u => u.id === id);
    if (user) {
      if (titleEl) titleEl.textContent = 'Uredi Nalog Zaposlenog';
      if (idEl) idEl.value = user.id;
      if (nameEl) nameEl.value = user.full_name || '';
      if (uNameEl) {
        uNameEl.value = user.username || '';
        uNameEl.disabled = true;
      }
      if (passEl) {
        passEl.required = false;
        passEl.placeholder = 'Ostavite prazno ako ne mijenjate';
      }
      if (roleEl) roleEl.value = user.role || 'worker';
      if (rateEl) rateEl.value = user.hourly_rate || 0;
      if (phoneEl) phoneEl.value = user.phone || '';
      if (document.getElementById('userAvatarSelect')) {
        document.getElementById('userAvatarSelect').value = user.avatar || '';
        previewUserAvatar(user.avatar || '');
      }
      if (btnSubmit) btnSubmit.textContent = 'Sačuvaj Izmjene';
    }
  } else {
    if (titleEl) titleEl.textContent = 'Novi Nalog za Zaposlenog';
    if (idEl) idEl.value = '';
    if (uNameEl) {
      uNameEl.disabled = false;
      uNameEl.value = '';
    }
    if (passEl) {
      passEl.required = true;
      passEl.placeholder = '••••••••';
    }
    if (roleEl) roleEl.value = 'worker';
    if (rateEl) rateEl.value = '';
    if (document.getElementById('userAvatarSelect')) {
      document.getElementById('userAvatarSelect').value = '';
      previewUserAvatar('');
    }
    if (btnSubmit) btnSubmit.textContent = 'Kreiraj Nalog';
  }

  openModal('userModal');
  refreshIcons();
}

async function saveUserHourlyRate(userId) {
  const input = document.getElementById(`userRateInput_${userId}`);
  if (!input) return;
  const rate = parseFloat(input.value) || 0;
  try {
    await api(`/api/users/${userId}/rate`, {
      method: 'PUT',
      body: JSON.stringify({ hourly_rate: rate })
    });
    showNotification('Satnica uspješno sačuvana!');
    loadUsers();
    loadDropdownData();
  } catch (err) {
    alert(err.message);
  }
}

async function handleCreateUser(e) {
  e.preventDefault();
  const id = document.getElementById('userId')?.value;
  const full_name = document.getElementById('userFullName').value.trim();
  const username = document.getElementById('userUsername').value.trim();
  const password = document.getElementById('userPassword').value;
  const role = document.getElementById('userRole').value;
  const phone = document.getElementById('userPhone').value.trim();
  const rateVal = document.getElementById('userHourlyRate')?.value;
  const hourly_rate = rateVal !== '' && rateVal !== undefined ? parseFloat(rateVal) : 0;
  const avatar = document.getElementById('userAvatarSelect')?.value || null;

  try {
    if (id) {
      await api(`/api/users/${id}`, {
        method: 'PUT',
        body: JSON.stringify({
          full_name,
          role,
          phone,
          hourly_rate,
          avatar,
          password: password && password.trim() ? password.trim() : undefined
        })
      });
      showNotification('Podaci o zaposlenom uspješno ažurirani!');
    } else {
      await api('/api/users', {
        method: 'POST',
        body: JSON.stringify({ full_name, username, password, role, phone, hourly_rate, avatar })
      });
      showNotification('Novi nalog za zaposlenog je uspješno kreiran!');
    }

    closeModal('userModal');
    document.getElementById('userForm').reset();
    if (document.getElementById('userId')) document.getElementById('userId').value = '';
    loadUsers();
    loadDropdownData();
  } catch (err) {
    alert(err.message);
  }
}

async function deleteUser(userId) {
  if (!confirm('Da li ste sigurni da želite obrisati ovog zaposlenog iz sistema?')) return;
  try {
    await api(`/api/users/${userId}`, { method: 'DELETE' });
    loadUsers();
    loadDropdownData();
    showNotification('Korisnik obrisan.');
  } catch (err) {
    alert(err.message);
  }
}

// ==================== PODEŠAVANJE PERMISIJA I DOZVOLA ====================
let currentPermissionsUserId = null;
let currentPermissionsUserRole = null;
let cachedPermissionDefinitions = null;

async function openPermissionsModal(userId) {
  try {
    currentPermissionsUserId = userId;
    const res = await api(`/api/users/${userId}/permissions`);
    const { user_id, username, full_name, role, permissions, definitions } = res;
    
    currentPermissionsUserRole = role;
    cachedPermissionDefinitions = definitions;

    document.getElementById('permUserId').value = user_id;
    document.getElementById('permUserFullName').textContent = full_name || username;
    document.getElementById('permUserUsername').textContent = '@' + username;
    
    const avatarEl = document.getElementById('permUserAvatar');
    if (avatarEl) {
      avatarEl.innerHTML = getUserAvatar(res, 'w-10 h-10', 'text-sm');
      avatarEl.className = 'w-10 h-10 rounded-full shrink-0 flex items-center justify-center';
    }

    const roleBadgeEl = document.getElementById('permUserRoleBadge');
    if (roleBadgeEl) {
      if (role === 'admin') {
        roleBadgeEl.className = 'font-bold text-amber-900 bg-amber-100 px-2 py-0.5 rounded border border-amber-300 text-[10px]';
        roleBadgeEl.textContent = 'Direktor (Admin)';
      } else if (role === 'secretary') {
        roleBadgeEl.className = 'font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded border border-emerald-300 text-[10px]';
        roleBadgeEl.textContent = 'Sekretarica / Finansije';
      } else {
        roleBadgeEl.className = 'font-bold text-slate-700 bg-slate-200 px-2 py-0.5 rounded border border-slate-300 text-[10px]';
        roleBadgeEl.textContent = 'Standardni Radnik';
      }
    }

    const isTargetAdmin = (role === 'admin');
    const saveBtn = document.getElementById('btnSavePermissions');
    if (saveBtn) {
      saveBtn.disabled = isTargetAdmin;
      if (isTargetAdmin) {
        saveBtn.classList.add('opacity-50', 'cursor-not-allowed');
      } else {
        saveBtn.classList.remove('opacity-50', 'cursor-not-allowed');
      }
    }

    renderPermissionsGrid(permissions, definitions, isTargetAdmin);
    openModal('permissionsModal');
    refreshIcons();
  } catch (err) {
    alert(err.message || 'Greška pri učitavanju dozvola korisnika.');
  }
}

function renderPermissionsGrid(userPerms, definitions, isTargetAdmin = false) {
  const container = document.getElementById('permissionsGridContainer');
  if (!container) return;

  if (isTargetAdmin) {
    container.innerHTML = `
      <div class="p-4 bg-amber-50 rounded-2xl border border-amber-200 text-amber-900 flex items-start gap-3">
        <i data-lucide="crown" class="w-6 h-6 text-amber-600 flex-shrink-0 mt-0.5"></i>
        <div>
          <h4 class="font-bold text-sm">Direktor / Administrator posjeduje sve dozvole</h4>
          <p class="text-xs text-amber-700 mt-1">Administrator ima neograničeno pravo pristupa svim finansijama, klijentima, radnim nalozima i podešavanjima, te se njegove dozvole ne mogu ograničiti.</p>
        </div>
      </div>
    `;
    refreshIcons();
    return;
  }

  let html = '';
  definitions.forEach((cat, catIdx) => {
    const itemsHtml = cat.items.map(item => {
      const isChecked = Boolean(userPerms && userPerms[item.key]);
      return `
        <label for="perm_${item.key}" class="flex items-start gap-3 p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl cursor-pointer transition hover:border-amber-300 group">
          <input type="checkbox" id="perm_${item.key}" data-perm="${item.key}" data-cat="${catIdx}" class="perm-checkbox mt-0.5 w-4 h-4 text-amber-600 rounded border-slate-300 focus:ring-amber-500 cursor-pointer" ${isChecked ? 'checked' : ''}>
          <div class="flex-1 min-w-0">
            <div class="font-extrabold text-slate-900 group-hover:text-amber-800 transition text-xs flex items-center gap-1.5">
              <span>${escapeHtml(item.label)}</span>
            </div>
            <div class="text-[11px] text-slate-500 leading-snug mt-0.5">
              ${escapeHtml(item.desc)}
            </div>
          </div>
        </label>
      `;
    }).join('');

    html += `
      <div class="bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
        <div class="flex items-center justify-between pb-2 mb-2 border-b border-slate-200">
          <div class="flex items-center gap-2">
            <div class="w-6 h-6 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center">
              <i data-lucide="${cat.icon || 'shield'}" class="w-3.5 h-3.5 text-amber-700"></i>
            </div>
            <h4 class="font-black text-slate-900 text-xs uppercase tracking-wider">${escapeHtml(cat.category)}</h4>
          </div>
          <div class="flex items-center gap-2">
            <button type="button" onclick="toggleCategoryPerms(${catIdx}, true)" class="text-[10px] font-bold text-amber-700 hover:text-amber-900 hover:underline">Označi sve</button>
            <span class="text-slate-300 text-[10px]">|</span>
            <button type="button" onclick="toggleCategoryPerms(${catIdx}, false)" class="text-[10px] font-bold text-slate-500 hover:text-slate-700 hover:underline">Isključi sve</button>
          </div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-2.5">
          ${itemsHtml}
        </div>
      </div>
    `;
  });

  container.innerHTML = html;
  refreshIcons();
}

function toggleCategoryPerms(catIdx, checkAll) {
  const checkboxes = document.querySelectorAll(`.perm-checkbox[data-cat="${catIdx}"]`);
  checkboxes.forEach(cb => {
    cb.checked = checkAll;
  });
}

function applyPermissionPreset(preset) {
  if (currentPermissionsUserRole === 'admin') return;

  const checkboxes = document.querySelectorAll('.perm-checkbox');
  
  if (preset === 'all') {
    checkboxes.forEach(cb => cb.checked = true);
  } else if (preset === 'none') {
    checkboxes.forEach(cb => cb.checked = false);
  } else if (preset === 'worker') {
    const defaultWorkerKeys = ['view_clients', 'log_work_hours', 'view_print'];
    checkboxes.forEach(cb => {
      cb.checked = defaultWorkerKeys.includes(cb.dataset.perm);
    });
  } else if (preset === 'secretary') {
    checkboxes.forEach(cb => {
      // Secretary has everything except system permissions management
      cb.checked = (cb.dataset.perm !== 'manage_permissions');
    });
  }
}

async function saveUserPermissions(e) {
  if (e) e.preventDefault();
  if (!currentPermissionsUserId) return;
  if (currentPermissionsUserRole === 'admin') {
    alert('Direktor posjeduje sve dozvole i ne može se mijenjati.');
    closeModal('permissionsModal');
    return;
  }

  const permissions = {};
  const checkboxes = document.querySelectorAll('.perm-checkbox');
  checkboxes.forEach(cb => {
    const key = cb.dataset.perm;
    if (key) {
      permissions[key] = cb.checked;
    }
  });

  const saveBtn = document.getElementById('btnSavePermissions');
  const originalText = saveBtn ? saveBtn.innerHTML : '';
  if (saveBtn) {
    saveBtn.disabled = true;
    saveBtn.innerHTML = '<span>Spremanje...</span>';
  }

  try {
    const res = await api(`/api/users/${currentPermissionsUserId}/permissions`, {
      method: 'PUT',
      body: JSON.stringify({ permissions })
    });

    showNotification(res.message || 'Dozvole su uspješno sačuvane!');
    closeModal('permissionsModal');

    // Ako je korisnik mijenjao sopstvene permisije, odmah osvježi UI
    if (currentUser && currentUser.id === currentPermissionsUserId) {
      currentUser.permissions = res.permissions;
      setupUIForUser();
    }

    loadUsers();
  } catch (err) {
    alert(err.message || 'Greška pri spremanju dozvola.');
  } finally {
    if (saveBtn) {
      saveBtn.disabled = false;
      saveBtn.innerHTML = originalText;
      refreshIcons();
    }
  }
}

// ==================== MODAL & UI HELPERS ====================
function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (!modal) return;
  modal.classList.remove('hidden');

  if (modalId === 'taskModal') {
    const typeSelect = document.getElementById('taskModalType');
    if (typeSelect) {
      autoAssignWorkerByType(typeSelect.value);
    }
  }

  if (modalId === 'workHourModal') {
    const rateInput = document.getElementById('whHourlyRate');
    if (rateInput) {
      rateInput.readOnly = false;
      if (currentUser && currentUser.hourly_rate) {
        rateInput.value = currentUser.hourly_rate;
      }
    }
  }
  refreshIcons();
}

function closeModal(modalId) {
  const el = document.getElementById(modalId);
  if (el) el.classList.add('hidden');
}

async function openMasterKeyModal() {
  const modal = document.getElementById('masterKeyModal');
  const display = document.getElementById('currentMasterKeyDisplay');
  const input = document.getElementById('newMasterKeyInput');
  if (input) input.value = '';
  if (display) display.textContent = 'Učitavanje...';
  if (modal) modal.classList.remove('hidden');
  refreshIcons();

  try {
    const res = await fetch('/api/portal/master-key', {
      headers: { 'Authorization': `Bearer ${authToken}` }
    });
    if (res.ok) {
      const data = await res.json();
      if (display) display.textContent = data.master_key || 'unikatmd2609876';
    } else {
      if (display) display.textContent = 'Greška pri učitavanju';
    }
  } catch (e) {
    if (display) display.textContent = 'Greška pri učitavanju';
  }
}

async function handleSaveMasterKey(e) {
  if (e) e.preventDefault();
  const input = document.getElementById('newMasterKeyInput');
  const key = (input ? input.value : '').trim();
  if (!key || key.length < 4) {
    alert('Master šifra mora imati minimalno 4 karaktera.');
    return;
  }

  try {
    const res = await fetch('/api/portal/master-key', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`
      },
      body: JSON.stringify({ new_master_key: key })
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Greška pri spremanju.');
    }
    alert(data.message || 'Zajednička master šifra firme je uspješno promijenjena!');
    closeModal('masterKeyModal');
    if (data.gate_token) {
      portalGateToken = data.gate_token;
      localStorage.setItem('unikat_portal_gate', portalGateToken);
    }
  } catch (err) {
    alert(err.message || 'Greška pri ažuriranju master šifre.');
  }
}

function formatCurrency(amount) {
  const num = parseFloat(amount) || 0;
  return num.toLocaleString('bs-BA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' KM';
}

function renderTaskStatusBadge(status) {
  switch (status) {
    case 'done':
      return '<span class="px-2 py-0.5 rounded text-[10px] font-bold badge-done">✓ Urađeno</span>';
    case 'in_progress':
      return '<span class="px-2 py-0.5 rounded text-[10px] font-bold badge-in_progress">⏳ U toku</span>';
    case 'blocked':
      return '<span class="px-2 py-0.5 rounded text-[10px] font-bold badge-blocked">✖ Nije urađeno</span>';
    default:
      return '<span class="px-2 py-0.5 rounded text-[10px] font-bold badge-todo">📋 Za uraditi</span>';
  }
}

function capitalize(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function escapeHtml(text) {
  if (!text) return '';
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function showNotification(msg) {
  showFloatingToast('Obavještenje', msg);
}

// ==================== IMPORT IZ GOOGLE SHEETS / EXCEL ====================
let parsedImportRecords = [];

function parseImportData() {
  const raw = document.getElementById('importRawText').value.trim();
  if (!raw) {
    alert('Molimo unesite ili zalijepite podatke u polje.');
    return;
  }

  const lines = raw.split(/\r?\n/).filter(l => l.trim().length > 0);
  if (lines.length === 0) return;

  const firstLine = lines[0];
  let sep = '\t';
  if (firstLine.includes('\t')) sep = '\t';
  else if (firstLine.includes(';')) sep = ';';
  else if (firstLine.includes(',')) sep = ',';

  const headerCols = firstLine.split(sep).map(c => c.trim().toLowerCase());
  
  let colMap = { client: -1, phone: -1, contact: -1, city: -1, task: -1, status: -1, total: -1, paid: -1 };

  headerCols.forEach((col, idx) => {
    if (col.includes('klijent') || col.includes('firma') || col.includes('naziv') || col.includes('kupac') || col.includes('client')) colMap.client = idx;
    else if (col.includes('tel') || col.includes('mob') || col.includes('phone')) colMap.phone = idx;
    else if (col.includes('kontakt') || col.includes('osoba')) colMap.contact = idx;
    else if (col.includes('grad') || col.includes('mjesto') || col.includes('lokacija')) colMap.city = idx;
    else if (col.includes('zadatak') || col.includes('posao') || col.includes('rad') || col.includes('opis') || col.includes('usluga')) colMap.task = idx;
    else if (col.includes('status') || col.includes('stanje')) colMap.status = idx;
    else if (col.includes('cijena') || col.includes('iznos') || col.includes('ukupno') || col.includes('faktur') || col.includes('dug') || col.includes('total')) colMap.total = idx;
    else if (col.includes('plać') || col.includes('plac') || col.includes('uplac') || col.includes('paid')) colMap.paid = idx;
  });

  let startIndex = 1;
  if (colMap.client === -1) {
    colMap.client = 0;
    colMap.phone = 1;
    colMap.task = 2;
    colMap.status = 3;
    colMap.total = 4;
    colMap.paid = 5;
    startIndex = 0;
  }

  parsedImportRecords = [];
  for (let i = startIndex; i < lines.length; i++) {
    const parts = lines[i].split(sep).map(p => p.trim());
    if (parts.length === 0) continue;
    const clientName = parts[colMap.client] || '';
    if (!clientName) continue;

    parsedImportRecords.push({
      client_name: clientName,
      phone: colMap.phone !== -1 ? (parts[colMap.phone] || '') : '',
      contact_person: colMap.contact !== -1 ? (parts[colMap.contact] || '') : '',
      city: colMap.city !== -1 ? (parts[colMap.city] || '') : '',
      task_title: colMap.task !== -1 ? (parts[colMap.task] || '') : '',
      task_status: colMap.status !== -1 ? (parts[colMap.status] || 'todo') : 'todo',
      total_amount: colMap.total !== -1 ? parseFloat((parts[colMap.total] || '0').replace(/[^0-9.,]/g, '').replace(',', '.')) || 0 : 0,
      paid_amount: colMap.paid !== -1 ? parseFloat((parts[colMap.paid] || '0').replace(/[^0-9.,]/g, '').replace(',', '.')) || 0 : 0
    });
  }

  const container = document.getElementById('importPreviewContainer');
  const tbody = document.getElementById('importPreviewBody');
  const countBadge = document.getElementById('importCountBadge');
  const btn = document.getElementById('btnExecuteImport');

  if (parsedImportRecords.length === 0) {
    alert('Nije pronađen nijedan red sa klijentom.');
    container.classList.add('hidden');
    btn.disabled = true;
    return;
  }

  countBadge.textContent = `${parsedImportRecords.length} stavki`;
  tbody.innerHTML = parsedImportRecords.map(r => `
    <tr>
      <td class="p-2 font-bold text-slate-800">${escapeHtml(r.client_name)} ${r.phone ? `<span class="text-slate-400 font-normal">(${escapeHtml(r.phone)})</span>` : ''}</td>
      <td class="p-2 text-slate-600">${escapeHtml(r.task_title || '-')}</td>
      <td class="p-2">${renderTaskStatusBadge(r.task_status)}</td>
      <td class="p-2 text-right font-semibold">${formatCurrency(r.total_amount)}</td>
      <td class="p-2 text-right text-emerald-600 font-semibold">${formatCurrency(r.paid_amount)}</td>
    </tr>
  `).join('');

  container.classList.remove('hidden');
  btn.disabled = false;
}

async function executeImport() {
  if (parsedImportRecords.length === 0) return;
  const btn = document.getElementById('btnExecuteImport');
  btn.disabled = true;
  btn.textContent = 'Uvoz u toku...';

  try {
    const res = await api('/api/import/records', {
      method: 'POST',
      body: JSON.stringify({ records: parsedImportRecords })
    });
    closeModal('importModal');
    document.getElementById('importRawText').value = '';
    document.getElementById('importPreviewContainer').classList.add('hidden');
    await loadDropdownData();
    if (currentTab === 'clients') loadClients();
    if (currentTab === 'tasks') loadTasks();
    if (currentTab === 'hours') loadWorkHours();
    if (currentTab === 'dashboard') loadDashboard();
    if (currentTab === 'secretary') loadSecretaryModule();
    showNotification(`Uspješno uvezeno ${res.count} stavki!`);
  } catch (err) {
    alert(err.message);
  } finally {
    btn.disabled = false;
    btn.textContent = '2. Potvrdi i Uvezi u Sistem';
  }
}

// ==================== WORK HOURS (RADNI SATI & DNEVNICE) ====================
let currentHoursView = 'entries';
let isEarningsVisible = false;
let currentWorkHoursEntries = [];
let lastWorkHoursSummary = { totalHours: 0, totalOvertime: 0, totalPay: 0, count: 0 };
let lastPayrollData = null;

function toggleEarningsVisibility() {
  isEarningsVisible = !isEarningsVisible;
  updateEarningsDisplay();
}

function updateEarningsDisplay() {
  // Update toggle button text and icon in header
  const btnText = document.getElementById('textHoursEarningsPrivacy');
  const btnIcon = document.getElementById('iconHoursEarningsPrivacy');
  const payEyeIcon = document.getElementById('hoursPayEyeIcon');

  if (btnText) btnText.textContent = isEarningsVisible ? 'Sakrij Zaradu' : 'Prikaži Zaradu';
  if (btnIcon) btnIcon.setAttribute('data-lucide', isEarningsVisible ? 'eye-off' : 'eye');
  if (payEyeIcon) payEyeIcon.setAttribute('data-lucide', isEarningsVisible ? 'eye-off' : 'eye');

  // Update KPI card
  const payEl = document.getElementById('hoursSummaryPay');
  if (payEl) {
    if (isEarningsVisible) {
      payEl.innerHTML = `<span class="cursor-pointer select-none inline-flex items-center gap-1.5" title="Kliknite da sakrijete">${formatCurrency(lastWorkHoursSummary.totalPay)}</span>`;
    } else {
      payEl.innerHTML = `<span class="cursor-pointer select-none inline-flex items-center gap-1.5 text-emerald-700 bg-emerald-100/80 hover:bg-emerald-200 px-3 py-0.5 rounded-xl border border-emerald-300 tracking-widest text-xl transition" title="Kliknite da vidite iznos zarade">•••••• KM <i data-lucide="eye" class="w-4 h-4 ml-1 inline"></i></span>`;
    }
  }

  // Update dashboard subtext if element exists
  const dashSub = document.getElementById('statHoursSubtext');
  if (dashSub) {
    const payText = (currentUser && currentUser.role === 'worker') ? 'Vaša zarada' : 'Ukupan obračun';
    if (isEarningsVisible) {
      dashSub.innerHTML = `<span class="cursor-pointer select-none font-semibold text-emerald-700" onclick="toggleEarningsVisibility()" title="Kliknite da sakrijete zaradu">${payText}: ${formatCurrency(lastWorkHoursSummary.totalPay)} <i data-lucide="eye-off" class="w-3 h-3 inline ml-0.5 text-slate-400"></i></span>`;
    } else {
      dashSub.innerHTML = `<span class="cursor-pointer select-none text-slate-500 hover:text-emerald-700 font-semibold" onclick="toggleEarningsVisibility()" title="Kliknite da vidite iznos zarade">${payText}: •••••• KM <i data-lucide="eye" class="w-3 h-3 inline ml-0.5"></i></span>`;
    }
  }

  // Re-render tables
  if (currentWorkHoursEntries && currentWorkHoursEntries.length > 0) {
    renderHoursTable(currentWorkHoursEntries);
  }
  if (lastPayrollData && currentHoursView === 'payroll') {
    renderPayrollTable(lastPayrollData);
  }

  refreshIcons();
}

async function loadWorkHours() {
  const month = document.getElementById('hoursFilterMonth') ? document.getElementById('hoursFilterMonth').value : '';
  const workerId = document.getElementById('hoursFilterWorker') ? document.getElementById('hoursFilterWorker').value : '';
  const clientId = document.getElementById('hoursFilterClient') ? document.getElementById('hoursFilterClient').value : '';

  try {
    const params = new URLSearchParams();
    if (month) params.append('month', month);
    if (workerId) params.append('user_id', workerId);
    if (clientId) params.append('client_id', clientId);

    const data = await api(`/api/work-hours?${params.toString()}`);
    currentWorkHoursEntries = data.entries || [];
    lastWorkHoursSummary = data.summary || { totalHours: 0, totalOvertime: 0, totalPay: 0, count: 0 };
    
    document.getElementById('hoursSummaryTotal').textContent = `${data.summary.totalHours} h`;
    document.getElementById('hoursSummaryOvertime').textContent = `${data.summary.totalOvertime} h`;
    document.getElementById('hoursSummaryDays').textContent = `${data.summary.count} unosa`;

    if (currentUser.role === 'worker') {
      const payLabel = document.getElementById('hoursPayLabel');
      if (payLabel) payLabel.textContent = 'Vaša Zarada (KM)';
      const workerFilterCont = document.getElementById('hoursWorkerFilterContainer');
      if (workerFilterCont) workerFilterCont.classList.add('hidden');
      const toggle = document.getElementById('hoursViewToggle');
      if (toggle) toggle.classList.add('hidden');
      const printBtn = document.getElementById('btnPayrollPrint');
      if (printBtn) printBtn.classList.add('hidden');
    }

    updateEarningsDisplay();

    if (currentHoursView === 'payroll') {
      loadPayrollReport();
    }

    refreshIcons();
  } catch (err) {
    console.error('Error loading work hours:', err);
  }
}

function renderHoursTable(entries) {
  const tbody = document.getElementById('hoursTableBody');
  if (!tbody) return;

  if (!entries || entries.length === 0) {
    tbody.innerHTML = '<tr><td colspan="11" class="p-6 text-center text-slate-400">Nema evidentiranih radnih sati za odabrani period i filtere.</td></tr>';
    return;
  }

  const canManage = (currentUser?.role === 'admin' || currentUser?.role === 'secretary');

  tbody.innerHTML = entries.map(e => {
    const regHours = parseFloat(e.hours) || 0;
    const otHours = parseFloat(e.overtime_hours) || 0;
    const totalEntryHours = regHours + otHours;

    const rateDisplay = isEarningsVisible 
      ? `<span class="font-bold text-slate-700">${formatCurrency(e.hourly_rate)}</span>`
      : `<span onclick="toggleEarningsVisibility()" class="cursor-pointer select-none font-bold text-slate-400 hover:text-slate-600 tracking-widest text-xs" title="Kliknite za prikaz satnice">•••• KM <i data-lucide="eye" class="w-3 h-3 inline opacity-60"></i></span>`;

    const payDisplay = isEarningsVisible
      ? `<span class="font-extrabold text-emerald-700 text-sm">${formatCurrency(e.calculated_pay)}</span>`
      : `<span onclick="toggleEarningsVisibility()" class="cursor-pointer select-none inline-flex items-center gap-1 text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 font-black tracking-widest text-xs hover:bg-emerald-100 transition" title="Kliknite za prikaz zarade">•••••• KM <i data-lucide="eye" class="w-3 h-3 opacity-70"></i></span>`;

    return `
      <tr class="hover:bg-slate-50/80 transition">
        <td class="p-3 font-semibold text-slate-900">${escapeHtml(e.work_date || '-')}</td>
        <td class="p-3">
          <div class="flex items-center gap-2.5">
            ${getUserAvatar(e.user_avatar || e.user_full_name, 'w-8 h-8', 'text-xs')}
            <div>
              <div class="font-bold text-slate-900 leading-snug">${escapeHtml(e.user_full_name)}</div>
              <div class="text-[10px] text-slate-400 font-semibold">${e.hourly_rate ? `${e.hourly_rate} KM/h` : (e.user_role === 'worker' ? 'Radnik' : e.user_role)}</div>
            </div>
          </div>
        </td>
        <td class="p-3">
          <div class="font-bold text-slate-800">${escapeHtml(e.client_name || 'Opšti rad u firmi')}</div>
          ${e.task_title ? `<div class="text-[10px] text-indigo-600">${escapeHtml(e.task_title)}</div>` : ''}
        </td>
        <td class="p-3 text-slate-600">
          ${e.start_time && e.end_time ? `${e.start_time} - ${e.end_time}` : '-'}
        </td>
        <td class="p-3 text-right font-medium text-slate-700">${regHours.toFixed(1)} h</td>
        <td class="p-3 text-right text-amber-600 font-bold">${otHours > 0 ? `+${otHours.toFixed(1)} h` : '-'}</td>
        <td class="p-3 text-right font-black text-slate-900 bg-slate-50/60">${totalEntryHours.toFixed(1)} h</td>
        <td class="p-3 text-right">${rateDisplay}</td>
        <td class="p-3 text-right font-extrabold text-emerald-700">${payDisplay}</td>
        <td class="p-3 text-slate-600 max-w-xs truncate">${escapeHtml(e.description || '-')}</td>
        <td class="p-3 text-center whitespace-nowrap">
          ${canManage ? `
            <div class="inline-flex items-center gap-1.5">
              <button onclick="openWorkHourModal(${e.id})" class="p-1.5 text-slate-400 hover:text-amber-600 rounded-lg hover:bg-amber-50 transition" title="Uredi radne sate i iznos">
                <i data-lucide="edit-3" class="w-4 h-4"></i>
              </button>
              <button onclick="deleteWorkHourEntry(${e.id})" class="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition" title="Obriši zapis">
                <i data-lucide="trash-2" class="w-4 h-4"></i>
              </button>
            </div>
          ` : `
            <span class="text-xs text-slate-300">-</span>
          `}
        </td>
      </tr>
    `;
  }).join('');
}

function setHoursSubView(view) {
  currentHoursView = view;
  const btnEntries = document.getElementById('btnHoursViewEntries');
  const btnPayroll = document.getElementById('btnHoursViewPayroll');
  const viewEntries = document.getElementById('hoursViewEntries');
  const viewPayroll = document.getElementById('hoursViewPayroll');

  if (view === 'payroll') {
    btnPayroll.classList.add('bg-[#D4AF37]/20', 'text-[#ECC968]', 'border', 'border-[#D4AF37]/50', 'font-bold');
    btnPayroll.classList.remove('text-slate-400');
    btnEntries.classList.remove('bg-[#D4AF37]/20', 'text-[#ECC968]', 'border', 'border-[#D4AF37]/50', 'font-bold');
    btnEntries.classList.add('text-slate-400');
    viewEntries.classList.add('hidden');
    viewPayroll.classList.remove('hidden');
    loadPayrollReport();
  } else {
    btnEntries.classList.add('bg-[#D4AF37]/20', 'text-[#ECC968]', 'border', 'border-[#D4AF37]/50', 'font-bold');
    btnEntries.classList.remove('text-slate-400');
    btnPayroll.classList.remove('bg-[#D4AF37]/20', 'text-[#ECC968]', 'border', 'border-[#D4AF37]/50', 'font-bold');
    btnPayroll.classList.add('text-slate-400');
    viewPayroll.classList.add('hidden');
    viewEntries.classList.remove('hidden');
  }
}

async function loadPayrollReport() {
  const month = document.getElementById('hoursFilterMonth') ? document.getElementById('hoursFilterMonth').value : '';
  try {
    const data = await api(`/api/work-hours/payroll-report?month=${month}`);
    lastPayrollData = data;
    renderPayrollTable(data);
    refreshIcons();
  } catch (err) {
    console.error('Error loading payroll report:', err);
  }
}

function renderPayrollTable(data) {
  const grandTotalEl = document.getElementById('payrollGrandTotal');
  if (grandTotalEl) {
    grandTotalEl.innerHTML = isEarningsVisible
      ? `<span class="cursor-pointer select-none" onclick="toggleEarningsVisibility()" title="Kliknite da sakrijete">${formatCurrency(data.grandTotalPay)}</span>`
      : `<span class="cursor-pointer select-none text-emerald-700 bg-emerald-100/70 hover:bg-emerald-200 px-3 py-1 rounded-xl text-lg tracking-widest font-black transition" onclick="toggleEarningsVisibility()" title="Kliknite da vidite iznos">•••••• KM 👁️</span>`;
  }

  const tbody = document.getElementById('payrollTableBody');
  if (!tbody) return;

  if (!data.workers || data.workers.length === 0) {
    tbody.innerHTML = '<tr><td colspan="8" class="p-6 text-center text-slate-400">Nema evidentiranih radnika za obračun.</td></tr>';
    return;
  }

  tbody.innerHTML = data.workers.map(w => {
    const rateDisplay = isEarningsVisible
      ? `<span class="font-semibold text-slate-700">${formatCurrency(w.hourly_rate)}</span>`
      : `<span onclick="toggleEarningsVisibility()" class="cursor-pointer select-none font-bold text-slate-400 hover:text-slate-600 tracking-widest text-xs" title="Kliknite za prikaz satnice">•••• KM</span>`;

    const payDisplay = isEarningsVisible
      ? `<span class="font-extrabold text-emerald-700 text-sm">${formatCurrency(w.total_pay)}</span>`
      : `<span onclick="toggleEarningsVisibility()" class="cursor-pointer select-none inline-flex items-center gap-1 text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 font-black tracking-widest text-xs hover:bg-emerald-100 transition" title="Kliknite za prikaz">•••••• KM</span>`;

    return `
      <tr class="hover:bg-slate-50 transition">
        <td class="p-3.5">
          <div class="flex items-center gap-2.5">
            ${getUserAvatar(w.avatar || w.full_name, 'w-9 h-9', 'text-xs')}
            <div>
              <div class="font-extrabold text-slate-900 leading-snug">${escapeHtml(w.full_name)}</div>
              <div class="text-[10px] text-slate-400 uppercase font-semibold">${w.role === 'worker' ? 'Radnik' : w.role}</div>
            </div>
          </div>
        </td>
        <td class="p-3.5 text-slate-600">${escapeHtml(w.phone || '-')}</td>
        <td class="p-3.5 text-center font-bold text-slate-700">${w.days_worked} d.</td>
        <td class="p-3.5 text-right font-semibold text-slate-800">${(w.regular_hours !== undefined ? w.regular_hours : (w.total_hours - w.total_overtime)).toFixed(1)} h</td>
        <td class="p-3.5 text-right text-amber-600 font-bold">${w.total_overtime > 0 ? `+${w.total_overtime.toFixed(1)} h` : '-'}</td>
        <td class="p-3.5 text-right font-black text-slate-900 text-sm bg-slate-50/60">${w.total_hours.toFixed(1)} h</td>
        <td class="p-3.5 text-right">${rateDisplay}</td>
        <td class="p-3.5 text-right">${payDisplay}</td>
      </tr>
    `;
  }).join('');
}

function openWorkHourModal(id = null) {
  const form = document.getElementById('workHourForm');
  if (form) form.reset();

  const titleEl = document.getElementById('workHourModalTitle');
  const idEl = document.getElementById('workHourId');
  const dateEl = document.getElementById('whDate');
  const userEl = document.getElementById('whUserId');
  const clientEl = document.getElementById('whClientId');
  const taskEl = document.getElementById('whTaskId');
  const hoursEl = document.getElementById('whHours');
  const otEl = document.getElementById('whOvertime');
  const rateEl = document.getElementById('whHourlyRate');
  const startEl = document.getElementById('whStartTime');
  const endEl = document.getElementById('whEndTime');
  const descEl = document.getElementById('whDescription');
  const btnSubmit = document.getElementById('btnWorkHourSubmit');

  const canManage = (currentUser?.role === 'admin' || currentUser?.role === 'secretary');

  if (id) {
    if (!canManage) {
      alert('Samo administrator (Emin) i sekretarica (Amra) mogu mijenjati postojeće radne sate.');
      return;
    }

    const entry = currentWorkHoursEntries.find(e => e.id === id);
    if (entry) {
      if (titleEl) {
        titleEl.innerHTML = '<i data-lucide="edit-3" class="w-5 h-5 text-amber-500"></i><span>Uredi Radne Sate i Iznos</span>';
      }
      if (idEl) idEl.value = entry.id;
      if (dateEl) dateEl.value = entry.work_date || '';
      if (userEl) {
        userEl.disabled = false;
        userEl.value = entry.user_id || '';
      }
      if (clientEl) clientEl.value = entry.client_id || '';
      if (taskEl) taskEl.value = entry.task_id || '';
      if (hoursEl) hoursEl.value = entry.hours !== undefined ? entry.hours : '';
      if (otEl) otEl.value = entry.overtime_hours !== undefined ? entry.overtime_hours : '0';
      if (rateEl) {
        rateEl.disabled = false;
        rateEl.value = entry.hourly_rate !== undefined ? entry.hourly_rate : '';
      }
      if (startEl) startEl.value = entry.start_time || '08:00';
      if (endEl) endEl.value = entry.end_time || '16:00';
      if (descEl) descEl.value = entry.description || '';
      if (btnSubmit) btnSubmit.textContent = 'Sačuvaj Izmjene';
    }
  } else {
    if (titleEl) {
      titleEl.innerHTML = '<i data-lucide="clock" class="w-5 h-5 text-cyan-600"></i><span>Evidencija Radnih Sati</span>';
    }
    if (idEl) idEl.value = '';
    const today = new Date().toISOString().split('T')[0];
    if (dateEl) dateEl.value = today;

    if (currentUser.role === 'worker') {
      if (userEl) {
        userEl.value = currentUser.id;
        userEl.disabled = true;
      }
      if (rateEl) {
        rateEl.value = currentUser.hourly_rate || 0;
        rateEl.disabled = true;
      }
    } else {
      if (userEl) {
        userEl.disabled = false;
        if (!userEl.value && usersList.length > 0) {
          userEl.value = usersList[0].id;
        }
        const selUser = usersList.find(u => u.id === parseInt(userEl.value));
        if (rateEl) {
          rateEl.disabled = false;
          rateEl.value = selUser ? (selUser.hourly_rate || 0) : 0;
        }
      }
    }

    if (hoursEl) hoursEl.value = '8.0';
    if (otEl) otEl.value = '0';
    if (startEl) startEl.value = '08:00';
    if (endEl) endEl.value = '16:00';
    if (btnSubmit) btnSubmit.textContent = 'Sačuvaj Radne Sate';
  }

  updateWhModalCalculation();
  openModal('workHourModal');
  refreshIcons();
}

async function handleSaveWorkHour(e) {
  e.preventDefault();
  const id = document.getElementById('workHourId').value;
  const work_date = document.getElementById('whDate').value;
  const user_id = document.getElementById('whUserId').value;
  const client_id = document.getElementById('whClientId').value;
  const task_id = document.getElementById('whTaskId').value;
  const hours = document.getElementById('whHours').value;
  const overtime_hours = document.getElementById('whOvertime').value;
  const hourly_rate = document.getElementById('whHourlyRate').value;
  const start_time = document.getElementById('whStartTime').value;
  const end_time = document.getElementById('whEndTime').value;
  const description = document.getElementById('whDescription').value.trim();

  const payload = {
    work_date,
    user_id,
    client_id,
    task_id,
    hours,
    overtime_hours,
    hourly_rate,
    start_time,
    end_time,
    description
  };

  try {
    if (id) {
      await api(`/api/work-hours/${id}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      });
      showNotification('Radni sati i iznos uspješno ažurirani!');
    } else {
      await api('/api/work-hours', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
      showNotification('Radni sati uspješno evidentirani!');
    }

    closeModal('workHourModal');
    document.getElementById('workHourForm').reset();
    document.getElementById('workHourId').value = '';
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('whDate').value = today;
    await loadWorkHours();
    if (currentTab === 'dashboard') loadDashboard();
  } catch (err) {
    alert(err.message);
  }
}

// Alias for existing submit event listener
const handleCreateWorkHour = handleSaveWorkHour;

async function deleteWorkHourEntry(id) {
  if (!confirm('Da li ste sigurni da želite obrisati ovaj zapis radnih sati?')) return;
  try {
    await api(`/api/work-hours/${id}`, { method: 'DELETE' });
    loadWorkHours();
    if (currentTab === 'dashboard') loadDashboard();
    showNotification('Zapis radnih sati obrisan.');
  } catch (err) {
    alert(err.message);
  }
}

function printPayrollReport() {
  window.print();
}

// ==================== WORK HOURS TABLE IMPORT ====================
let parsedHoursRecords = [];

function parseHoursImportData() {
  const raw = document.getElementById('importHoursRawText').value.trim();
  if (!raw) {
    alert('Molimo unesite ili zalijepite podatke o satima.');
    return;
  }

  const lines = raw.split(/\r?\n/).filter(l => l.trim().length > 0);
  if (lines.length === 0) return;

  parsedHoursRecords = [];

  // Check if pasted data is Google Sheets monthly calendar matrix (e.g. contains month name or days 1..31 across)
  const monthMap = {
    'januar': '01', 'februar': '02', 'mart': '03', 'april': '04', 'maj': '05', 'juni': '06',
    'juli': '07', 'avgust': '08', 'septembar': '09', 'oktobar': '10', 'novembar': '11', 'decembar': '12'
  };
  const isMatrixFormat = lines.some(l => {
    const low = l.toLowerCase();
    return Object.keys(monthMap).some(m => low.includes(m)) || (l.includes('1') && l.includes('2') && l.includes('15') && l.includes('DANI:'));
  });

  if (isMatrixFormat) {
    let currentYear = new Date().getFullYear();
    let currentMonth = null;
    let dayCols = [];

    lines.forEach(line => {
      const parts = line.split('\t').map(p => p.trim());
      const lower = line.toLowerCase();

      // Check month header
      for (const [mName, mNum] of Object.entries(monthMap)) {
        if (lower.includes(mName)) {
          currentMonth = mNum;
          const yMatch = line.match(/20\d\d/);
          if (yMatch) currentYear = parseInt(yMatch[0]);
          dayCols = [];
          break;
        }
      }

      // Check days row (1..31)
      if (parts.some(p => p === '1') && parts.some(p => p === '2') && parts.some(p => p === '3')) {
        dayCols = [];
        parts.forEach((p, idx) => {
          const d = parseInt(p);
          if (!isNaN(d) && d >= 1 && d <= 31) dayCols.push({ day: d, colIdx: idx });
        });
        return;
      }

      // Check worker row
      const workerName = parts[0];
      if (currentMonth && dayCols.length > 0 && workerName && !workerName.toLowerCase().includes('dani') && !workerName.toLowerCase().includes('ime i prezime') && !workerName.toLowerCase().includes('unikat') && !workerName.toLowerCase().includes('radno vrijeme')) {
        dayCols.forEach(({ day, colIdx }) => {
          const val = parts[colIdx];
          if (val !== undefined && val !== '') {
            const num = parseFloat(val.replace(',', '.'));
            if (!isNaN(num) && num > 0) {
              const ot = num > 8 ? num - 8 : 0;
              parsedHoursRecords.push({
                worker_name: workerName,
                work_date: `${currentYear}-${currentMonth}-${String(day).padStart(2, '0')}`,
                client_name: 'UNIKAT MD',
                hours: num,
                overtime_hours: ot,
                hourly_rate: 12.5,
                description: `Radno vrijeme 09:00 - 17:00h (${workerName})`
              });
            }
          }
        });
      }
    });
  } else {
    // Standard tabular format
    const firstLine = lines[0];
    let sep = '\t';
    if (firstLine.includes('\t')) sep = '\t';
    else if (firstLine.includes(';')) sep = ';';
    else if (firstLine.includes(',')) sep = ',';

    const headerCols = firstLine.split(sep).map(c => c.trim().toLowerCase());
    let colMap = { worker: -1, date: -1, client: -1, hours: -1, overtime: -1, rate: -1, desc: -1 };

    headerCols.forEach((col, idx) => {
      if (col.includes('radnik') || col.includes('ime') || col.includes('zaposlen') || col.includes('worker')) colMap.worker = idx;
      else if (col.includes('datum') || col.includes('dan') || col.includes('date')) colMap.date = idx;
      else if (col.includes('klijent') || col.includes('firma') || col.includes('kupac') || col.includes('client')) colMap.client = idx;
      else if (col.includes('prekovrem')) colMap.overtime = idx;
      else if (col.includes('sat') || col.includes('hours') || col.includes('čas')) colMap.hours = idx;
      else if (col.includes('satnic') || col.includes('rate')) colMap.rate = idx;
      else if (col.includes('opis') || col.includes('rad') || col.includes('posao')) colMap.desc = idx;
    });

    let startIndex = 1;
    if (colMap.hours === -1) {
      colMap.worker = 0;
      colMap.date = 1;
      colMap.client = 2;
      colMap.hours = 3;
      colMap.desc = 4;
      startIndex = 0;
    }

    for (let i = startIndex; i < lines.length; i++) {
      const parts = lines[i].split(sep).map(p => p.trim().replace(/^["']|["']$/g, ''));
      if (parts.length === 0) continue;

      const numHours = colMap.hours !== -1 ? (parseFloat((parts[colMap.hours] || '').replace(/[^0-9.,]/g, '').replace(',', '.')) || 0) : 0;
      if (numHours <= 0) continue;

      parsedHoursRecords.push({
        worker_name: colMap.worker !== -1 ? (parts[colMap.worker] || '') : '',
        work_date: colMap.date !== -1 ? (parts[colMap.date] || '') : new Date().toISOString().split('T')[0],
        client_name: colMap.client !== -1 ? (parts[colMap.client] || '') : '',
        hours: numHours,
        overtime_hours: colMap.overtime !== -1 ? (parseFloat((parts[colMap.overtime] || '0').replace(/[^0-9.,]/g, '').replace(',', '.')) || 0) : 0,
        hourly_rate: colMap.rate !== -1 ? (parseFloat((parts[colMap.rate] || '0').replace(/[^0-9.,]/g, '').replace(',', '.')) || 0) : 0,
        description: colMap.desc !== -1 ? (parts[colMap.desc] || '') : ''
      });
    }
  }

  const container = document.getElementById('importHoursPreviewContainer');
  const tbody = document.getElementById('importHoursPreviewBody');
  const countBadge = document.getElementById('importHoursCountBadge');
  const btn = document.getElementById('btnExecuteHoursImport');

  if (parsedHoursRecords.length === 0) {
    alert('Nije pronađen nijedan red sa validnim brojem radnih sati.');
    container.classList.add('hidden');
    btn.disabled = true;
    return;
  }

  countBadge.textContent = `${parsedHoursRecords.length} unosa`;
  tbody.innerHTML = parsedHoursRecords.map(r => `
    <tr>
      <td class="p-2 font-bold text-slate-800">${escapeHtml(r.worker_name || 'Trenutni korisnik')}</td>
      <td class="p-2 text-slate-600">${r.work_date}</td>
      <td class="p-2 text-slate-700 font-semibold">${escapeHtml(r.client_name || 'Opšti rad')}</td>
      <td class="p-2 text-right font-extrabold text-cyan-800">${r.hours} h</td>
      <td class="p-2 text-slate-500">${escapeHtml(r.description || '-')}</td>
    </tr>
  `).join('');

  container.classList.remove('hidden');
  btn.disabled = false;
}

async function executeHoursImport() {
  if (parsedHoursRecords.length === 0) return;
  const btn = document.getElementById('btnExecuteHoursImport');
  btn.disabled = true;
  btn.textContent = 'Uvoz u toku...';

  try {
    const res = await api('/api/work-hours/import', {
      method: 'POST',
      body: JSON.stringify({ records: parsedHoursRecords })
    });
    closeModal('importHoursModal');
    document.getElementById('importHoursRawText').value = '';
    document.getElementById('importHoursPreviewContainer').classList.add('hidden');
    await loadDropdownData();
    await loadWorkHours();
    if (currentTab === 'dashboard') loadDashboard();
    showNotification(`Uspješno uvezeno ${res.count} unosa radnih sati!`);
  } catch (err) {
    alert(err.message);
  } finally {
    btn.disabled = false;
    btn.textContent = '2. Potvrdi i Uvezi Sate';
  }
}

// ==================== ŠTAMPARIJA & EVIDENCIJA ZA ŠTAMPARIJU ====================
let printSelectedMonth = 'all';

function formatPrintDate(d) {
  if (!d) return '-';
  const m = String(d).match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (m) {
    return `${m[3]}.${m[2]}.`;
  }
  return escapeHtml(d);
}

function getMonthNameBosnian(monthStr) {
  if (!monthStr || monthStr === 'all') return 'Svi periodi (Ukupno)';
  const parts = String(monthStr).split('-');
  const year = parts[0];
  const month = parts[1];
  const names = {
    '01': 'Januar', '02': 'Februar', '03': 'Mart', '04': 'April',
    '05': 'Maj', '06': 'Juni', '07': 'Juli', '08': 'August',
    '09': 'Septembar', '10': 'Oktobar', '11': 'Novembar', '12': 'Decembar'
  };
  return `${names[month] || month} ${year}`;
}

async function loadPrintServices(status = printActiveFilter, search = null) {
  try {
    printActiveFilter = status;
    const searchVal = search !== null ? search : (document.getElementById('printSearchInput')?.value || '');

    let url = `/api/print-services?`;
    if (status && status !== 'all') {
      url += `status=${encodeURIComponent(status)}&`;
    }
    if (printSelectedMonth && printSelectedMonth !== 'all') {
      url += `month=${encodeURIComponent(printSelectedMonth)}&`;
    }
    if (searchVal.trim()) {
      url += `search=${encodeURIComponent(searchVal.trim())}&`;
    }

    const data = await api(url);
    printServicesList = data.printServices || [];
    const rawStats = data.stats || {};
    const totalCount = rawStats.totalCount ?? printServicesList.length;
    const doneCount = rawStats.doneCount ?? 0;
    const inProgressCount = rawStats.inProgressCount ?? 0;
    const totalToPay = rawStats.totalToPay ?? printServicesList.reduce((acc, it) => acc + (it.price || 0), 0);

    // Update KPI badges & stats
    const statTotalEl = document.getElementById('printStatTotal');
    const statDoneEl = document.getElementById('printStatDone');
    const statInProgEl = document.getElementById('printStatInProgress');
    const statTotalOwedEl = document.getElementById('printStatTotalOwed');
    const statMonthLabel = document.getElementById('printStatMonthLabel');
    const countBadge = document.getElementById('printResultsCountBadge');
    const sidebarBadge = document.getElementById('badgePrintCount');
    const tableTotalBadge = document.getElementById('printTableTotalBadge');

    if (statTotalEl) statTotalEl.textContent = totalCount;
    if (statDoneEl) statDoneEl.textContent = doneCount;
    if (statInProgEl) statInProgEl.textContent = inProgressCount;
    if (statTotalOwedEl) statTotalOwedEl.textContent = formatCurrency(totalToPay);
    if (statMonthLabel) {
      statMonthLabel.textContent = printSelectedMonth === 'all' 
        ? 'Ukupan račun za sve evidentirane periode' 
        : `Za isplatu štampariji za ${getMonthNameBosnian(printSelectedMonth)}`;
    }
    if (countBadge) countBadge.textContent = `${printServicesList.length} ${printServicesList.length === 1 ? 'nalog' : 'naloga'}`;
    if (sidebarBadge) sidebarBadge.textContent = totalCount;
    if (tableTotalBadge) tableTotalBadge.textContent = `Ukupno za platiti: ${formatCurrency(totalToPay)}`;

    populatePrintMonthDropdown(data.availableMonths || []);
    renderPrintServicesTable(printServicesList, totalToPay);
  } catch (err) {
    console.error('Error loading print services:', err);
  }
}

function populatePrintMonthDropdown(months) {
  const select = document.getElementById('printMonthFilter');
  if (!select) return;

  const currentVal = printSelectedMonth || 'all';
  let html = `<option value="all" ${currentVal === 'all' ? 'selected' : ''}>Svi periodi (Ukupno)</option>`;

  const now = new Date();
  const currentYm = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  const allMonths = Array.from(new Set([currentYm, ...months])).sort().reverse();

  allMonths.forEach(m => {
    const label = getMonthNameBosnian(m);
    const isSelected = (currentVal === m);
    html += `<option value="${m}" ${isSelected ? 'selected' : ''}>${label}</option>`;
  });

  select.innerHTML = html;
}

function onPrintMonthChange(month) {
  printSelectedMonth = month;
  loadPrintServices();
}

function renderPrintServicesTable(items, totalAmount = null) {
  const tbody = document.getElementById('printServicesTableBody');
  const tfoot = document.getElementById('printServicesTableFoot');
  const emptyState = document.getElementById('printEmptyState');
  if (!tbody) return;

  if (!items || items.length === 0) {
    tbody.innerHTML = '';
    if (tfoot) tfoot.innerHTML = '';
    if (emptyState) emptyState.classList.remove('hidden');
    refreshIcons();
    return;
  }

  if (emptyState) emptyState.classList.add('hidden');

  let computedSum = 0;

  tbody.innerHTML = items.map(item => {
    const isDone = item.status === 'Završeno' || item.status === 'done';
    const isInProgress = item.status === 'U toku' || item.status === 'in_progress';
    const displayStatus = isDone ? 'Završeno' : (isInProgress ? 'U toku' : 'Otkazano');

    let statusBadgeClass = 'bg-slate-100 text-slate-700 border-slate-200';
    if (isDone) {
      statusBadgeClass = 'bg-emerald-50 text-emerald-700 border-emerald-200';
    } else if (isInProgress) {
      statusBadgeClass = 'bg-amber-50 text-amber-800 border-amber-200';
    }

    const price = item.price || 0;
    computedSum += price;
    const canManage = (currentUser?.role === 'admin' || currentUser?.role === 'secretary' || can('manage_print'));

    return `
      <tr class="hover:bg-slate-50/80 transition-colors">
        <td class="p-3.5 whitespace-nowrap font-bold text-slate-900">${formatPrintDate(item.order_date)}</td>
        <td class="p-3.5 whitespace-nowrap">
          <div class="font-extrabold text-slate-900 text-xs">${escapeHtml(item.client_name)}</div>
          ${item.client_phone ? `<div class="text-[10px] text-slate-400">${escapeHtml(item.client_phone)}</div>` : ''}
        </td>
        <td class="p-3.5 whitespace-nowrap">
          <span class="inline-flex items-center px-2 py-0.5 rounded-md text-xs font-bold bg-amber-50 text-amber-900 border border-amber-200">
            ${escapeHtml(item.service_type)}
          </span>
        </td>
        <td class="p-3.5 max-w-xs text-slate-700 font-medium text-xs leading-relaxed">
          ${escapeHtml(item.description || '-')}
        </td>
        <td class="p-3.5 whitespace-nowrap">
          <span class="inline-flex items-center gap-1 text-xs font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded-md">
            <i data-lucide="building-2" class="w-3 h-3 text-slate-500"></i>
            ${escapeHtml(item.executor || 'Misija')}
          </span>
        </td>
        <td class="p-3.5 text-center whitespace-nowrap">
          <button onclick="togglePrintStatus(${item.id}, '${escapeHtml(item.status)}')" title="Klikni za brzu promjenu statusa" class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-extrabold border shadow-2xs transition hover:opacity-80 ${statusBadgeClass}">
            <i data-lucide="${isDone ? 'check-circle' : (isInProgress ? 'clock' : 'circle')}" class="w-3 h-3"></i>
            <span>${displayStatus}</span>
          </button>
        </td>
        <td class="p-3.5 text-right whitespace-nowrap">
          ${price > 0 
            ? `<span class="font-black text-xs text-slate-950 bg-amber-50/70 border border-amber-200 px-2.5 py-1 rounded-lg inline-block shadow-2xs">${formatCurrency(price)}</span>` 
            : '<span class="text-slate-400 font-semibold">-</span>'}
        </td>
        <td class="p-3.5 whitespace-nowrap text-slate-500 italic text-xs">
          ${escapeHtml(item.notes || '-')}
        </td>
        <td class="p-3.5 whitespace-nowrap text-slate-700 font-medium text-xs">
          <div class="inline-flex items-center gap-2">
            ${getUserAvatar(item.responsible_person || 'Emin / Amra', 'w-6 h-6', 'text-[9px]')}
            <span>${escapeHtml(item.responsible_person || 'Emin / Amra')}</span>
          </div>
        </td>
        <td class="p-3.5 text-right whitespace-nowrap">
          <div class="inline-flex items-center gap-1">
            <button onclick="openPrintModal(${item.id})" title="Uredi nalog" class="p-1.5 text-slate-400 hover:text-amber-600 rounded-lg hover:bg-amber-50 transition">
              <i data-lucide="edit-3" class="w-4 h-4"></i>
            </button>
            ${canManage ? `
              <button onclick="deletePrintService(${item.id})" title="Obriši nalog" class="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition">
                <i data-lucide="trash-2" class="w-4 h-4"></i>
              </button>
            ` : ''}
          </div>
        </td>
      </tr>
    `;
  }).join('');

  const finalSum = (totalAmount !== null && totalAmount !== undefined) ? totalAmount : computedSum;

  if (tfoot) {
    tfoot.innerHTML = `
      <tr class="bg-amber-50/60 border-t-2 border-amber-300">
        <td colspan="6" class="p-3.5 text-right font-black uppercase text-xs text-amber-950">
          UKUPNO ZA PLATITI ŠTAMPARIJI (${printSelectedMonth === 'all' ? 'SVI NALOZI' : getMonthNameBosnian(printSelectedMonth).toUpperCase()}):
        </td>
        <td class="p-3.5 text-right font-black text-sm text-slate-950">
          ${formatCurrency(finalSum)}
        </td>
        <td colspan="3" class="p-3.5 text-slate-500 text-[11px] font-medium">
          (${items.length} stavki • Račun štamparije za isplatu)
        </td>
      </tr>
    `;
  }

  refreshIcons();
}

function filterPrintServices(status) {
  printActiveFilter = status;

  const btnAll = document.getElementById('btnPrintFilterAll');
  const btnDone = document.getElementById('btnPrintFilterDone');
  const btnPending = document.getElementById('btnPrintFilterPending');

  [btnAll, btnDone, btnPending].forEach(btn => {
    if (btn) {
      btn.className = 'px-3 py-1.5 rounded-lg text-xs font-bold text-slate-600 hover:text-slate-900 transition';
    }
  });

  if (status === 'all' && btnAll) {
    btnAll.className = 'px-3 py-1.5 rounded-lg text-xs font-bold bg-white text-slate-900 shadow-2xs';
  } else if ((status === 'Završeno' || status === 'done') && btnDone) {
    btnDone.className = 'px-3 py-1.5 rounded-lg text-xs font-bold bg-emerald-600 text-white shadow-2xs';
  } else if ((status === 'U toku' || status === 'in_progress') && btnPending) {
    btnPending.className = 'px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-600 text-white shadow-2xs';
  }

  loadPrintServices(status);
}

function debouncePrintSearch() {
  if (printSearchDebounceTimer) clearTimeout(printSearchDebounceTimer);
  printSearchDebounceTimer = setTimeout(() => {
    loadPrintServices(printActiveFilter);
  }, 250);
}

function openPrintModal(id = null) {
  const form = document.getElementById('printServiceForm');
  if (form) form.reset();

  const titleEl = document.getElementById('printModalTitle');
  const idEl = document.getElementById('printId');
  const dateEl = document.getElementById('printOrderDate');
  const executorEl = document.getElementById('printExecutor');
  const respEl = document.getElementById('printResponsible');
  const statusEl = document.getElementById('printStatus');
  const priceEl = document.getElementById('printPrice');

  if (id) {
    const item = printServicesList.find(p => p.id === id);
    if (item) {
      if (titleEl) titleEl.textContent = 'Uredi Nalog za Štampu';
      if (idEl) idEl.value = item.id;
      if (dateEl) dateEl.value = item.order_date || '';
      document.getElementById('printClientName').value = item.client_name || '';
      document.getElementById('printServiceType').value = item.service_type || '';
      document.getElementById('printDescription').value = item.description || '';
      if (executorEl) executorEl.value = item.executor || 'Misija';
      const statusVal = (item.status === 'done' || item.status === 'Završeno') ? 'done' : ((item.status === 'in_progress' || item.status === 'U toku') ? 'in_progress' : 'cancelled');
      if (statusEl) statusEl.value = statusVal;
      if (priceEl) priceEl.value = item.price || '';
      if (respEl) respEl.value = item.responsible_person || 'Emin / Amra';
      document.getElementById('printNotes').value = item.notes || '';
    }
  } else {
    if (titleEl) titleEl.textContent = 'Novi Nalog za Štampu';
    if (idEl) idEl.value = '';
    
    // Default today formatted as DD.MM.
    const today = new Date();
    const day = String(today.getDate()).padStart(2, '0');
    const month = String(today.getMonth() + 1).padStart(2, '0');
    if (dateEl) dateEl.value = `${day}.${month}.`;

    if (executorEl) executorEl.value = 'Misija';
    if (respEl) respEl.value = 'Emin / Amra';
    if (statusEl) statusEl.value = 'done';
    if (priceEl) priceEl.value = '';
  }

  openModal('printModal');
  refreshIcons();
}

async function handleSavePrintService(e) {
  e.preventDefault();
  const id = document.getElementById('printId').value;
  const order_date = document.getElementById('printOrderDate').value.trim();
  const client_name = document.getElementById('printClientName').value.trim();
  const service_type = document.getElementById('printServiceType').value.trim();
  const description = document.getElementById('printDescription').value.trim();
  const executor = document.getElementById('printExecutor').value.trim() || 'Misija';
  const status = document.getElementById('printStatus').value;
  const priceVal = document.getElementById('printPrice').value;
  const price = priceVal !== '' ? parseFloat(priceVal) : 0;
  const responsible_person = document.getElementById('printResponsible').value.trim() || 'Emin / Amra';
  const notes = document.getElementById('printNotes').value.trim();

  // Match client_id if client exists in clientsList
  let client_id = null;
  const matchedClient = clientsList.find(c => c.name.toLowerCase() === client_name.toLowerCase());
  if (matchedClient) {
    client_id = matchedClient.id;
  }

  const payload = {
    order_date,
    client_id,
    client_name,
    service_type,
    description,
    executor,
    status,
    price,
    notes,
    responsible_person
  };

  try {
    if (id) {
      await api(`/api/print-services/${id}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      });
      showNotification('Nalog za štampu uspješno ažuriran!');
    } else {
      await api('/api/print-services', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
      showNotification('Novi nalog za štampu uspješno evidentiran!');
    }

    closeModal('printModal');
    loadPrintServices();
  } catch (err) {
    alert(err.message);
  }
}

async function togglePrintStatus(id, currentStatus) {
  const isDone = currentStatus === 'Završeno' || currentStatus === 'done';
  const newStatus = isDone ? 'in_progress' : 'done';
  try {
    await api(`/api/print-services/${id}`, {
      method: 'PUT',
      body: JSON.stringify({ status: newStatus })
    });
    showNotification(`Status naloga promijenjen u: ${newStatus === 'done' ? 'Završeno' : 'U toku'}`);
    loadPrintServices();
  } catch (err) {
    alert(err.message);
  }
}

async function deletePrintService(id) {
  if (!confirm('Jeste li sigurni da želite obrisati ovaj nalog štampe?')) return;
  try {
    await api(`/api/print-services/${id}`, {
      method: 'DELETE'
    });
    showNotification('Nalog za štampu je obrisan!');
    loadPrintServices();
  } catch (err) {
    alert(err.message);
  }
}

// ==================== PROMJENA ŠIFRE (ZA SVAKOG RADNIKA) ====================
function openChangePasswordModal() {
  const form = document.getElementById('changePasswordForm');
  if (form) form.reset();
  openModal('changePasswordModal');
  refreshIcons();
}

async function handleChangePassword(e) {
  e.preventDefault();
  const currentPassword = document.getElementById('cpCurrentPassword').value;
  const newPassword = document.getElementById('cpNewPassword').value;
  const confirmPassword = document.getElementById('cpConfirmPassword').value;

  if (!currentPassword || !newPassword) {
    alert('Morate unijeti trenutnu i novu lozinku.');
    return;
  }

  if (newPassword !== confirmPassword) {
    alert('Nova lozinka i potvrda se ne poklapaju! Molimo unesite ponovo.');
    return;
  }

  if (newPassword.length < 4) {
    alert('Nova lozinka mora imati najmanje 4 karaktera.');
    return;
  }

  try {
    const res = await api('/api/auth/change-password', {
      method: 'PUT',
      body: JSON.stringify({ currentPassword, newPassword })
    });
    showNotification(res.message || 'Lozinka je uspješno promijenjena!');
    closeModal('changePasswordModal');
    const form = document.getElementById('changePasswordForm');
    if (form) form.reset();
  } catch (err) {
    alert(err.message || 'Greška pri promjeni lozinke.');
  }
}
