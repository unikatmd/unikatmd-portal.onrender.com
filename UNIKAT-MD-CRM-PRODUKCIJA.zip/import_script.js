const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');

const dbPath = path.join(__dirname, 'poslovni_sistem.db');
const db = new Database(dbPath);

console.log('Database connected.');
